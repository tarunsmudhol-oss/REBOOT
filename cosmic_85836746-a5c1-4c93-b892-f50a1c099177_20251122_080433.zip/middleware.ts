import { createAuthMiddleware } from 'cosmic-authentication';

export const middleware = createAuthMiddleware({
  protectedRoutes: [
    '/student-dashboard',
    '/student-portal',
    '/teacher-dashboard', 
    '/parent-dashboard',
    '/parents-guardians-zone',
    '/feedback',
    '/feedback/analytics'
  ]
});

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|api/|favicon.ico).*)',
  ]
};