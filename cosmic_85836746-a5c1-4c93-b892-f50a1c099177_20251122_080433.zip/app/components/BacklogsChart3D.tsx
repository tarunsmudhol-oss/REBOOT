"use client";

import React, { useMemo } from "react";
import Pie3D, { PieSlice } from "@/app/components/Pie3D";

export type BacklogStatus = "red" | "yellow" | "green";

export interface BacklogItem {
  id: string;
  topic: string;
  status: BacklogStatus;
  notes?: string;
}

interface BacklogsChart3DProps {
  items: BacklogItem[];
}

export default function BacklogsChart3D({ items }: BacklogsChart3DProps) {
  const { slices, counts, total } = useMemo(() => {
    const red = items.filter((i) => i.status === "red").length;
    const yellow = items.filter((i) => i.status === "yellow").length;
    const green = items.filter((i) => i.status === "green").length;
    const t = Math.max(1, red + yellow + green);
    const sl: PieSlice[] = [
      { label: "Very Important", value: (red / t) * 100, color: "#ef4444" },
      { label: "Practice Often", value: (yellow / t) * 100, color: "#f59e0b" },
      { label: "Revision", value: (green / t) * 100, color: "#16a34a" }
    ];
    return { slices: sl, counts: { red, yellow, green }, total: red + yellow + green };
  }, [items]);

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-medium text-slate-900">academic journey</h3>
        <p className="text-xs text-slate-500">{total} topics</p>
      </div>
      <Pie3D slices={slices} />
      <div className="mt-4 grid grid-cols-3 gap-4 text-xs">
        <div className="flex items-center gap-2">
          <span className="inline-block w-3 h-3 rounded-full" style={{ background: '#ef4444' }} />
          <p className="text-slate-700">Red: {counts.red}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-block w-3 h-3 rounded-full" style={{ background: '#f59e0b' }} />
          <p className="text-slate-700">Yellow: {counts.yellow}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-block w-3 h-3 rounded-full" style={{ background: '#16a34a' }} />
          <p className="text-slate-700">Green: {counts.green}</p>
        </div>
      </div>
    </div>
  );
}
