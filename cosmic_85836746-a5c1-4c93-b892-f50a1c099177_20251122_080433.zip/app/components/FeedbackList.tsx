"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Icon } from "@iconify/react";

interface Item {
  id: string;
  userId: string;
  role?: string;
  feedbackType: string;
  rating?: number;
  text?: string;
  subject?: string;
  course?: string;
  context?: string;
  status?: string;
  createdAt?: { toDate?: () => Date } | string | number | null;
}

export default function FeedbackList() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>("");
  const [notifications, setNotifications] = useState<Item[]>([]);
  const lastFetch = useRef<number>(Date.now());

  const fetchAll = async () => {
    setLoading(true);
    setError("");
    try {
      const r = await fetch('/api/feedback', { cache: 'no-store' });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'Failed to load feedback');
      setItems(j.items || []);
      lastFetch.current = Date.now();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  const pollNew = async () => {
    try {
      const r = await fetch(`/api/feedback?since=${lastFetch.current}`);
      const j = await r.json();
      if (r.ok && Array.isArray(j.items) && j.items.length > 0) {
        // prepend new items
        setItems((prev) => [...j.items, ...prev]);
        setNotifications(j.items);
      }
      lastFetch.current = Date.now();
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    void fetchAll();
    const id = setInterval(pollNew, 8000);
    return () => clearInterval(id);
  }, []);

  const markResponded = async (id: string) => {
    try {
      const r = await fetch('/api/feedback', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status: 'responded' }) });
      if (r.ok) {
        setItems((prev) => prev.map((it) => it.id === id ? { ...it, status: 'responded' } : it));
      }
    } catch {
      // ignore
    }
  };

  const friendlyDate = (it: Item) => {
    const d = typeof it.createdAt === 'object' && it.createdAt?.toDate ? it.createdAt.toDate() : (typeof it.createdAt === 'string' ? new Date(it.createdAt) : (typeof it.createdAt === 'number' ? new Date(it.createdAt) : null));
    return d ? d.toLocaleString() : '';
  };

  const grouped = useMemo(() => {
    const map: Record<string, Item[]> = {};
    for (const it of items) {
      const k = it.status || 'new';
      map[k] = map[k] || [];
      map[k].push(it);
    }
    return map;
  }, [items]);

  return (
    <section className="w-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium text-slate-900">Latest Feedback</h2>
        <button onClick={fetchAll} className="text-sm text-slate-700 hover:text-slate-900 px-3 py-1.5 rounded bg-slate-100">Refresh</button>
      </div>

      {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm mb-3">{error}</div>}

      {loading ? (
        <p className="text-sm text-slate-600">Loading…</p>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          {(['new','in-progress','responded'] as const).map((status) => (
            <div key={status} className="bg-white/80 backdrop-blur-sm rounded-xl p-4 border border-white/20">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm text-slate-700 capitalize">{status.replace('-', ' ')}</p>
                <span className="text-xs px-2 py-1 rounded bg-slate-100 text-slate-700">{(grouped[status]||[]).length}</span>
              </div>
              <div className="space-y-3">
                {(grouped[status]||[]).map((it) => (
                  <div key={it.id} className="p-3 rounded-lg border border-slate-200/70 bg-slate-50/50">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs px-2 py-0.5 rounded bg-blue-100 text-blue-700">{it.feedbackType}</span>
                        {typeof it.rating === 'number' && it.rating > 0 && (
                          <span className="text-xs text-amber-600 flex items-center gap-1"><Icon icon="mdi:star"/> {it.rating}</span>
                        )}
                      </div>
                      <span className="text-xs text-slate-500">{friendlyDate(it)}</span>
                    </div>
                    <p className="text-sm text-slate-800 mb-2">{it.text || 'No message provided'}</p>
                    <div className="flex items-center justify-between text-xs text-slate-600">
                      <span>{it.role || 'user'}</span>
                      <div className="flex items-center gap-2">
                        {status !== 'responded' && <button onClick={()=>markResponded(it.id)} className="px-2 py-1 rounded bg-emerald-600 text-white">Mark Responded</button>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Notification toasts */}
      <div className="fixed top-4 right-4 z-50">
        <AnimatePresence>
          {notifications.map((n) => (
            <motion.div key={n.id} initial={{opacity:0, y:-10}} animate={{opacity:1, y:0}} exit={{opacity:0, y:-10}} transition={{duration:0.25}} className="mb-2 p-3 rounded-lg shadow bg-white/90 border border-slate-200 w-80">
              <div className="flex items-center justify-between">
                <p className="text-sm text-slate-900">New feedback • {n.feedbackType}</p>
                <button onClick={()=>setNotifications((prev)=>prev.filter((x)=>x.id!==n.id))} className="text-slate-500 hover:text-slate-700">
                  <Icon icon="mdi:close" />
                </button>
              </div>
              <p className="text-xs text-slate-600 mt-1 line-clamp-2">{n.text || 'No message'}</p>
              <div className="mt-2 flex items-center gap-2">
                <button onClick={()=>markResponded(n.id)} className="text-xs px-2 py-1 rounded bg-slate-900 text-white">Mark Responded</button>
                <a href="#" className="text-xs text-teal-700 hover:underline">Open</a>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </section>
  );
}
