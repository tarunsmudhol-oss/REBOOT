"use client";

import React from "react";
import { Icon } from "@iconify/react";

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-slate-200/60 bg-white/80 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-6 py-10">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <p className="text-slate-900 text-sm">Smart Student Portal</p>
            <p className="text-slate-500 text-xs mt-2">
              Helping students learn, grow, and succeed with caring mentorship and the right tools.
            </p>
          </div>
          <div>
            <p className="text-slate-900 text-sm">Contact</p>
            <ul className="mt-2 space-y-1 text-xs text-slate-600">
              <li className="flex items-center gap-2"><Icon icon="ic:outline-email" className="text-slate-500" /><a href="mailto:support@smartstudentportal.edu" className="hover:text-slate-900">support@smartstudentportal.edu</a></li>
              <li className="flex items-center gap-2"><Icon icon="mdi:phone-outline" className="text-slate-500" /><a href="tel:+18005551234" className="hover:text-slate-900">+1 (800) 555‑1234</a></li>
              <li className="flex items-center gap-2"><Icon icon="mdi:map-marker-outline" className="text-slate-500" /><span>123 Learning Ave, Suite 200, Edutown</span></li>
            </ul>
          </div>
          <div>
            <p className="text-slate-900 text-sm">Quick Links</p>
            <ul className="mt-2 space-y-1 text-xs text-slate-600">
              <li><a href="/student-dashboard" className="hover:text-slate-900">Student Dashboard</a></li>
              <li><a href="/teacher-dashboard" className="hover:text-slate-900">Teacher Dashboard</a></li>
              <li><a href="/parents-guardians-zone" className="hover:text-slate-900">Parents/Guardians Zone</a></li>
            </ul>
          </div>
          <div>
            <p className="text-slate-900 text-sm">Stay Updated</p>
            <form className="mt-2 flex items-center gap-2" onSubmit={(e) => e.preventDefault()}>
              <input aria-label="Email address" type="email" placeholder="Your email" className="w-full text-sm px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              <button className="px-3 py-2 text-sm rounded-lg bg-blue-600 text-white hover:bg-blue-700">Subscribe</button>
            </form>
            <div className="flex items-center gap-3 mt-3 text-slate-500">
              <a aria-label="Twitter" href="#" className="hover:text-slate-900"><Icon icon="mdi:twitter" /></a>
              <a aria-label="Instagram" href="#" className="hover:text-slate-900"><Icon icon="mdi:instagram" /></a>
              <a aria-label="GitHub" href="#" className="hover:text-slate-900"><Icon icon="mdi:github" /></a>
            </div>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mt-8">
          <p className="text-xs text-slate-500">© {new Date().getFullYear()} Smart Student Portal. All rights reserved.</p>
          <div className="text-xs text-slate-500 flex items-center gap-3">
            <a href="#" className="hover:text-slate-900">Privacy</a>
            <span>•</span>
            <a href="#" className="hover:text-slate-900">Terms</a>
            <span>•</span>
            <a href="#" className="hover:text-slate-900">Support</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
