"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react";

interface FeedbackPayload {
  feedbackType: string;
  rating?: number;
  text?: string;
  mcqAnswers?: Record<string, string>;
  emojiMatrix?: Record<string, unknown>;
  subject?: string;
  course?: string;
  context?: string;
}

function useFeedbackQueue() {
  const KEY = "feedback-queue";
  const [syncing, setSyncing] = useState(false);

  const read = (): FeedbackPayload[] => {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return [];
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch {
      return [];
    }
  };

  const write = (arr: FeedbackPayload[]) => {
    localStorage.setItem(KEY, JSON.stringify(arr));
  };

  const enqueue = (item: FeedbackPayload) => {
    const arr = read();
    arr.push(item);
    write(arr);
  };

  const flush = useCallback(async () => {
    if (syncing) return;
    const arr = read();
    if (!navigator.onLine || arr.length === 0) return;
    setSyncing(true);
    try {
      const remaining: FeedbackPayload[] = [];
      for (const item of arr) {
        try {
          const res = await fetch("/api/feedback", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(item)
          });
          if (!res.ok) remaining.push(item);
        } catch {
          remaining.push(item);
        }
      }
      write(remaining);
    } finally {
      setSyncing(false);
    }
  }, [syncing]);

  useEffect(() => {
    const onOnline = () => void flush();
    const onVisible = () => { if (document.visibilityState === 'visible') void flush(); };
    window.addEventListener('online', onOnline);
    document.addEventListener('visibilitychange', onVisible);
    void flush();
    return () => {
      window.removeEventListener('online', onOnline);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [flush]);

  return { enqueue, flush, syncing };
}

export default function FeedbackForm() {
  const [feedbackType, setFeedbackType] = useState<string>("course");
  const [rating, setRating] = useState<number>(0);
  const [text, setText] = useState<string>("");
  const [mcq, setMcq] = useState<Record<string, string>>({ q1: "", q2: "" });
  const [emoji, setEmoji] = useState<Record<string, unknown>>({ mood: "", matrix: [] });
  const [subject, setSubject] = useState<string>("");
  const [course, setCourse] = useState<string>("");
  const [context, setContext] = useState<string>("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [success, setSuccess] = useState<string>("");

  const { enqueue, syncing } = useFeedbackQueue();

  const canSubmit = useMemo(() => {
    return !!feedbackType && (rating > 0 || text.trim().length > 5);
  }, [feedbackType, rating, text]);

  const submitOnline = async (payload: FeedbackPayload) => {
    const res = await fetch("/api/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      throw new Error(j.error || "Failed to submit feedback");
    }
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!canSubmit) {
      setError("Please provide a rating or write a few words.");
      return;
    }

    const payload: FeedbackPayload = {
      feedbackType,
      rating, text,
      mcqAnswers: mcq,
      emojiMatrix: emoji,
      subject: subject || undefined,
      course: course || undefined,
      context: context || undefined
    };

    setLoading(true);
    try {
      if (navigator.onLine) {
        await submitOnline(payload);
        setSuccess("Thanks! Your feedback was submitted.");
      } else {
        enqueue(payload);
        setSuccess("You are offline. Saved locally and will sync automatically once you are online.");
      }
      // reset minimal fields
      setRating(0);
      setText("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const emojiOptions = ["😞","😐","🙂","😃","🤩"];

  return (
    <section className="w-full">
      <motion.div initial={{opacity:0, y:20}} animate={{opacity:1,y:0}} transition={{duration:0.5}} className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white/20 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-medium text-slate-900">Share Your Feedback</h2>
            <p className="text-sm text-slate-600">Help us improve courses, teaching, and the portal experience.</p>
          </div>
          <div className="text-xs text-slate-500">{syncing ? 'Syncing…' : 'Offline sync ready'}</div>
        </div>

        <form onSubmit={onSubmit} className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-slate-700 mb-1">Feedback Type</label>
            <select value={feedbackType} onChange={(e)=>setFeedbackType(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:border-transparent">
              <option value="course">Course</option>
              <option value="teaching">Teaching Quality</option>
              <option value="website">Website Usability</option>
              <option value="services">Services/Facilities</option>
              <option value="general">General</option>
            </select>
          </div>

          <div className="grid grid-cols-5 gap-1">
            <label className="col-span-5 block text-sm text-slate-700 mb-1">Star Rating</label>
            {[1,2,3,4,5].map((n) => (
              <button key={n} type="button" aria-label={`Rate ${n}`} onClick={()=>setRating(n)} className="p-2 rounded hover:bg-slate-100">
                <Icon icon={n <= rating ? 'mdi:star' : 'mdi:star-outline'} className={`text-xl ${n <= rating ? 'text-amber-500' : 'text-slate-400'}`} />
              </button>
            ))}
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm text-slate-700 mb-1">Tell us more</label>
            <textarea value={text} onChange={(e)=>setText(e.target.value)} rows={4} placeholder="What worked well? What could be better?" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:border-transparent" />
          </div>

          <div>
            <label className="block text-sm text-slate-700 mb-1">Would you recommend this course?</label>
            <div className="flex gap-3 text-sm">
              {['Yes','No','Maybe'].map((opt)=> (
                <label key={opt} className={`px-3 py-1.5 rounded-lg border cursor-pointer ${mcq.q1===opt? 'bg-teal-600 text-white border-teal-600':'border-slate-300 text-slate-700'}`}> 
                  <input type="radio" name="q1" value={opt} className="hidden" onChange={()=>setMcq({...mcq, q1: opt})} />
                  <span>{opt}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm text-slate-700 mb-1">How satisfied are you overall?</label>
            <div className="flex items-center gap-2">
              {emojiOptions.map((eji)=> (
                <button key={eji} type="button" onClick={()=>setEmoji({ ...emoji, mood: eji })} className={`text-xl hover:scale-110 transition-transform ${emoji.mood===eji? 'opacity-100':'opacity-60'}`}>
                  <span aria-label="emoji">{eji}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm text-slate-700 mb-1">Subject (optional)</label>
            <input value={subject} onChange={(e)=>setSubject(e.target.value)} placeholder="e.g., Mathematics" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:border-transparent" />
          </div>
          <div>
            <label className="block text-sm text-slate-700 mb-1">Course/Context (optional)</label>
            <input value={course} onChange={(e)=>setCourse(e.target.value)} placeholder="e.g., Algebra II / Mobile UI" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:border-transparent" />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm text-slate-700 mb-1">Additional context (optional)</label>
            <input value={context} onChange={(e)=>setContext(e.target.value)} placeholder="Anything else you'd like us to know" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:border-transparent" />
          </div>

          {error && <div className="md:col-span-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">{error}</div>}
          {success && <div className="md:col-span-2 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm">{success}</div>}

          <div className="md:col-span-2 flex items-center justify-end gap-3">
            <button type="submit" disabled={!canSubmit || loading} className="px-4 py-2 rounded-lg bg-slate-900 text-white text-sm disabled:opacity-50">
              {loading ? 'Submitting…' : 'Submit Feedback'}
            </button>
          </div>
        </form>
      </motion.div>
    </section>
  );
}
