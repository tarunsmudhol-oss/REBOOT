"use client";

import React from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react";
import Link from "next/link";

export type AssignmentStatus = "pending" | "submitted" | "graded" | "overdue";

export interface AttachmentMeta { name: string; url: string; type: string }

export interface AssignmentItem {
  id: string;
  title: string;
  subject: string;
  dueAt: string; // ISO
  status: AssignmentStatus;
  description?: string;
  attachments?: AttachmentMeta[];
}

function timeRemaining(dueIso: string): { label: string; overdue: boolean } {
  const now = new Date();
  const due = new Date(dueIso);
  const diff = due.getTime() - now.getTime();
  if (diff <= 0) return { label: "Past due", overdue: true };
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  if (days > 0) return { label: `${days}d ${hours}h left`, overdue: false };
  if (hours > 0) return { label: `${hours}h ${mins}m left`, overdue: false };
  return { label: `${mins}m left`, overdue: false };
}

function statusColor(status: AssignmentStatus): string {
  switch (status) {
    case "pending":
      return "text-amber-600";
    case "submitted":
      return "text-blue-600";
    case "graded":
      return "text-green-600";
    case "overdue":
      return "text-red-600";
    default:
      return "text-slate-600";
  }
}

export default function AssignmentCard({ item }: { item: AssignmentItem }) {
  const { label, overdue } = timeRemaining(item.dueAt);
  const status = overdue && item.status === "pending" ? "overdue" : item.status;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3 }}
      className="bg-white/80 backdrop-blur-sm border border-white/30 rounded-xl p-4 flex flex-col gap-3"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-slate-900 text-sm font-medium">{item.title}</h3>
          <p className="text-xs text-slate-500 mt-0.5">{item.subject}</p>
        </div>
        <span className={`text-xs px-2 py-1 rounded-full bg-slate-100 ${statusColor(status)}`}>
          {status}
        </span>
      </div>

      <div className="flex items-center gap-2 text-xs text-slate-600">
        <Icon icon="mdi:calendar-clock" />
        <p>Due: {new Date(item.dueAt).toLocaleString()}</p>
        <span className="mx-1">•</span>
        <Icon icon="mdi:timer" />
        <p>{label}</p>
      </div>

      {item.attachments && item.attachments.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-1">
          {item.attachments.slice(0, 3).map((a) => (
            <a key={a.url} href={a.url} target="_blank" rel="noreferrer" className="text-xs px-2 py-1 rounded bg-slate-100 text-slate-700 hover:bg-slate-200 transition">
              <span>{a.name}</span>
            </a>
          ))}
          {item.attachments.length > 3 && <span className="text-xs text-slate-500">+{item.attachments.length - 3} more</span>}
        </div>
      )}

      <div className="flex items-center gap-2 mt-1">
        <Link href={`/student-dashboard/assignments/${item.id}`} className="px-3 py-1.5 text-xs rounded-lg bg-slate-900 text-white">View</Link>
        <Link href={`/student-dashboard/assignments/${item.id}?submit=true`} className="px-3 py-1.5 text-xs rounded-lg bg-blue-600 text-white">Submit</Link>
      </div>
    </motion.div>
  );
}
