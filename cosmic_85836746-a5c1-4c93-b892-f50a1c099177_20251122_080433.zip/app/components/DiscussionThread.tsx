"use client";

import React, { useEffect, useRef, useState } from "react";

interface MessageItem { id: string; senderId: string; text: string; createdAt?: string }

export default function DiscussionThread({ assignmentId }: { assignmentId: string }) {
  const [messages, setMessages] = useState<MessageItem[]>([]);
  const [input, setInput] = useState<string>("");
  const [busy, setBusy] = useState<boolean>(false);
  const listRef = useRef<HTMLDivElement | null>(null);

  const load = async () => {
    try {
      const r = await fetch(`/api/assignments/threads?assignmentId=${assignmentId}`, { cache: "no-store" });
      const j = await r.json();
      if (r.ok && Array.isArray(j.items)) setMessages(j.items);
    } catch {
      // noop
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 10000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    if (!input.trim()) return;
    setBusy(true);
    try {
      const r = await fetch("/api/assignments/threads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assignmentId, text: input.trim() })
      });
      if (r.ok) {
        setInput("");
        load();
      }
    } catch {
      // noop
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm border border-white/30 rounded-xl p-4">
      <h4 className="text-slate-900 text-sm font-medium mb-2">Discussion</h4>
      <div ref={listRef} className="h-48 overflow-y-auto bg-white border border-slate-200 rounded p-2 space-y-2">
        {messages.length === 0 && <p className="text-xs text-slate-500">No messages yet.</p>}
        {messages.map((m) => (
          <div key={m.id} className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1">
            <p className="text-slate-800">{m.text}</p>
          </div>
        ))}
      </div>
      <div className="mt-2 flex items-center gap-2">
        <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Ask a question or share a note" className="flex-1 text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
        <button onClick={send} disabled={busy} className="px-3 py-1.5 text-xs rounded-lg bg-slate-900 text-white disabled:opacity-50">Send</button>
      </div>
    </div>
  );
}
