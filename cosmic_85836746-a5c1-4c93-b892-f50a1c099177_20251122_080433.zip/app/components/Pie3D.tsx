"use client";

import React, { useMemo } from "react";
import { Canvas } from "@react-three/fiber";
import * as THREE from "three";
import { OrbitControls } from "@react-three/drei";

export interface PieSlice {
  label: string;
  value: number; // percentage out of 100 sum
  color: string; // hex color
}

interface Pie3DProps {
  slices: PieSlice[];
  height?: number; // thickness
  radius?: number;
}

function Wedge({ start, end, radius, height, color }: { start: number; end: number; radius: number; height: number; color: string }) {
  const geometry = useMemo(() => {
    const shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.absarc(0, 0, radius, start, end, false);
    shape.lineTo(0, 0);

    const extrudeSettings: THREE.ExtrudeGeometryOptions = {
      depth: height,
      bevelEnabled: false,
      curveSegments: 48
    };

    const geom = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    // Rotate so depth goes upward
    geom.rotateX(Math.PI / 2);
    return geom;
  }, [start, end, radius, height]);

  return (
    <mesh geometry={geometry} position={[0, height / 2, 0]}>
      <meshStandardMaterial color={color} metalness={0.15} roughness={0.4} />
    </mesh>
  );
}

export default function Pie3D({ slices, height = 0.4, radius = 2.4 }: Pie3DProps) {
  const total = Math.max(1, slices.reduce((sum, s) => sum + s.value, 0));
  let current = -Math.PI / 2; // start at top

  const wedges = slices.map((s, i) => {
    const angle = (s.value / total) * Math.PI * 2;
    const start = current;
    const end = current + angle;
    current = end;
    return { start, end, color: s.color, key: `${s.label}-${i}` };
  });

  return (
    <div className="w-full h-64 rounded-xl overflow-hidden bg-white/70 border border-white/20">
      <Canvas camera={{ position: [4, 3.2, 4], fov: 45 }} shadows>
        <ambientLight intensity={0.6} />
        <directionalLight position={[5, 8, 5]} intensity={0.8} castShadow />
        <group rotation={[-0.35, 0, 0]}>
          {/* Base shadow */}
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
            <circleGeometry args={[radius + 0.2, 64]} />
            <meshStandardMaterial color="#e5e7eb" />
          </mesh>
          {wedges.map((w) => (
            <Wedge key={w.key} start={w.start} end={w.end} radius={radius} height={height} color={w.color} />
          ))}
        </group>
        <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={1.2} enablePan={false} />
      </Canvas>
    </div>
  );
}
