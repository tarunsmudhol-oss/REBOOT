"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, ThreeEvent, useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import * as THREE from "three";

export type Mood = "rising" | "steady" | "falling";

interface CognitiveNode {
  id: string;
  label: string;
  mastery: number; // 0..1
  completed?: boolean;
}

interface LearningSphereProps {
  cognitive?: CognitiveNode[];
  mood?: Mood;
  nextTargetId?: string;
  onNodeClick?: (nodeId: string) => void;
  reducedMotion?: boolean;
}

function fibonacciSphere(count: number, radius: number): THREE.Vector3[] {
  const points: THREE.Vector3[] = [];
  const offset = 2 / count;
  const increment = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < count; i += 1) {
    const y = i * offset - 1 + offset / 2;
    const r = Math.sqrt(1 - y * y);
    const phi = i * increment;
    const x = Math.cos(phi) * r;
    const z = Math.sin(phi) * r;
    points.push(new THREE.Vector3(x * radius, y * radius, z * radius));
  }
  return points;
}

function Nodes({ positions, colors, sizes, mood, hoveredIndex, setHoveredIndex, onClickId, ids, reducedMotion }: {
  positions: THREE.Vector3[];
  colors: THREE.Color[];
  sizes: number[];
  mood: Mood;
  hoveredIndex: number | null;
  setHoveredIndex: (idx: number | null) => void;
  onClickId?: (id: string) => void;
  ids: string[];
  reducedMotion?: boolean;
}) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const temp = useMemo(() => new THREE.Object3D(), []);
  const colorAttr = useRef<THREE.InstancedBufferAttribute | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    const mesh = ref.current;
    const colorsArray = new Float32Array(positions.length * 3);
    colors.forEach((c, i) => {
      colorsArray[i * 3] = c.r;
      colorsArray[i * 3 + 1] = c.g;
      colorsArray[i * 3 + 2] = c.b;
    });
    colorAttr.current = new THREE.InstancedBufferAttribute(colorsArray, 3);
    mesh.geometry.setAttribute("instanceColor", colorAttr.current);
  }, [positions.length, colors]);

  useFrame(({ clock }) => {
    if (!ref.current) return;
    const t = clock.getElapsedTime();
    for (let i = 0; i < positions.length; i += 1) {
      const p = positions[i];
      temp.position.set(p.x, p.y, p.z);
      const baseScale = sizes[i];
      const pulse = Math.sin(t * (0.6 + (i % 5) * 0.05)) * 0.03;
      const scale = baseScale + (hoveredIndex === i ? 0.1 : 0) + (reducedMotion ? 0 : pulse);
      temp.scale.setScalar(scale);
      temp.lookAt(0, 0, 0);
      temp.updateMatrix();
      ref.current.setMatrixAt(i, temp.matrix);
    }
    ref.current.instanceMatrix.needsUpdate = true;
  });

  const handlePointerMove = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    const instanceId = (e.instanceId ?? null) as number | null;
    setHoveredIndex(instanceId);
    document.body.style.cursor = instanceId !== null ? "pointer" : "default";
  };

  const handlePointerOut = () => {
    setHoveredIndex(null);
    document.body.style.cursor = "default";
  };

  const handleClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    const instanceId = (e.instanceId ?? null) as number | null;
    if (instanceId !== null && onClickId) {
      onClickId(ids[instanceId]);
    }
  };

  // A subtle emissive material that feels glassy
  const mat = useMemo(() => new THREE.MeshPhysicalMaterial({
    transparent: true,
    opacity: 0.95,
    roughness: 0.25,
    metalness: 0.1,
    transmission: 0.6,
    thickness: 0.6,
    emissive: new THREE.Color(0x0a1a2f),
    emissiveIntensity: mood === "rising" ? 0.6 : mood === "steady" ? 0.35 : 0.18,
    color: new THREE.Color(0x98e2ff)
  }), [mood]);

  return (
    <instancedMesh
      ref={ref}
      args={[undefined as unknown as THREE.BufferGeometry, undefined as unknown as THREE.Material, positions.length]}
      onPointerMove={handlePointerMove}
      onPointerOut={handlePointerOut}
      onClick={handleClick}
    >
      <sphereGeometry args={[1, 16, 16]} />
      <primitive object={mat as unknown as THREE.Material} attach="material" />
    </instancedMesh>
  );
}

function GuidanceBeam({ target }: { target: THREE.Vector3 | null }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame(({ clock }) => {
    if (!ref.current || !target) return;
    const t = clock.getElapsedTime();
    (ref.current.material as THREE.MeshBasicMaterial).opacity = 0.5 + Math.sin(t * 4) * 0.25;
  });
  if (!target) return null;
  const height = 2.5;
  const pos = target.clone();
  const beamTop = pos.clone();
  beamTop.y += height / 2;
  return (
    <mesh ref={ref} position={[pos.x, pos.y + height / 2, pos.z]}>
      <cylinderGeometry args={[0.015, 0.015, height, 16]} />
      <meshBasicMaterial color={0x7dd3fc} transparent opacity={0.6} />
    </mesh>
  );
}

function SphereShell({ mood }: { mood: Mood }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame(({ clock }) => {
    if (!ref.current) return;
    const t = clock.getElapsedTime();
    ref.current.rotation.y = t * (mood === "rising" ? 0.12 : mood === "steady" ? 0.06 : 0.02);
  });
  return (
    <mesh ref={ref}>
      <sphereGeometry args={[1.85, 64, 64]} />
      <meshPhysicalMaterial
        transparent
        opacity={0.18}
        roughness={0.2}
        metalness={0.1}
        transmission={0.9}
        thickness={1.2}
        color={new THREE.Color(0x94a3b8)}
      />
    </mesh>
  );
}

export default function LearningSphere({ cognitive, mood = "steady", nextTargetId, onNodeClick, reducedMotion }: LearningSphereProps) {
  const nodes: CognitiveNode[] = useMemo(() => {
    if (cognitive && cognitive.length > 0) return cognitive;
    // fallback demo nodes
    return Array.from({ length: 60 }).map((_, i) => ({
      id: `n${i}`,
      label: `Concept ${i + 1}`,
      mastery: Math.max(0.05, Math.min(1, (Math.sin(i * 1.7) + 1) / 2)),
      completed: i % 11 === 0
    }));
  }, [cognitive]);

  const radius = 1.4;
  const pos = useMemo(() => fibonacciSphere(nodes.length, radius), [nodes.length]);
  const ids = useMemo(() => nodes.map((n) => n.id), [nodes]);
  const sizes = useMemo(() => nodes.map((n) => 0.08 + n.mastery * 0.08), [nodes]);
  const colors = useMemo(() => nodes.map((n) => new THREE.Color().setHSL(0.55 + n.mastery * 0.15, 0.65, 0.55 + n.mastery * 0.2)), [nodes]);

  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [clickedId, setClickedId] = useState<string | null>(null);

  const nextTarget = useMemo(() => {
    if (!nextTargetId) return null;
    const idx = ids.indexOf(nextTargetId);
    return idx >= 0 ? pos[idx] : null;
  }, [nextTargetId, ids, pos]);

  // Tooltip overlay
  const [tooltip, setTooltip] = useState<{ x: number; y: number; text: string; ring: number } | null>(null);
  useEffect(() => {
    const handler = (ev: MouseEvent) => {
      if (hoveredIndex === null) {
        setTooltip(null);
        return;
      }
      const node = nodes[hoveredIndex];
      setTooltip({ x: ev.clientX + 12, y: ev.clientY + 12, text: `${node.label}`, ring: Math.round(node.mastery * 100) });
    };
    window.addEventListener("mousemove", handler);
    return () => window.removeEventListener("mousemove", handler);
  }, [hoveredIndex, nodes]);

  const handleClickId = (id: string) => {
    setClickedId((prev) => (prev === id ? null : id));
    onNodeClick?.(id);
  };

  const prefersReduced = reducedMotion || (typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);

  return (
    <div className="relative w-full h-[420px] rounded-2xl overflow-hidden border border-white/20 bg-gradient-to-b from-slate-900 via-slate-950 to-black">
      <Canvas camera={{ position: [0, 0, 4.2], fov: 50 }} dpr={[1, 2]}>
        <ambientLight intensity={mood === "rising" ? 0.7 : mood === "steady" ? 0.5 : 0.28} />
        <directionalLight position={[3, 4, 2]} intensity={0.9} color={0x7dd3fc} />
        <group>
          <SphereShell mood={mood} />
          <Nodes
            positions={pos}
            colors={colors}
            sizes={sizes}
            mood={mood}
            hoveredIndex={hoveredIndex}
            setHoveredIndex={setHoveredIndex}
            onClickId={handleClickId}
            ids={ids}
            reducedMotion={prefersReduced}
          />
          {nextTarget && <GuidanceBeam target={nextTarget} />}
          {/* Simple subtopic orbit for clicked node */}
          {clickedId && (() => {
            const idx = ids.indexOf(clickedId);
            if (idx < 0) return null;
            const center = pos[idx];
            const orbitRadius = 0.35;
            const count = 6;
            const geom = new THREE.SphereGeometry(0.03, 12, 12);
            const mat = new THREE.MeshBasicMaterial({ color: 0x67e8f9 });
            const arr: React.ReactElement[] = [];
            for (let i = 0; i < count; i += 1) {
              const angle = (i / count) * Math.PI * 2;
              const x = center.x + Math.cos(angle) * orbitRadius;
              const z = center.z + Math.sin(angle) * orbitRadius;
              arr.push(
                <mesh key={`orb-${i}`} position={[x, center.y, z]} geometry={geom} material={mat} />
              );
            }
            return arr;
          })()}
        </group>
        {!prefersReduced && <OrbitControls enablePan={false} enableZoom={false} autoRotate autoRotateSpeed={mood === "rising" ? 1.6 : mood === "steady" ? 0.9 : 0.3} />}
      </Canvas>
      {/* Overlay grad vignette to make it glassy */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
      {/* Tooltip */}
      {tooltip && (
        <div
          className="pointer-events-none absolute z-10 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 px-3 py-1.5 text-[11px] text-white"
          style={{ left: tooltip.x, top: tooltip.y }}
          aria-hidden="true"
        >
          <div className="flex items-center gap-2">
            <span className="opacity-90">{tooltip.text}</span>
            <span className="opacity-70">•</span>
            <span className="opacity-90">{tooltip.ring}%</span>
          </div>
        </div>
      )}
    </div>
  );
}
