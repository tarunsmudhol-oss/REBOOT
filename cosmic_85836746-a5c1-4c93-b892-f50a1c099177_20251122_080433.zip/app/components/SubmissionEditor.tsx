"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Icon } from "@iconify/react";

interface FileMeta { fileId: string; fileName: string; fileType: string; fileSize: number }
interface SubmissionItem {
  id: string;
  version: number;
  status: "draft" | "submitted" | "graded";
  textAnswer?: string;
  files?: FileMeta[];
  submittedAt?: string | null;
  createdAt?: string;
}

export default function SubmissionEditor({ assignmentId }: { assignmentId: string }) {
  const [text, setText] = useState<string>("");
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");
  const [history, setHistory] = useState<SubmissionItem[]>([]);

  const draftKey = useMemo(() => `draft:${assignmentId}`, [assignmentId]);

  useEffect(() => {
    const cached = localStorage.getItem(draftKey);
    if (cached) setText(cached);
    // Load history
    (async () => {
      try {
        const r = await fetch(`/api/assignments/submissions?assignmentId=${assignmentId}`, { cache: "no-store" });
        const j = await r.json();
        if (r.ok && Array.isArray(j.items)) setHistory(j.items);
      } catch {
        // noop
      }
    })();
  }, [assignmentId, draftKey]);

  useEffect(() => {
    const t = setTimeout(() => {
      localStorage.setItem(draftKey, text);
    }, 500);
    return () => clearTimeout(t);
  }, [text, draftKey]);

  const onDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    const list = Array.from(e.dataTransfer.files || []);
    setFiles((prev) => [...prev, ...list]);
  };

  const onPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = Array.from(e.target.files || []);
    setFiles((prev) => [...prev, ...list]);
  };

  const removeFile = (name: string) => setFiles((prev) => prev.filter((f) => f.name !== name));

  const saveDraft = async () => {
    setBusy(true);
    setMessage("");
    try {
      const r = await fetch("/api/assignments/submissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assignmentId, textAnswer: text, isFinal: false })
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Failed to save draft");
      setMessage(`Draft saved (v${j.version})`);
      localStorage.removeItem(draftKey);
      // refresh history
      const r2 = await fetch(`/api/assignments/submissions?assignmentId=${assignmentId}`, { cache: "no-store" });
      const j2 = await r2.json();
      if (r2.ok && Array.isArray(j2.items)) setHistory(j2.items);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Error saving draft");
    } finally {
      setBusy(false);
    }
  };

  const submitFinal = async () => {
    setBusy(true);
    setMessage("");
    try {
      const form = new FormData();
      form.set("assignmentId", assignmentId);
      form.set("textAnswer", text);
      form.set("isFinal", "true");
      for (const f of files) form.append("file", f, f.name);
      const r = await fetch("/api/assignments/submissions", { method: "POST", body: form });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Failed to submit");
      setMessage("Submitted successfully");
      setFiles([]);
      localStorage.removeItem(draftKey);
      const r2 = await fetch(`/api/assignments/submissions?assignmentId=${assignmentId}`, { cache: "no-store" });
      const j2 = await r2.json();
      if (r2.ok && Array.isArray(j2.items)) setHistory(j2.items);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Error submitting");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm border border-white/30 rounded-xl p-4">
      <h4 className="text-slate-900 text-sm font-medium mb-2">Submission</h4>
      {message && <p className="text-xs text-slate-700 mb-2">{message}</p>}

      <div className="mb-3">
        <label className="block text-xs text-slate-700 mb-1">Write your answer</label>
        <textarea value={text} onChange={(e) => setText(e.target.value)} rows={6} placeholder="Type here..." className="w-full text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
        <p className="text-[11px] text-slate-500 mt-1">Autosaves locally. Use Save Draft to sync to cloud.</p>
      </div>

      <div className="mb-3">
        <label onDragOver={(e) => e.preventDefault()} onDrop={onDrop} className="flex flex-col items-center justify-center text-xs gap-2 border border-dashed border-slate-300 rounded-lg p-4 cursor-pointer hover:bg-slate-50">
          <Icon icon="mdi:tray-arrow-up" className="text-slate-600" />
          <p className="text-slate-700">Drag & drop files, or click to browse</p>
          <input type="file" multiple onChange={onPick} className="hidden" />
        </label>
        {files.length > 0 && (
          <ul className="mt-2 space-y-1">
            {files.map((f) => (
              <li key={f.name} className="flex items-center justify-between text-xs text-slate-700 bg-slate-50 rounded px-2 py-1">
                <span>{f.name}</span>
                <button onClick={() => removeFile(f.name)} className="text-slate-500 hover:text-slate-800">Remove</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="flex items-center gap-2">
        <button onClick={saveDraft} disabled={busy} className="px-3 py-1.5 text-xs rounded-lg bg-slate-100 text-slate-800 disabled:opacity-50">Save Draft</button>
        <button onClick={submitFinal} disabled={busy} className="px-3 py-1.5 text-xs rounded-lg bg-blue-600 text-white disabled:opacity-50">Submit Final</button>
      </div>

      {history.length > 0 && (
        <div className="mt-4">
          <h5 className="text-xs text-slate-900 font-medium mb-1">Submission History</h5>
          <div className="space-y-1">
            {history.map((h) => (
              <div key={h.id} className="text-xs text-slate-700 bg-white border border-slate-200 rounded px-2 py-1 flex items-center justify-between">
                <span>v{String(h.version)} • {h.status}</span>
                {Array.isArray(h.files) && h.files.length > 0 && (
                  <div className="flex gap-2">
                    {h.files.map((fm) => (
                      <a key={fm.fileId} href={`/api/assignments/submissions/download?fileId=${encodeURIComponent(fm.fileId)}`} className="underline">{fm.fileName}</a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
