"use client";

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Icon } from "@iconify/react";

interface TeacherProfile {
  displayName: string;
  onboardingCompleted: boolean;
  subjects: string[];
  bio: string;
}

export default function TeacherOnboarding() {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<TeacherProfile | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const res = await fetch("/api/teacher", { cache: "no-store" });
        if (!res.ok) {
          setLoading(false);
          return;
        }
        const data = await res.json();
        if (!active) return;
        const pf = data?.profile as TeacherProfile | undefined;
        if (pf) {
          setProfile(pf);
          setOpen(!pf.onboardingCompleted);
        }
      } catch {
        // ignore
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, []);

  const completeOnboarding = async () => {
    try {
      setSaving(true);
      await fetch("/api/teacher", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ onboardingCompleted: true })
      });
      setOpen(false);
      setProfile((p) => p ? { ...p, onboardingCompleted: true } : p);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return null;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4"
          aria-modal="true"
          role="dialog"
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="w-full max-w-lg bg-white/95 border border-white/30 rounded-2xl p-6 shadow-xl"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                <Icon icon="mdi:account-tie" className="text-xl" />
              </div>
              <div>
                <h2 className="text-xl font-medium text-slate-900">Welcome, {profile?.displayName || "Teacher"}</h2>
                <p className="text-sm text-slate-600">Quick tour to get you set up in under a minute</p>
              </div>
            </div>

            <ul className="space-y-2 mb-4">
              <li className="flex items-start gap-2 text-sm text-slate-700">
                <Icon icon="mdi:check-circle-outline" className="text-emerald-600 mt-0.5" />
                <span>Lesson Plans — create, save, and share your objectives</span>
              </li>
              <li className="flex items-start gap-2 text-sm text-slate-700">
                <Icon icon="mdi:check-circle-outline" className="text-emerald-600 mt-0.5" />
                <span>Content Library — find resources and share with classes</span>
              </li>
              <li className="flex items-start gap-2 text-sm text-slate-700">
                <Icon icon="mdi:check-circle-outline" className="text-emerald-600 mt-0.5" />
                <span>Students — view progress, attendance, and insights</span>
              </li>
              <li className="flex items-start gap-2 text-sm text-slate-700">
                <Icon icon="mdi:check-circle-outline" className="text-emerald-600 mt-0.5" />
                <span>Grading — adjust scores and leave feedback quickly</span>
              </li>
            </ul>

            <div className="rounded-lg bg-emerald-50 border border-emerald-100 p-3 text-sm text-emerald-700 mb-4">
              Tip: You can revisit the full tour anytime from the header. <a href="#lesson-plans" className="underline">Jump to Lesson Plans</a>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button onClick={() => setOpen(false)} className="px-3 py-2 rounded-lg text-sm bg-slate-100">Maybe later</button>
              <button onClick={completeOnboarding} disabled={saving} className="px-3 py-2 rounded-lg text-sm bg-slate-900 text-white disabled:opacity-60">
                {saving ? 'Finishing…' : 'Start my tour'}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
