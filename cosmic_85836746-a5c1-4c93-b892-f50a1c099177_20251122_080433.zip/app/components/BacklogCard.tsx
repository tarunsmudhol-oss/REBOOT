"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react";

export type BacklogStatus = "red" | "yellow" | "green";

export interface BacklogItem {
  id: string;
  topic: string;
  status: BacklogStatus;
  notes?: string;
}

interface BacklogCardProps {
  title: string;
  hue: BacklogStatus; // controls colors
  items: BacklogItem[];
  onMove: (id: string, to: BacklogStatus) => Promise<void>;
  onEditNotes: (id: string, notes: string) => Promise<void>;
  onDelete?: (id: string) => Promise<void>;
}

export default function BacklogCard({ title, hue, items, onMove, onEditNotes, onDelete }: BacklogCardProps) {
  const [expanded, setExpanded] = useState(true);
  const [savingId, setSavingId] = useState<string>("");

  const colorClass =
    hue === "red" ? "border-red-200 bg-red-50/60" : hue === "yellow" ? "border-yellow-200 bg-yellow-50/60" : "border-green-200 bg-green-50/60";
  const pillClass =
    hue === "red"
      ? "bg-red-600 text-white"
      : hue === "yellow"
      ? "bg-amber-500 text-white"
      : "bg-green-600 text-white";

  const toLabel = (s: BacklogStatus) => (s === "red" ? "Very Important" : s === "yellow" ? "Practice Often" : "Good • Revision");

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className={`rounded-xl border ${colorClass}`}>
      <button
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center justify-between px-4 py-3 rounded-t-xl"
        aria-expanded={expanded}
        aria-controls={`panel-${hue}`}
      >
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center px-2 py-1 text-xs rounded ${pillClass}`}>{toLabel(hue)}</span>
          <p className="text-sm text-slate-800">{title}</p>
        </div>
        <div className="flex items-center gap-2 text-slate-500 text-xs">
          <span>{items.length}</span>
          <Icon icon={expanded ? "mdi:chevron-up" : "mdi:chevron-down"} />
        </div>
      </button>
      {expanded && (
        <div id={`panel-${hue}`} className="px-4 pb-4 space-y-3">
          {items.length === 0 ? (
            <p className="text-xs text-slate-500">No topics here yet.</p>
          ) : (
            items.map((it) => (
              <div key={it.id} className="bg-white/80 backdrop-blur-sm border border-white/30 rounded-lg p-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm text-slate-900">{it.topic}</p>
                    <label className="block text-xs text-slate-500 mt-1" htmlFor={`notes-${it.id}`}>Notes</label>
                    <textarea
                      id={`notes-${it.id}`}
                      className="w-full mt-1 text-xs rounded border border-slate-200 p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Add a short note"
                      defaultValue={it.notes || ""}
                      onBlur={async (e) => {
                        const val = e.target.value;
                        if (val !== (it.notes || "")) {
                          setSavingId(it.id);
                          await onEditNotes(it.id, val);
                          setSavingId("");
                        }
                      }}
                    />
                  </div>
                  <div className="flex flex-col items-end gap-2 min-w-[120px]">
                    <div className="flex gap-1">
                      <button
                        onClick={async () => {
                          if (hue !== "red") {
                            setSavingId(it.id);
                            await onMove(it.id, "red");
                            setSavingId("");
                          }
                        }}
                        className={`px-2 py-1 rounded text-xs ${hue === "red" ? "bg-red-600 text-white" : "bg-red-100 text-red-700"}`}
                        aria-label="Move to Very Important"
                      >
                        Red
                      </button>
                      <button
                        onClick={async () => {
                          if (hue !== "yellow") {
                            setSavingId(it.id);
                            await onMove(it.id, "yellow");
                            setSavingId("");
                          }
                        }}
                        className={`px-2 py-1 rounded text-xs ${hue === "yellow" ? "bg-amber-500 text-white" : "bg-amber-100 text-amber-700"}`}
                        aria-label="Move to Practice Often"
                      >
                        Yellow
                      </button>
                      <button
                        onClick={async () => {
                          if (hue !== "green") {
                            setSavingId(it.id);
                            await onMove(it.id, "green");
                            setSavingId("");
                          }
                        }}
                        className={`px-2 py-1 rounded text-xs ${hue === "green" ? "bg-green-600 text-white" : "bg-green-100 text-green-700"}`}
                        aria-label="Move to Revision"
                      >
                        Green
                      </button>
                    </div>
                    {onDelete && (
                      <button
                        onClick={async () => {
                          setSavingId(it.id);
                          await onDelete(it.id);
                          setSavingId("");
                        }}
                        className="px-2 py-1 rounded text-xs bg-slate-100 text-slate-700 hover:bg-slate-200"
                        aria-label="Delete topic"
                      >
                        <span className="inline-flex items-center gap-1"><Icon icon="mdi:trash-can-outline" className="text-sm" /> Delete</span>
                      </button>
                    )}
                    {savingId === it.id && <span className="text-[10px] text-slate-500">Saving...</span>}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </motion.div>
  );
}
