'use client';

import React, { useEffect, useMemo, useState } from "react";
import { Icon } from "@iconify/react";

interface GuardianRecord {
  guardianName: string;
  guardianEmail: string;
  childDob: string; // ISO string
  isVerified: boolean;
  verificationTimestamp?: string | null;
  associatedChildUid?: string | null;
}

function calculateAge(dobIso: string): number {
  if (!dobIso) return 0;
  const today = new Date();
  const birthDate = new Date(dobIso);
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age -= 1;
  }
  return age;
}

export default function GuardianIntakeForm() {
  const [form, setForm] = useState<GuardianRecord>({
    guardianName: "",
    guardianEmail: "",
    childDob: "",
    isVerified: false,
    verificationTimestamp: null,
    associatedChildUid: null
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string>("");
  const [error, setError] = useState<string>("");

  const childAge = useMemo(() => calculateAge(form.childDob), [form.childDob]);
  const under14 = childAge > 0 && childAge < 14;

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch('/api/parents-guardians', { cache: 'no-store' });
        if (!res.ok) return;
        const data = await res.json();
        if (data && data.exists) {
          setForm({
            guardianName: data.guardianName || '',
            guardianEmail: data.guardianEmail || '',
            childDob: data.childDob || '',
            isVerified: Boolean(data.isVerified),
            verificationTimestamp: data.verificationTimestamp || null,
            associatedChildUid: data.associatedChildUid || null
          });
        }
      } catch {
        // ignore
      }
    };
    load();
  }, []);

  const save = async () => {
    setLoading(true);
    setError("");
    setMessage("");
    try {
      const res = await fetch('/api/parents-guardians', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guardianName: form.guardianName,
          guardianEmail: form.guardianEmail,
          childDob: form.childDob,
          associatedChildUid: form.associatedChildUid || null
        })
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Failed to save');
      } else {
        setMessage('Saved');
      }
    } catch {
      setError('Failed to save');
    } finally {
      setLoading(false);
    }
  };

  const verify = async () => {
    setLoading(true);
    setError("");
    setMessage("");
    try {
      const res = await fetch('/api/parents-guardians/verify', {
        method: 'POST'
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Verification failed');
      } else {
        setForm(prev => ({ ...prev, isVerified: true }));
        setMessage('Access verified');
      }
    } catch {
      setError('Verification failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="max-w-5xl mx-auto px-4 md:px-6 mt-8">
      {under14 && (
        <div className="mb-4 rounded-md border border-yellow-300 bg-yellow-50 text-yellow-900 p-3 text-sm">
          <p>Access is restricted. The associated child must be 14 or older.</p>
        </div>
      )}
      <div className="bg-white border border-slate-200 rounded-lg p-4 md:p-6">
        <h2 className="text-base md:text-lg font-medium text-slate-900 mb-4">Guardian Intake</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="flex flex-col text-sm">
            <span className="text-slate-700 mb-1">Parent/Guardian name</span>
            <input
              value={form.guardianName}
              onChange={(e) => setForm(f => ({ ...f, guardianName: e.target.value }))}
              className="h-9 rounded-md border border-slate-300 px-3 text-slate-900"
              placeholder="Enter full name"
            />
          </label>
          <label className="flex flex-col text-sm">
            <span className="text-slate-700 mb-1">Registered email</span>
            <input
              value={form.guardianEmail}
              onChange={(e) => setForm(f => ({ ...f, guardianEmail: e.target.value }))}
              className="h-9 rounded-md border border-slate-300 px-3 text-slate-900"
              type="email"
              placeholder="name@example.com"
            />
          </label>
          <label className="flex flex-col text-sm">
            <span className="text-slate-700 mb-1">Child’s date of birth</span>
            <input
              value={form.childDob}
              onChange={(e) => setForm(f => ({ ...f, childDob: e.target.value }))}
              className="h-9 rounded-md border border-slate-300 px-3 text-slate-900"
              type="date"
            />
          </label>
          <label className="flex items-center gap-2 text-sm mt-6 md:mt-0">
            <input
              type="checkbox"
              checked
              readOnly
              className="h-4 w-4 rounded border-slate-300"
            />
            <span>I confirm I am the child’s parent/guardian.</span>
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-3 mt-4">
          <button
            type="button"
            onClick={save}
            disabled={loading}
            className="h-9 px-4 rounded-md bg-slate-900 text-white text-sm disabled:opacity-60"
          >
            {loading ? 'Saving...' : 'Save Details'}
          </button>
          <button
            type="button"
            onClick={verify}
            disabled={loading || under14}
            className="h-9 px-4 rounded-md bg-slate-100 text-slate-900 border border-slate-300 text-sm disabled:opacity-60"
          >
            Verify Access
          </button>
          <button
            type="button"
            disabled
            className="h-9 px-4 rounded-md bg-slate-100 text-slate-500 border border-slate-300 text-sm"
          >
            <span className="inline-flex items-center gap-1"><Icon icon="mdi:message-badge-outline" /> Send OTP</span>
          </button>
          <span className="text-xs text-slate-500">Verification is visual-only for demo; no OTP is required.</span>
        </div>

        {(message || error) && (
          <div className={`mt-4 text-sm ${error ? 'text-red-600' : 'text-green-600'}`}>
            <p>{error || message}</p>
          </div>
        )}

        <div className="mt-4 text-xs text-slate-500">
          <p>Status: {form.isVerified ? 'Verified' : 'Not verified'}</p>
          {form.childDob && <p>Child age: {childAge} years</p>}
        </div>
      </div>
    </section>
  );
}
