"use client";

import { motion } from "framer-motion";
import React from "react";
import { cn } from "@/lib/utils";

interface PerformanceCardProps {
  title: string;
  emoji?: string;
  children: React.ReactNode;
  className?: string;
}

export default function PerformanceCard({ title, emoji, children, className = "" }: PerformanceCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.5 }}
      className={cn("bg-white/85 backdrop-blur-sm rounded-xl border border-white/30 p-5", className)}
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-base font-medium text-slate-900 flex items-center gap-2">
          {emoji && (
            <motion.span
              initial={{ rotate: -10 }}
              animate={{ rotate: 0 }}
              transition={{ type: "spring", stiffness: 160, damping: 10 }}
              aria-hidden="true"
            >
              {emoji}
            </motion.span>
          )}
          <span>{title}</span>
        </h3>
      </div>
      <div className="text-sm text-slate-700">
        {children}
      </div>
    </motion.div>
  );
}
