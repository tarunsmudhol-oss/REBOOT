"use client";

import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import Pie3D from "@/app/components/Pie3D";

interface Stats {
  total: number;
  avgRating: number | null;
  countsByType: Record<string, number>;
  countsByRole: Record<string, number>;
  trendByDay: Record<string, number>;
}

export default function AnalyticsPanel() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const r = await fetch('/api/feedback/stats', { cache: 'no-store' });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'Failed to load stats');
      setStats(j as Stats);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const typeSlices = useMemo(() => {
    const entries = Object.entries(stats?.countsByType || {});
    if (entries.length === 0) return [] as Array<{ label: string; value: number; color: string }>;
    const palette = ['#2563eb','#06b6d4','#10b981','#f59e0b','#ef4444','#0ea5e9'];
    return entries.map(([label, value], i) => ({ label, value, color: palette[i % palette.length] }));
  }, [stats]);

  const trend = useMemo(() => {
    const t = stats?.trendByDay || {};
    return Object.keys(t).sort().slice(-14).map((day) => ({ day, value: t[day] }));
  }, [stats]);

  return (
    <section className="w-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium text-slate-900">Analytics</h2>
        <a href="/api/feedback/export" className="text-sm px-3 py-1.5 rounded bg-slate-900 text-white">Export CSV</a>
      </div>

      {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm mb-3">{error}</div>}

      {loading ? (
        <p className="text-sm text-slate-600">Loading…</p>
      ) : stats ? (
        <div className="grid lg:grid-cols-3 gap-6">
          <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{duration:0.5}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <p className="text-sm text-slate-600">Totals</p>
            <p className="text-2xl text-slate-900 mt-1">{stats.total}</p>
            <div className="mt-4">
              <p className="text-sm text-slate-600">Average Rating</p>
              <p className="text-xl text-amber-600">{stats.avgRating ?? '—'}</p>
            </div>
            <div className="mt-4">
              <p className="text-sm text-slate-600 mb-2">By Role</p>
              <div className="grid grid-cols-2 gap-2 text-sm">
                {Object.entries(stats.countsByRole || {}).map(([role, count]) => (
                  <div key={role} className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between">
                    <span className="capitalize text-slate-800">{role}</span>
                    <span className="text-slate-600">{count}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{duration:0.5, delay:0.1}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <p className="text-sm text-slate-600 mb-3">Categories</p>
            <Pie3D slices={typeSlices} />
          </motion.div>

          <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{duration:0.5, delay:0.2}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <p className="text-sm text-slate-600 mb-3">Last 14 days</p>
            <div className="flex items-end gap-1 h-40">
              {trend.map((pt) => (
                <div key={pt.day} title={`${pt.day}: ${pt.value}`} className="flex-1">
                  <div style={{height: Math.min(100, pt.value * 10) + '%'}} className="w-full bg-teal-500/70 rounded-t" />
                  <p className="text-[10px] text-slate-500 text-center mt-1">{pt.day.slice(5)}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      ) : null}
    </section>
  );
}
