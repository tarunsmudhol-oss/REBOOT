"use client";

import { motion } from "framer-motion";

export default function PerformanceHero() {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-teal-50 via-white to-blue-50 border border-white/30 p-8 mb-8">
      <motion.h1
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-3xl md:text-4xl font-medium text-slate-900 tracking-tight"
      >
        <span className="inline-flex items-center gap-2">
          <motion.span
            initial={{ scale: 0.8, rotate: -6 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="inline-block px-3 py-1 rounded-lg bg-blue-600 text-white text-sm"
          >
            ✨
          </motion.span>
          <span>PERSONAL PERFORMANCE</span>
        </span>
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.25 }}
        className="mt-2 text-sm text-slate-600"
      >
        Keep going — small wins every day add up to big results. 📈
      </motion.p>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="absolute -right-6 -bottom-6 w-40 h-40 rounded-full bg-blue-200/40"
      />
    </div>
  );
}
