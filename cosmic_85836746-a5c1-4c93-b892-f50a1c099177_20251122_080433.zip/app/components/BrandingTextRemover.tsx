"use client";

import { useEffect } from "react";

function removePhraseFromText(text: string, regex: RegExp): string {
  return text.replace(regex, "").replace(/\s{2,}/g, " ").trim();
}

export default function BrandingTextRemover() {
  useEffect(() => {
    const phrase = /\b(?:built\s*with\s*cosmic)\b/gi;

    const scrubTextNode = (node: Node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        const current = node.textContent ?? "";
        if (phrase.test(current)) {
          node.textContent = removePhraseFromText(current, phrase);
        }
      }
    };

    const scrubElementAttributes = (el: Element) => {
      const attribs = ["title", "aria-label", "alt"] as const;
      attribs.forEach((name) => {
        const val = el.getAttribute(name);
        if (val && phrase.test(val)) {
          el.setAttribute(name, removePhraseFromText(val, phrase));
        }
      });
    };

    const scrubNodeDeep = (root: Node) => {
      if (root.nodeType === Node.TEXT_NODE) {
        scrubTextNode(root);
        return;
      }
      if (root.nodeType === Node.ELEMENT_NODE) {
        scrubElementAttributes(root as Element);
      }
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
      const textNodes: Node[] = [];
      // Collect first to avoid live updates changing traversal
      while (walker.nextNode()) {
        textNodes.push(walker.currentNode);
      }
      textNodes.forEach(scrubTextNode);
    };

    // Initial scrub across the document
    scrubNodeDeep(document.body);

    // Specifically target common badge containers to ensure we keep the badge visible
    const selectors = [
      "#cosmic-badge",
      '[id*="cosmic-badge"]',
      'a[href*="cosmic.new"]',
      'a[href*="cosmic"]'
    ];
    document.querySelectorAll(selectors.join(",")).forEach((el) => scrubNodeDeep(el));

    // Observe future insertions (e.g., async badge load)
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((n) => {
          scrubNodeDeep(n);
        });
        if (mutation.type === "attributes" && mutation.target) {
          scrubElementAttributes(mutation.target as Element);
        }
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["title", "aria-label", "alt"]
    });

    return () => observer.disconnect();
  }, []);

  return null;
}
