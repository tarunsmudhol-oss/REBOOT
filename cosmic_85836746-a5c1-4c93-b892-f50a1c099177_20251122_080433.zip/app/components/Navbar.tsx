"use client";

import React, { useState } from "react";
import { Icon } from "@iconify/react";
import { useAuth } from "cosmic-authentication";
import { Button } from "./Button";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isAuthenticated, user, signOut } = useAuth();

  const handleSignOut = () => {
    signOut();
  };

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-lg border-b border-slate-200/50",
      { "bg-slate-50/90": isMenuOpen }
    )}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-8 h-8 bg-blue-600 rounded-lg">
              <Icon icon="mdi:education" className="text-white text-lg" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-semibold text-slate-900">Smart Student Portal</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-slate-600 hover:text-slate-900 text-sm font-medium transition-colors">
              Features
            </a>
            <a href="#about" className="text-slate-600 hover:text-slate-900 text-sm font-medium transition-colors">
              About
            </a>
            <a href="#contact" className="text-slate-600 hover:text-slate-900 text-sm font-medium transition-colors">
              Contact
            </a>
          </div>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-3">
            {isAuthenticated ? (
              <div className="flex items-center space-x-3">
                <span className="text-sm text-slate-600">Welcome, {user?.displayName}</span>
                <Button variant="ghost" onClick={handleSignOut} size="sm">
                  Sign Out
                </Button>
              </div>
            ) : (
              <>
                <Button variant="ghost" size="sm">
                  Log In
                </Button>
                <Button variant="primary" size="sm">
                  Get Started
                </Button>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Icon 
              icon={isMenuOpen ? "mdi:close" : "mdi:menu"} 
              className="h-5 w-5" 
            />
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-slate-200/50">
            <div className="flex flex-col space-y-4">
              <a href="#features" className="text-slate-600 hover:text-slate-900 text-sm font-medium">
                Features
              </a>
              <a href="#about" className="text-slate-600 hover:text-slate-900 text-sm font-medium">
                About
              </a>
              <a href="#contact" className="text-slate-600 hover:text-slate-900 text-sm font-medium">
                Contact
              </a>
              {isAuthenticated ? (
                <div className="pt-4 border-t border-slate-200">
                  <p className="text-sm text-slate-600 mb-2">Welcome, {user?.displayName}</p>
                  <Button variant="ghost" onClick={handleSignOut} size="sm" className="w-full">
                    Sign Out
                  </Button>
                </div>
              ) : (
                <div className="pt-4 border-t border-slate-200 space-y-2">
                  <Button variant="ghost" size="sm" className="w-full">
                    Log In
                  </Button>
                  <Button variant="primary" size="sm" className="w-full">
                    Get Started
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}