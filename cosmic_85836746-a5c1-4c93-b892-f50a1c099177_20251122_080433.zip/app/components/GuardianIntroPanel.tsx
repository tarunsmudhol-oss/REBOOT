import React from "react";
import { Icon } from "@iconify/react";

export default function GuardianIntroPanel() {
  return (
    <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
      <div className="flex items-start gap-3 mb-2">
        <Icon aria-hidden icon="mdi:lock" className="text-slate-700 mt-[2px]" />
        <h1 className="text-2xl md:text-3xl font-medium text-slate-900">Parents / Guardians Zone</h1>
      </div>
      <p className="text-sm text-slate-600 mb-6">This area is only for parents or legal guardians. Students below 14 years are not allowed.</p>

      <div className="space-y-2 text-slate-700 text-sm">
        <p>To protect student data and privacy.</p>
        <p>To let parents track progress and see teacher feedback safely.</p>
        <p>To make sure guidance and reports go only to adults.</p>
      </div>

      <div role="note" aria-label="Age restriction notice" className="mt-6 rounded-md border border-yellow-300 bg-yellow-50 text-yellow-900 p-4 text-sm">
        <p>If you are under 14, please do not continue. Ask your parent or guardian to access this page.</p>
      </div>
    </section>
  );
}
