"use client";

import React from "react";
import { Icon } from "@iconify/react";
import { usePathname } from "next/navigation";
import Link from "next/link";

interface NavItem {
  icon: string;
  label: string;
  href: string;
}

export default function LeftNav() {
  const pathname = usePathname();
  const isGuardian = pathname?.startsWith("/parents-guardians-zone") ?? false;
  const isTeacher = pathname?.startsWith("/teacher-dashboard") ?? false;

  const studentItems: NavItem[] = [
    { icon: "mdi:clipboard-text-outline", label: "Assignments", href: "/student-dashboard/assignments" },
    { icon: "mdi:school-outline", label: "Learning Hub", href: "#assignments" },
    { icon: "mdi:chart-line", label: "Performance", href: "/student-dashboard/performance" },
    { icon: "mdi:account-tie", label: "Mentoring", href: "/student-portal/mentoring" },
    { icon: "mdi:clock-alert-outline", label: "Backlogs", href: "/student-portal/backlogs" },
    { icon: "mdi:robot-outline", label: "AI Assist", href: "/student-portal/ai-assist" },
    { icon: "mdi:message-text-outline", label: "Feedback", href: "/student-portal/feedback" }
  ];

  const guardianItems: NavItem[] = [
    { icon: "mdi:shield-lock-outline", label: "Guardians Zone", href: "/parents-guardians-zone" },
    { icon: "mdi:view-dashboard-outline", label: "Overview", href: "/parents-guardians-zone/dashboard" },
    { icon: "mdi:account-box-outline", label: "Profile & Reports", href: "/parents-guardians-zone/profile" },
    { icon: "mdi:clipboard-text-outline", label: "Assignments", href: "/parents-guardians-zone/assignments" },
    { icon: "mdi:emoticon-happy-outline", label: "Well-being", href: "/parents-guardians-zone/wellbeing" },
    { icon: "mdi:email-outline", label: "Communication", href: "/parents-guardians-zone/communication" },
    { icon: "mdi:cash-multiple", label: "Fees", href: "/parents-guardians-zone/fees" },
    { icon: "mdi:calendar-outline", label: "Events", href: "/parents-guardians-zone/events" },
    { icon: "mdi:book-open-outline", label: "Resources", href: "/parents-guardians-zone/resources" },
    { icon: "mdi:account-multiple-outline", label: "Multi-Child", href: "/parents-guardians-zone/multi-child" },
    { icon: "mdi:message-alert-outline", label: "Feedback & Support", href: "/parents-guardians-zone/feedback-support" },
    { icon: "mdi:lock-outline", label: "Privacy & Security", href: "/parents-guardians-zone/privacy-security" },
    { icon: "mdi:bell-outline", label: "Notifications", href: "/parents-guardians-zone/notifications" }
  ];

  const teacherItems: NavItem[] = [
    { icon: "mdi:book-open-variant", label: "Lesson Plans", href: "/teacher-dashboard#lesson-plans" },
    { icon: "mdi:library", label: "Content Library", href: "/teacher-dashboard#content-library" },
    { icon: "mdi:account-group-outline", label: "Students", href: "/teacher-dashboard#students" },
    { icon: "mdi:forum-outline", label: "Communication", href: "/teacher-dashboard#communication" },
    { icon: "mdi:clipboard-check-outline", label: "Grading", href: "/teacher-dashboard#grading" },
    { icon: "mdi:calendar-clock", label: "Schedule", href: "/teacher-dashboard#schedule" },
    { icon: "mdi:chart-bar-stacked", label: "Reports", href: "/teacher-dashboard#reports" },
    { icon: "mdi:folder-outline", label: "Resources", href: "/teacher-dashboard#resources" },
    { icon: "mdi:account-multiple-plus-outline", label: "Collaboration", href: "/teacher-dashboard#collaboration" },
    { icon: "mdi:book", label: "e-Library", href: "/teacher-dashboard#elibrary" }
  ];

  const items = isGuardian ? guardianItems : (isTeacher ? teacherItems : studentItems);

  return (
    <aside className="hidden lg:flex lg:flex-col lg:w-56 shrink-0 border-r border-slate-200/60 bg-white/70 backdrop-blur-sm min-h-screen py-6">
      <div className="px-4 mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center">
            <Icon icon="mdi:education" className="text-lg" />
          </div>
          <p className="text-sm text-slate-900">{isGuardian ? "Parent Portal" : (isTeacher ? "Teacher Portal" : "Student Portal")}</p>
        </div>
      </div>
      <nav className="px-2 space-y-1">
        {items.map((item) => {
          const isHash = item.href.startsWith("#") || item.href.includes("#");
          return isHash ? (
            <a
              key={item.label}
              href={item.href}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100/70 transition-colors"
            >
              <Icon icon={item.icon} className="text-lg" />
              <span className="text-sm">{item.label}</span>
            </a>
          ) : (
            <Link
              key={item.label}
              href={item.href}
              prefetch
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100/70 transition-colors"
            >
              <Icon icon={item.icon} className="text-lg" />
              <span className="text-sm">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
