"use client";

import React, { useMemo } from "react";
import { motion, useReducedMotion } from "framer-motion";

interface OverlayProps {
  enabled: boolean;
  intensity: number; // 0..1
  state: "rising" | "steady" | "falling";
  nextTask?: string;
  onToggle?: (enabled: boolean) => void;
  onIntensity?: (v: number) => void;
  nightMode?: boolean;
}

export default function AIPersonalizationOverlay({ enabled, intensity, state, nextTask, onToggle, onIntensity, nightMode }: OverlayProps) {
  const prefersReducedMotion = useReducedMotion();
  const dim = state === "falling" ? 0.2 * intensity : 0;
  const brighten = state === "rising" ? 0.15 * intensity : 0;

  const halo = useMemo(() => ({
    background: `radial-gradient(1200px 600px at 80% 20%, rgba(56,189,248,${0.05 * intensity}) 0%, rgba(56,189,248,0) 70%)`
  }), [intensity]);

  return (
    <div className="relative">
      {/* Global dim/brighten layer */}
      {enabled && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: Math.min(0.25 + brighten - dim, 0.35) }}
          transition={{ duration: prefersReducedMotion ? 0 : 0.5 }}
          className={`pointer-events-none fixed inset-0 ${nightMode ? "bg-slate-900/30" : "bg-black/10"}`}
          style={halo}
          aria-hidden
        />
      )}

      {/* Floating panels */}
      {enabled && (
        <div className="fixed inset-x-0 bottom-6 flex flex-col md:flex-row items-center justify-center gap-3 px-4 z-40">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: prefersReducedMotion ? 0 : 0.4 }}
            className="backdrop-blur-md bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white w-full md:w-auto"
          >
            <p className="text-[11px] uppercase tracking-wide opacity-80">Study Progress</p>
            <p className="text-sm">Constellations evolving ⭐</p>
          </motion.div>
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: prefersReducedMotion ? 0 : 0.45, delay: 0.05 }}
            className="backdrop-blur-md bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white w-full md:w-auto"
          >
            <p className="text-[11px] uppercase tracking-wide opacity-80">Next Task</p>
            <p className="text-sm">{nextTask || "Focus sync active →"}</p>
          </motion.div>
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: prefersReducedMotion ? 0 : 0.5, delay: 0.1 }}
            className="backdrop-blur-md bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white w-full md:w-auto"
          >
            <p className="text-[11px] uppercase tracking-wide opacity-80">AI Mentor</p>
            <div className="flex items-center gap-2">
              <span className="relative inline-flex h-3 w-3">
                <span className="absolute inline-flex h-full w-full rounded-full bg-cyan-300 opacity-75 animate-ping" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-400" />
              </span>
              <p className="text-sm">Guiding</p>
            </div>
          </motion.div>
        </div>
      )}

      {/* Controls */}
      <div className="flex items-center gap-3 mt-3">
        <label className="flex items-center gap-2 text-xs text-slate-600">
          <input
            aria-label="Toggle AI Overlay"
            type="checkbox"
            className="h-3.5 w-3.5"
            checked={enabled}
            onChange={(e) => onToggle?.(e.target.checked)}
          />
          <span>Overlay</span>
        </label>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">Intensity</span>
          <input
            aria-label="Overlay intensity"
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={intensity}
            onChange={(e) => onIntensity?.(Number(e.target.value))}
          />
        </div>
      </div>
    </div>
  );
}
