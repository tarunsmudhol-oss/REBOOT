import React from "react";

interface SectionItem {
  title: string;
  description: string;
  href: string;
}

const sections: SectionItem[] = [
  {
    title: 'Dashboard Overview',
    description: 'Academic progress, upcoming assignments, announcements, and visual widgets.',
    href: '/parents-guardians-zone/dashboard'
  },
  {
    title: 'Student Profile and Academic Reports',
    description: 'Digital profiles, enrollment details, history, downloadable reports, and performance graphs.',
    href: '/parents-guardians-zone/profile'
  },
  {
    title: 'Homework and Assignments Tracker',
    description: 'Calendar/list views, submission status, grades, teacher comments, and reminders.',
    href: '/parents-guardians-zone/assignments'
  },
  {
    title: 'Student Well-being and Behavior Monitoring',
    description: 'Behavior reports, check-ins, counseling records, alerts, and mental health resources.',
    href: '/parents-guardians-zone/wellbeing'
  },
  {
    title: 'Communication Hub',
    description: 'Secure messaging, meeting scheduling, and school-wide bulletin board.',
    href: '/parents-guardians-zone/communication'
  },
  {
    title: 'Fee Management',
    description: 'Fee structure, schedules, receipts, and payment gateway placeholders.',
    href: '/parents-guardians-zone/fees'
  },
  {
    title: 'School Events and Calendar',
    description: 'Interactive events calendar with RSVP.',
    href: '/parents-guardians-zone/events'
  },
  {
    title: 'Learning Resources',
    description: 'Guides, videos, links, and tips for parents to support learning.',
    href: '/parents-guardians-zone/resources'
  },
  {
    title: 'Multi-Child Account Management',
    description: 'Manage multiple children with consolidated notifications.',
    href: '/parents-guardians-zone/multi-child'
  },
  {
    title: 'Feedback and Support',
    description: 'Forms, analytics, notifications, and offline support, integrated with Feedback area.',
    href: '/parents-guardians-zone/feedback-support'
  },
  {
    title: 'Privacy and Security',
    description: 'Role-based access, secure login, and data encryption.',
    href: '/parents-guardians-zone/privacy-security'
  },
  {
    title: 'User Interface and Interaction',
    description: 'Clean, responsive design with charts, calendars, tables, and message threads.',
    href: '/parents-guardians-zone/notifications'
  }
];

export default function DashboardSectionsOverview() {
  return (
    <section className="max-w-6xl mx-auto px-4 md:px-6 mt-10 mb-14">
      <h2 className="text-lg md:text-xl font-medium text-slate-900 mb-4">Sections under this website</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {sections.map((s) => (
          <a key={s.title} href={s.href} className="rounded-lg border border-slate-200 bg-white p-4 hover:border-slate-300">
            <h3 className="text-sm font-medium text-slate-900 mb-1">{s.title}</h3>
            <p className="text-xs text-slate-600">{s.description}</p>
          </a>
        ))}
      </div>
      <p className="mt-6 text-xs text-slate-500">Accessing this page confirms you are a parent or legal guardian. Unauthorized access by minors is restricted to protect privacy and comply with data protection guidelines.</p>
    </section>
  );
}
