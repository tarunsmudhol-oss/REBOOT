'use client';

import React, { useEffect, useState } from "react";

export default function VerificationPreviewBox() {
  const [text, setText] = useState<string>("Academic Progress Overview (locked until verified)");
  const [locked, setLocked] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);

  const load = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/child-progress-preview', { cache: 'no-store' });
      const data = await res.json();
      setText(data?.text || "Academic Progress Overview (locked until verified)");
      setLocked(!Boolean(data?.verified));
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  return (
    <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
      <div className="rounded-lg border border-slate-200 p-5 bg-slate-50">
        <div className={`relative ${locked ? 'filter blur-[1.5px] opacity-80' : ''}`}>
          <p className="text-sm text-slate-700">{text}</p>
        </div>
        <div className="mt-3 flex items-center justify-between">
          {locked && (
            <div className="text-xs text-slate-500">Preview is locked until verification is completed.</div>
          )}
          <button
            type="button"
            onClick={() => void load()}
            className="text-xs px-2 py-1 rounded border border-slate-300 text-slate-700 bg-white"
            disabled={loading}
          >
            {loading ? 'Refreshing…' : 'Refresh preview'}
          </button>
        </div>
      </div>
    </section>
  );
}
