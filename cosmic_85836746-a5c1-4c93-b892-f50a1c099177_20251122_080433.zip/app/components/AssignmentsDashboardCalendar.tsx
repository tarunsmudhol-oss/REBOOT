"use client";

import React from "react";
import { AssignmentItem } from "@/app/components/AssignmentCard";

function getMonthMatrix(date = new Date()) {
  const year = date.getFullYear();
  const month = date.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const start = new Date(firstDay);
  start.setDate(firstDay.getDate() - ((firstDay.getDay() + 6) % 7)); // Monday start
  const end = new Date(lastDay);
  end.setDate(lastDay.getDate() + (7 - ((lastDay.getDay() + 6) % 7) - 1));

  const weeks: Date[][] = [];
  const current = new Date(start);
  while (current <= end) {
    const week: Date[] = [];
    for (let i = 0; i < 7; i++) {
      week.push(new Date(current));
      current.setDate(current.getDate() + 1);
    }
    weeks.push(week);
  }
  return { year, month, weeks };
}

function sameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

export default function AssignmentsDashboardCalendar({ items }: { items: AssignmentItem[] }) {
  const today = new Date();
  const { month, weeks } = getMonthMatrix(today);

  const byDate = new Map<string, AssignmentItem[]>();
  for (const it of items) {
    const d = new Date(it.dueAt);
    const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    const list = byDate.get(key) || [];
    list.push(it);
    byDate.set(key, list);
  }

  const monthName = today.toLocaleString(undefined, { month: "long", year: "numeric" });

  return (
    <div className="bg-white/80 backdrop-blur-sm border border-white/30 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-slate-900">{monthName}</h3>
        <p className="text-xs text-slate-500">Calendar View</p>
      </div>
      <div className="grid grid-cols-7 gap-2 text-xs">
        {["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map((d) => (
          <div key={d} className="text-slate-500 px-2 py-1">{d}</div>
        ))}
        {weeks.flatMap((week, wi) => (
          week.map((d, di) => {
            const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
            const list = byDate.get(key) || [];
            const inMonth = d.getMonth() === month;
            const isToday = sameDay(d, today);
            return (
              <div key={`${wi}-${di}`} className={`min-h-20 rounded-lg border px-2 py-1 ${inMonth ? "bg-white" : "bg-slate-50"} ${isToday ? "border-blue-500" : "border-slate-200"}`}>
                <div className="flex items-center justify-between">
                  <span className={`text-[11px] ${inMonth ? "text-slate-700" : "text-slate-400"}`}>{d.getDate()}</span>
                  {list.length > 0 && (
                    <span className="text-[10px] px-1 rounded bg-slate-900 text-white">{list.length}</span>
                  )}
                </div>
                <div className="mt-1 space-y-1">
                  {list.slice(0, 2).map((it) => (
                    <a key={it.id} href={`/student-dashboard/assignments/${it.id}`} className="block truncate text-[10px] px-1 py-0.5 rounded bg-slate-100 text-slate-700 hover:bg-slate-200">
                      {it.title}
                    </a>
                  ))}
                  {list.length > 2 && (
                    <p className="text-[10px] text-slate-500">+{list.length - 2} more</p>
                  )}
                </div>
              </div>
            );
          })
        ))}
      </div>
    </div>
  );
}
