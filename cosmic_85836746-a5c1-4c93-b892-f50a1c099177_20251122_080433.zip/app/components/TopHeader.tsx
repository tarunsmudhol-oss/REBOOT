"use client";

import React from "react";
import { Icon } from "@iconify/react";
import { useAuth } from "cosmic-authentication";

export default function TopHeader() {
  const { user, signOut } = useAuth();

  const today = new Date();
  const formatted = today.toLocaleDateString(undefined, {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric"
  });

  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center gap-4 justify-between">
          {/* Left: Logo + Search */}
          <div className="flex items-center gap-4 min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center">
                <Icon icon="mdi:education" className="text-white text-lg" />
              </div>
              <p className="text-slate-900 text-sm">Student Portal</p>
            </div>
            <div className="hidden md:flex items-center flex-1 max-w-md bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
              <Icon icon="mdi:magnify" className="text-slate-400 mr-2" />
              <input
                type="text"
                placeholder="Search courses, assignments, library..."
                className="w-full bg-transparent outline-none text-sm text-slate-700 placeholder:text-slate-400"
              />
            </div>
          </div>

          {/* Center: Nav Links */}
          <nav className="hidden lg:flex items-center gap-6">
            <a href="#registration" className="text-sm text-slate-600 hover:text-slate-900">Registration</a>
            <a href="#elibrary" className="text-sm text-slate-600 hover:text-slate-900">E-Library</a>
            <a href="#student-info" className="text-sm text-slate-600 hover:text-slate-900">Student Information</a>
          </nav>

          {/* Right: Icons + Logout */}
          <div className="flex items-center gap-2">
            <button className="p-2 rounded-lg hover:bg-slate-100 text-slate-600" aria-label="Announcements">
              <Icon icon="mdi:bullhorn-outline" className="text-lg" />
            </button>
            <button className="p-2 rounded-lg hover:bg-slate-100 text-slate-600" aria-label="Calendar">
              <Icon icon="mdi:calendar-outline" className="text-lg" />
            </button>
            <button className="p-2 rounded-lg hover:bg-slate-100 text-slate-600" aria-label="Notifications">
              <Icon icon="mdi:bell-outline" className="text-lg" />
            </button>
            <button className="p-2 rounded-lg hover:bg-slate-100 text-slate-600" aria-label="Settings">
              <Icon icon="mdi:cog-outline" className="text-lg" />
            </button>
            <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center text-xs ml-1" aria-label="Profile">
              <span>{(user?.displayName || "S").split(" ").map((n) => n[0]).join("")}</span>
            </div>
            <div className="mx-2 h-5 w-px bg-slate-200" />
            <div className="hidden md:flex items-center text-xs text-slate-500 mr-2">{formatted}</div>
            <button onClick={signOut} className="px-3 py-1.5 text-sm bg-slate-900 text-white rounded-lg hover:opacity-90">
              Logout
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
