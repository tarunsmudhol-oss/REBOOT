"use client";

import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react";
import Button from "@/app/components/Button";

interface VideoItem {
  title: string;
  platform: string;
  url: string;
  channel?: string;
  duration?: string;
  thumbnailUrl?: string;
}

interface NoteItem {
  title: string;
  format: "markdown" | "text";
  content: string;
}

interface QAItem {
  question: string;
  answer: string;
  year?: string;
  source?: string;
}

interface MCQItem {
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
}

interface WeightItem {
  topic: string;
  weight: number;
}

function SectionHeader({ title, subtitle, icon }: { title: string; subtitle?: string; icon?: string }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-2">
        {icon && <Icon icon={icon} className="text-slate-700" />}
        <h3 className="text-base font-medium text-slate-900">{title}</h3>
      </div>
      {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
    </div>
  );
}

function getYouTubeEmbedId(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtu.be")) {
      return u.pathname.replace("/", "") || null;
    }
    if (u.hostname.includes("youtube.com")) {
      const id = u.searchParams.get("v");
      if (id) return id;
      const paths = u.pathname.split("/");
      const idx = paths.indexOf("embed");
      if (idx >= 0 && paths[idx + 1]) return paths[idx + 1];
    }
  } catch {
    // ignore
  }
  return null;
}

export default function LearningHub() {
  // Shared states
  const [loadingKey, setLoadingKey] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Videos
  const [vSubject, setVSubject] = useState<string>("");
  const [vTopic, setVTopic] = useState<string>("");
  const [vOffline, setVOffline] = useState<boolean>(false);
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [videoFileUrl, setVideoFileUrl] = useState<string>("");

  // Notes
  const [nSubject, setNSubject] = useState<string>("");
  const [nTopic, setNTopic] = useState<string>("");
  const [nOffline, setNOffline] = useState<boolean>(false);
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [notesFileUrl, setNotesFileUrl] = useState<string>("");

  // PYQ
  const [qGrade, setQGrade] = useState<string>("");
  const [qSubject, setQSubject] = useState<string>("");
  const [qExam, setQExam] = useState<string>("");
  const [qOffline, setQOffline] = useState<boolean>(false);
  const [qa, setQa] = useState<QAItem[]>([]);
  const [pyqFileUrl, setPyqFileUrl] = useState<string>("");

  // Tests
  const [tSubject, setTSubject] = useState<string>("");
  const [tTopic, setTTopic] = useState<string>("");
  const [tOffline, setTOffline] = useState<boolean>(false);
  const [mcq, setMcq] = useState<MCQItem[]>([]);
  const [testsFileUrl, setTestsFileUrl] = useState<string>("");

  // Weightage
  const [wSubject, setWSubject] = useState<string>("");
  const [weights, setWeights] = useState<WeightItem[]>([]);

  const totalWeight = useMemo(() => weights.reduce((s, i) => s + (i.weight || 0), 0), [weights]);

  async function handleSubmit(path: string, payload: Record<string, unknown>, onSuccess: (data: unknown) => void) {
    setError("");
    setLoadingKey(path);
    try {
      const res = await fetch(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");
      onSuccess(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoadingKey("");
    }
  }

  return (
    <div id="assignments" className="mt-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-medium text-slate-900">Learning Hub</h2>
          <p className="text-xs text-slate-500">Curated resources • Online & offline</p>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
          {[{icon:"mdi:video",label:"Video Lessons",anchor:"#videos"},{icon:"ri:file-pdf-line",label:"Notes & PDFs",anchor:"#notes"},{icon:"ph:exam",label:"PYQs + Solutions",anchor:"#pyq"},{icon:"mdi:clipboard-text-outline",label:"Practice Tests",anchor:"#tests"},{icon:"material-symbols:line-weight",label:"Weightage",anchor:"#weightage"}].map((c)=> (
            <a key={c.label} href={c.anchor} className="block group bg-slate-50/80 border border-slate-200 rounded-xl p-4 hover:bg-slate-100 transition-colors">
              <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center mb-3">
                <Icon icon={c.icon} className="text-lg" />
              </div>
              <p className="text-sm text-slate-900">{c.label}</p>
              <p className="text-xs text-slate-500">Open</p>
            </a>
          ))}
        </div>

        {error && (
          <div className="mb-6 p-3 bg-red-50 border border-red-200 rounded text-red-700 text-sm">{error}</div>
        )}

        {/* Videos */}
        <div id="videos" className="mb-10">
          <SectionHeader title="Video Lessons" subtitle="YouTube & recorded lectures" icon="mdi:video" />
          <div className="grid md:grid-cols-3 gap-3 mb-4 text-sm">
            <input aria-label="Subject" value={vSubject} onChange={(e)=>setVSubject(e.target.value)} placeholder="Subject (required)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <input aria-label="Topic" value={vTopic} onChange={(e)=>setVTopic(e.target.value)} placeholder="Topic (optional)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <label className="inline-flex items-center gap-2 px-3 py-2 border border-slate-300 rounded-lg">
              <input type="checkbox" checked={vOffline} onChange={(e)=>setVOffline(e.target.checked)} />
              <span className="text-slate-600">Save for offline</span>
            </label>
          </div>
          <Button size="sm" onClick={()=> {
            if (!vSubject.trim()) { setError("Please enter a subject for videos."); return; }
            handleSubmit("/api/learning/videos", { subject: vSubject, topic: vTopic, offline: vOffline }, (d)=>{
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              const data = d as any;
              setVideos((data.items || []) as VideoItem[]);
              setVideoFileUrl(data.file?.fileUrl || "");
            });
          }} loading={loadingKey==="/api/learning/videos"}>Fetch Videos</Button>

          {/* Results */}
          <div className="mt-4 grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {videos.map((v)=> {
              const embedId = getYouTubeEmbedId(v.url);
              return (
                <div key={v.url} className="rounded-xl border border-slate-200 bg-white p-3">
                  <div className="aspect-video rounded-lg overflow-hidden bg-slate-100 flex items-center justify-center">
                    {embedId ? (
                      <iframe title={v.title} src={`https://www.youtube.com/embed/${encodeURIComponent(embedId)}`} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen className="w-full h-full" />
                    ) : (
                      <a href={v.url} target="_blank" rel="noreferrer" className="text-xs text-slate-600 underline">Open Link</a>
                    )}
                  </div>
                  <p className="mt-2 text-sm text-slate-900">{v.title}</p>
                  <p className="text-xs text-slate-500">{v.channel || v.platform} • {v.duration || "--"}</p>
                  <div className="mt-2 flex items-center gap-2">
                    <a href={v.url} target="_blank" rel="noreferrer" className="text-xs px-2 py-1 rounded bg-slate-900 text-white">Watch</a>
                  </div>
                </div>
              );
            })}
          </div>
          {videoFileUrl && (
            <div className="mt-3 text-xs text-slate-600">Offline list saved: <a className="underline" href={videoFileUrl}>Download</a></div>
          )}
        </div>

        {/* Notes */}
        <div id="notes" className="mb-10">
          <SectionHeader title="Topic-wise Notes & PDFs" subtitle="Concise, downloadable notes" icon="ri:file-pdf-line" />
          <div className="grid md:grid-cols-3 gap-3 mb-4 text-sm">
            <input aria-label="Subject" value={nSubject} onChange={(e)=>setNSubject(e.target.value)} placeholder="Subject (required)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <input aria-label="Topic" value={nTopic} onChange={(e)=>setNTopic(e.target.value)} placeholder="Topic (optional)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <label className="inline-flex items-center gap-2 px-3 py-2 border border-slate-300 rounded-lg">
              <input type="checkbox" checked={nOffline} onChange={(e)=>setNOffline(e.target.checked)} />
              <span className="text-slate-600">Save for offline</span>
            </label>
          </div>
          <Button size="sm" onClick={()=> {
            if (!nSubject.trim()) { setError("Please enter a subject for notes."); return; }
            handleSubmit("/api/learning/notes", { subject: nSubject, topic: nTopic, offline: nOffline }, (d)=>{
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              const data = d as any;
              setNotes((data.items || []) as NoteItem[]);
              setNotesFileUrl(data.file?.fileUrl || "");
            });
          }} loading={loadingKey==="/api/learning/notes"}>Fetch Notes</Button>

          <div className="mt-4 grid md:grid-cols-2 gap-4">
            {notes.map((n)=> (
              <div key={n.title} className="rounded-xl border border-slate-200 bg-white p-4">
                <p className="text-sm font-medium text-slate-900">{n.title}</p>
                <div className="mt-2 text-xs text-slate-700 whitespace-pre-wrap" dangerouslySetInnerHTML={{ __html: n.content.replace(/\n/g, "<br/>") }} />
              </div>
            ))}
          </div>
          {notesFileUrl && (
            <div className="mt-3 text-xs text-slate-600">Offline notes saved: <a className="underline" href={notesFileUrl}>Download</a></div>
          )}
        </div>

        {/* PYQ */}
        <div id="pyq" className="mb-10">
          <SectionHeader title="Previous-year Question Papers + Solutions" subtitle="Filtered by grade, subject and target exam" icon="ph:exam" />
          <div className="grid md:grid-cols-4 gap-3 mb-4 text-sm">
            <input aria-label="Grade" value={qGrade} onChange={(e)=>setQGrade(e.target.value)} placeholder="Grade (required)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <input aria-label="Subject" value={qSubject} onChange={(e)=>setQSubject(e.target.value)} placeholder="Subject (required)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <input aria-label="Exam Target" value={qExam} onChange={(e)=>setQExam(e.target.value)} placeholder="Exam target (required)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <label className="inline-flex items-center gap-2 px-3 py-2 border border-slate-300 rounded-lg">
              <input type="checkbox" checked={qOffline} onChange={(e)=>setQOffline(e.target.checked)} />
              <span className="text-slate-600">Save for offline</span>
            </label>
          </div>
          <Button size="sm" onClick={()=> {
            if (!qGrade.trim() || !qSubject.trim() || !qExam.trim()) { setError("Please fill Grade, Subject and Exam Target for PYQs."); return; }
            handleSubmit("/api/learning/pyq", { grade: qGrade, subject: qSubject, examTarget: qExam, offline: qOffline }, (d)=>{
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              const data = d as any;
              setQa((data.items || []) as QAItem[]);
              setPyqFileUrl(data.file?.fileUrl || "");
            });
          }} loading={loadingKey==="/api/learning/pyq"}>Fetch PYQs</Button>

          <div className="mt-4 space-y-3">
            {qa.map((q, i)=> (
              <div key={i} className="rounded-xl border border-slate-200 bg-white p-4">
                <p className="text-sm text-slate-900"><span className="text-slate-500 mr-1">Q{i+1}.</span>{q.question}</p>
                <p className="mt-2 text-xs text-slate-600"><span className="text-slate-500">Answer:</span> {q.answer}</p>
                <p className="mt-1 text-[11px] text-slate-400">{q.year || ""} {q.source ? `• ${q.source}`: ""}</p>
              </div>
            ))}
          </div>
          {pyqFileUrl && (
            <div className="mt-3 text-xs text-slate-600">Offline PYQs saved: <a className="underline" href={pyqFileUrl}>Download</a></div>
          )}
        </div>

        {/* Practice Tests */}
        <div id="tests" className="mb-10">
          <SectionHeader title="Practice Tests & Mock Exams" subtitle="Auto-generated MCQs" icon="mdi:clipboard-text-outline" />
          <div className="grid md:grid-cols-3 gap-3 mb-4 text-sm">
            <input aria-label="Subject" value={tSubject} onChange={(e)=>setTSubject(e.target.value)} placeholder="Subject (required)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <input aria-label="Topic" value={tTopic} onChange={(e)=>setTTopic(e.target.value)} placeholder="Topic (optional)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <label className="inline-flex items-center gap-2 px-3 py-2 border border-slate-300 rounded-lg">
              <input type="checkbox" checked={tOffline} onChange={(e)=>setTOffline(e.target.checked)} />
              <span className="text-slate-600">Save for offline</span>
            </label>
          </div>
          <Button size="sm" onClick={()=> {
            if (!tSubject.trim()) { setError("Please enter a subject for tests."); return; }
            handleSubmit("/api/learning/tests", { subject: tSubject, topic: tTopic, offline: tOffline }, (d)=>{
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              const data = d as any;
              setMcq((data.items || []) as MCQItem[]);
              setTestsFileUrl(data.file?.fileUrl || "");
            });
          }} loading={loadingKey==="/api/learning/tests"}>Generate Test</Button>

          <div className="mt-4 space-y-3">
            {mcq.map((m, i)=> (
              <div key={i} className="rounded-xl border border-slate-200 bg-white p-4 text-sm">
                <p className="text-slate-900"><span className="text-slate-500 mr-1">Q{i+1}.</span>{m.question}</p>
                <ul className="mt-2 text-xs text-slate-700 space-y-1 list-disc pl-5">
                  {m.options.map((o, idx)=> (
                    <li key={idx} className={idx === m.correctIndex ? "text-green-700" : ""}>{String.fromCharCode(65+idx)}. {o}</li>
                  ))}
                </ul>
                {m.explanation && <p className="mt-2 text-xs text-slate-500">Explanation: {m.explanation}</p>}
              </div>
            ))}
          </div>
          {testsFileUrl && (
            <div className="mt-3 text-xs text-slate-600">Offline test saved: <a className="underline" href={testsFileUrl}>Download</a></div>
          )}
        </div>

        {/* Weightage */}
        <div id="weightage" className="mb-2">
          <SectionHeader title="Subject-wise Weightage" subtitle="Distribution by topic" icon="material-symbols:line-weight" />
          <div className="grid md:grid-cols-3 gap-3 mb-4 text-sm">
            <input aria-label="Subject" value={wSubject} onChange={(e)=>setWSubject(e.target.value)} placeholder="Subject (required)" className="px-3 py-2 border border-slate-300 rounded-lg" />
            <div className="md:col-span-2 flex items-center">
              <Button size="sm" onClick={()=> {
                if (!wSubject.trim()) { setError("Please enter a subject for weightage."); return; }
                handleSubmit("/api/learning/weightage", { subject: wSubject }, (d)=>{
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  const data = d as any;
                  setWeights((data.items || []) as WeightItem[]);
                });
              }} loading={loadingKey==="/api/learning/weightage"}>Get Weightage</Button>
            </div>
          </div>

          <div className="space-y-2">
            {weights.map((w)=> (
              <div key={w.topic} className="text-xs">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-slate-700">{w.topic}</p>
                  <span className="text-slate-500">{w.weight}%</span>
                </div>
                <div className="h-2 w-full bg-slate-200 rounded">
                  <div className="h-2 bg-blue-600 rounded" style={{ width: `${w.weight}%` }} />
                </div>
              </div>
            ))}
            {weights.length > 0 && (
              <p className="text-[11px] text-slate-500">Total: {totalWeight}%</p>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
