"use client";

import React from "react";
import { motion } from "framer-motion";

const faqs = [
  {
    q: "Who can submit feedback?",
    a: "Authenticated students, parents, and staff can submit feedback. Your role is stored alongside your submission."
  },
  {
    q: "Can I submit feedback while offline?",
    a: "Yes. If you're offline, your feedback is saved locally and will sync automatically when you come back online."
  },
  {
    q: "How is my data used?",
    a: "We aggregate feedback to find trends and improve teaching, courses, and facilities. Sensitive fields are redacted in staff reports."
  },
  {
    q: "Who can view analytics?",
    a: "Only authorized staff can access analytics and detailed reports."
  }
];

export default function FAQSection() {
  return (
    <section className="w-full">
      <motion.div initial={{opacity:0, y:20}} animate={{opacity:1,y:0}} transition={{duration:0.5}} className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
        <h2 className="text-lg font-medium text-slate-900 mb-4">FAQ & Help</h2>
        <div className="space-y-4">
          {faqs.map((f) => (
            <div key={f.q} className="p-4 rounded-lg border border-slate-200/70 bg-slate-50/50">
              <p className="text-sm text-slate-900">{f.q}</p>
              <p className="text-sm text-slate-600 mt-1">{f.a}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
