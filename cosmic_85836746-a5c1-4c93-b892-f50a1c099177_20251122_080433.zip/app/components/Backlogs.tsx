"use client";

import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react";
import BacklogsChart3D, { BacklogItem, BacklogStatus } from "@/app/components/BacklogsChart3D";
import BacklogCard from "@/app/components/BacklogCard";

interface CreateForm {
  topic: string;
  status: BacklogStatus;
  notes: string;
}

export default function Backlogs() {
  const [items, setItems] = useState<BacklogItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [filter, setFilter] = useState<string>("");
  const [creating, setCreating] = useState<boolean>(false);
  const [form, setForm] = useState<CreateForm>({ topic: "", status: "red", notes: "" });

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const r = await fetch("/api/backlogs", { cache: "no-store" });
        const j = await r.json();
        if (!active) return;
        if (!r.ok) throw new Error(j.error || "Failed to load backlogs");
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const list: BacklogItem[] = (j.items || []).map((d: any) => ({
          id: String(d.id),
          topic: String(d.topic),
          status: d.status as BacklogStatus,
          notes: d.notes ? String(d.notes) : ""
        }));
        setItems(list);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Something went wrong");
      } finally {
        if (active) setLoading(false);
      }
    };
    load();
    return () => {
      active = false;
    };
  }, []);

  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return items;
    return items.filter((i) => i.topic.toLowerCase().includes(q) || (i.notes || '').toLowerCase().includes(q));
  }, [filter, items]);

  const groups = useMemo(() => {
    return {
      red: filtered.filter((i) => i.status === "red"),
      yellow: filtered.filter((i) => i.status === "yellow"),
      green: filtered.filter((i) => i.status === "green"),
    } as Record<BacklogStatus, BacklogItem[]>;
  }, [filtered]);

  async function onMove(id: string, to: BacklogStatus) {
    const prev = [...items];
    setItems((arr) => arr.map((i) => (i.id === id ? { ...i, status: to } : i)));
    const res = await fetch("/api/backlogs", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status: to })
    });
    if (!res.ok) {
      setItems(prev);
    }
  }

  async function onEditNotes(id: string, notes: string) {
    setItems((arr) => arr.map((i) => (i.id === id ? { ...i, notes } : i)));
    const res = await fetch("/api/backlogs", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, notes })
    });
    if (!res.ok) {
      // ignore revert to keep UI smooth
    }
  }

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!form.topic.trim()) {
      setError("Please enter a topic name.");
      return;
    }
    setCreating(true);
    try {
      const r = await fetch("/api/backlogs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Failed to add topic");
      const newItem: BacklogItem = { id: String(j.id || j.item?.id), topic: form.topic.trim(), status: form.status, notes: form.notes };
      setItems((arr) => [newItem, ...arr]);
      setForm({ topic: "", status: "red", notes: "" });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setCreating(false);
    }
  }

  return (
    <section id="backlogs" className="mt-12">
      {/* Hero */}
      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="mb-6">
        <p className="text-xs uppercase tracking-wide text-slate-500">progress report</p>
        <h2 className="text-2xl md:text-3xl text-slate-900 mt-1">everything u need to cover</h2>
      </motion.div>

      {/* Task bar */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="bg-white/80 backdrop-blur-sm border border-white/20 rounded-xl p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2 py-1 text-xs rounded bg-slate-900 text-white">topics not covered</span>
            <input
              aria-label="Search topics"
              placeholder="Search topics or notes"
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm w-full md:w-72 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
          </div>
          <form onSubmit={onCreate} className="flex flex-col sm:flex-row gap-2">
            <input
              aria-label="New topic"
              placeholder="Add a topic"
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm w-full sm:w-72 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={form.topic}
              onChange={(e) => setForm({ ...form, topic: e.target.value })}
              required
            />
            <select
              aria-label="Select status"
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value as BacklogStatus })}
            >
              <option value="red">Red</option>
              <option value="yellow">Yellow</option>
              <option value="green">Green</option>
            </select>
            <button disabled={creating} className="px-4 py-2 rounded-lg bg-slate-900 text-white text-sm">{creating ? "Adding..." : "Add"}</button>
          </form>
        </div>
        {error && <p className="mt-3 text-xs text-red-600" role="status" aria-live="polite">{error}</p>}
      </motion.div>

      {/* Loading / Empty */}
      {loading ? (
        <p className="text-sm text-slate-500">Loading backlogs...</p>
      ) : filtered.length === 0 ? (
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-8 border border-white/20 text-center">
          <p className="text-sm text-slate-600">No topics found. Use the bar above to add new topics.</p>
        </div>
      ) : (
        <div className="grid xl:grid-cols-3 gap-8">
          <div className="xl:col-span-1 order-2 xl:order-1 space-y-4">
            <BacklogCard title="Very important topics to cover soon" hue="red" items={groups.red} onMove={onMove} onEditNotes={onEditNotes} />
            <BacklogCard title="Practice often to improve mastery" hue="yellow" items={groups.yellow} onMove={onMove} onEditNotes={onEditNotes} />
            <BacklogCard title="Good at these • only revision needed" hue="green" items={groups.green} onMove={onMove} onEditNotes={onEditNotes} />
          </div>
          <div className="xl:col-span-2 order-1 xl:order-2">
            <BacklogsChart3D items={filtered} />
            <div className="grid sm:grid-cols-3 gap-4 mt-6">
              <div className="rounded-lg border border-red-200 bg-red-50/60 p-4">
                <p className="text-sm text-slate-900">Red: very important — cover soon</p>
              </div>
              <div className="rounded-lg border border-yellow-200 bg-yellow-50/60 p-4">
                <p className="text-sm text-slate-900">Yellow: practice often to master</p>
              </div>
              <div className="rounded-lg border border-green-200 bg-green-50/60 p-4">
                <p className="text-sm text-slate-900">Green: you&apos;re good — revise periodically</p>
              </div>
            </div>
            <div className="mt-6 flex items-center gap-2 text-xs text-slate-600">
              <Icon icon="mdi:information-outline" />
              <p>Tip: Drag-select text in your notes to quickly copy it while revising.</p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
