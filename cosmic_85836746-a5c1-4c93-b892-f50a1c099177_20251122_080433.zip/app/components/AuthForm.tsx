"use client";

import React, { useState } from "react";
import { Icon } from "@iconify/react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./Button";

interface AuthFormProps {
  mode: "login" | "signup";
  onModeSwitch: (mode: "login" | "signup") => void;
  onRoleSelection: (role: string) => void;
}

const roles = [
  {
    id: "student",
    title: "Student",
    description: "Access your courses, assignments, and grades",
    icon: "hugeicons:students",
    color: "bg-blue-500",
    route: "/student-dashboard"
  },
  {
    id: "teacher", 
    title: "Teacher",
    description: "Manage classes, create assignments, and track progress",
    icon: "mdi:account-tie",
    color: "bg-green-500",
    route: "/teacher-dashboard"
  },
  {
    id: "parent",
    title: "Parent",
    description: "Monitor your child\'s academic progress and activities",
    icon: "mdi:account-heart",
    color: "bg-orange-500", 
    route: "/parent-dashboard"
  }
];

export default function AuthForm({ mode, onModeSwitch, onRoleSelection }: AuthFormProps) {
  const [step, setStep] = useState<"auth" | "role" | "student-details">("auth");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    birthdate: ""
  });

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (mode === "signup" && (!formData.email || !formData.password || !formData.confirmPassword)) {
      setError("Please fill in all required fields");
      return;
    }

    if (mode === "signup" && formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    // Move to role selection; sign-in will occur when navigating to role route
    setStep("role");
  };

  const handleRoleSelect = (role: string) => {
    if (role === "student") {
      setStep("student-details");
    } else {
      // Navigate to protected route; middleware will prompt sign-in and return
      handleCompleteAuth(role);
    }
  };

  const handleStudentDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (!formData.birthdate) {
      setError("Birthdate is required for student accounts");
      setLoading(false);
      return;
    }

    const today = new Date();
    const birthDate = new Date(formData.birthdate);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) age -= 1;

    if (age < 15) {
      setError("Students must be at least 15 years old");
      setLoading(false);
      return;
    }

    try {
      // Go to student dashboard; auth middleware will handle sign-in flow
      handleCompleteAuth("student");
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteAuth = async (role: string) => {
    // Navigate first; if not authenticated, middleware triggers sign-in and returns
    onRoleSelection(role);
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white/90 backdrop-blur-lg rounded-2xl shadow-xl border border-white/20 p-8">
      <AnimatePresence mode="wait">
        {step === "auth" && (
          <motion.div
            key="auth"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            transition={{ duration: 0.3 }}
          >
            <div className="text-center mb-8">
              <h2 className="text-2xl font-medium text-slate-900 mb-2">
                {mode === "login" ? "Welcome back" : "Create your account"}
              </h2>
              <p className="text-slate-600 text-sm">
                {mode === "login" 
                  ? "Sign in to access your portal" 
                  : "Join our educational community"}
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                {error}
              </div>
            )}

            <form onSubmit={handleEmailAuth} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter your email"
                  required={mode === "signup"}
                />
              </div>

              {mode === "signup" && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Password</label>
                    <input
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter your password"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Confirm Password</label>
                    <input
                      type="password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Confirm your password"
                      required
                    />
                  </div>
                </>
              )}

              <Button type="submit" className="w-full" size="lg">
                {mode === "login" ? "Continue" : "Continue"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => onModeSwitch(mode === "login" ? "signup" : "login")}
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                {mode === "login" 
                  ? "Don\'t have an account? Sign up" 
                  : "Already have an account? Sign in"}
              </button>
            </div>
          </motion.div>
        )}

        {step === "role" && (
          <motion.div
            key="role"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            transition={{ duration: 0.3 }}
          >
            <div className="text-center mb-8">
              <h2 className="text-2xl font-medium text-slate-900 mb-2">Choose your role</h2>
              <p className="text-slate-600 text-sm">Select how you&apos;ll be using the portal</p>
            </div>

            <div className="space-y-3">
              {roles.map((role) => (
                <button
                  key={role.id}
                  onClick={() => handleRoleSelect(role.id)}
                  className="w-full p-4 border border-slate-200 rounded-xl hover:border-blue-300 hover:bg-blue-50/50 transition-all duration-200 text-left group"
                >
                  <div className="flex items-center space-x-4">
                    <div className={`p-3 rounded-lg ${role.color}`}>
                      <Icon icon={role.icon} className="text-white text-xl" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-slate-900 group-hover:text-blue-900">
                        {role.title}
                      </h3>
                      <p className="text-sm text-slate-600 group-hover:text-blue-700">
                        {role.description}
                      </p>
                    </div>
                    <Icon icon="mdi:chevron-right" className="text-slate-400 group-hover:text-blue-500" />
                  </div>
                </button>
              ))}
            </div>

            <div className="mt-6 text-center">
              <button
                onClick={() => setStep("auth")}
                className="text-sm text-slate-500 hover:text-slate-700"
              >
                ← Back to login
              </button>
            </div>
          </motion.div>
        )}

        {step === "student-details" && (
          <motion.div
            key="student-details"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            transition={{ duration: 0.3 }}
          >
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon icon="hugeicons:students" className="text-blue-600 text-2xl" />
              </div>
              <h2 className="text-2xl font-medium text-slate-900 mb-2">Student Information</h2>
              <p className="text-slate-600 text-sm">Please provide your date of birth to verify your age</p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                {error}
              </div>
            )}

            <form onSubmit={handleStudentDetails} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Date of Birth <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={formData.birthdate}
                  onChange={(e) => setFormData({ ...formData, birthdate: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                  max={new Date().toISOString().split('T')[0]}
                />
                <p className="text-xs text-slate-500 mt-1">
                  You must be at least 15 years old to continue as a student
                </p>
              </div>

              <Button type="submit" className="w-full" size="lg" loading={loading}>
                Continue to Student Dashboard
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => setStep("role")}
                className="text-sm text-slate-500 hover:text-slate-700"
                disabled={loading}
              >
                ← Back to role selection
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}