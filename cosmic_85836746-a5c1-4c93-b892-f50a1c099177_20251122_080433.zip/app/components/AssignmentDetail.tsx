"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Icon } from "@iconify/react";
import SubmissionEditor from "@/app/components/SubmissionEditor";
import DiscussionThread from "@/app/components/DiscussionThread";

interface AttachmentMeta { name: string; url: string; type: string }
interface RubricItem { criterion: string; points: number; description?: string }
interface AssignmentFull {
  id: string;
  title: string;
  subject: string;
  dueAt: string;
  description?: string;
  attachments?: AttachmentMeta[];
  rubric?: RubricItem[];
  status: "pending" | "submitted" | "graded" | "overdue";
}

interface FeedbackItem { id: string; grade?: number; teacherComments?: string }

export default function AssignmentDetail({ assignmentId }: { assignmentId: string }) {
  const [data, setData] = useState<AssignmentFull | null>(null);
  const [feedback, setFeedback] = useState<FeedbackItem[]>([]);
  const [ai, setAi] = useState<{ tips: string[]; outline: string[]; checklist: string[] } | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const r = await fetch(`/api/assignments?id=${assignmentId}`, { cache: "no-store" });
        const j = await r.json();
        if (!active) return;
        if (r.ok && j?.id) setData(j);
      } catch {
        // noop
      }
    })();

    (async () => {
      try {
        const r = await fetch(`/api/assignments/feedback?assignmentId=${assignmentId}`, { cache: "no-store" });
        const j = await r.json();
        if (!active) return;
        if (r.ok && Array.isArray(j.items)) setFeedback(j.items);
      } catch {
        // noop
      }
    })();

    return () => {
      active = false;
    };
  }, [assignmentId]);

  const grade = useMemo(() => {
    const g = feedback.map((f) => (typeof f.grade === "number" ? f.grade : null)).filter((x): x is number => x !== null);
    if (g.length === 0) return null;
    return g[g.length - 1];
  }, [feedback]);

  const loadAi = async () => {
    try {
      const r = await fetch("/api/assignments/ai-assist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject: data?.subject || "", assignmentText: data?.description || "" })
      });
      const j = await r.json();
      if (r.ok) setAi(j);
    } catch {
      // noop
    }
  };

  if (!data) return <p className="text-sm text-slate-600">Loading assignment...</p>;

  const dueStr = new Date(data.dueAt).toLocaleString();

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-4">
        <div className="bg-white/80 backdrop-blur-sm border border-white/30 rounded-xl p-5">
          <h2 className="text-lg font-medium text-slate-900">{data.title}</h2>
          <p className="text-xs text-slate-500 mt-0.5">{data.subject}</p>
          <div className="flex items-center gap-2 text-xs text-slate-600 mt-2">
            <Icon icon="mdi:calendar-clock" />
            <p>Due: {dueStr}</p>
          </div>
          {data.description && (
            <div className="mt-3">
              <h4 className="text-sm text-slate-900 font-medium">Description</h4>
              <p className="text-sm text-slate-700 mt-1 whitespace-pre-wrap">{data.description}</p>
            </div>
          )}
          {Array.isArray(data.rubric) && data.rubric.length > 0 && (
            <div className="mt-3">
              <h4 className="text-sm text-slate-900 font-medium">Grading Rubric</h4>
              <div className="mt-2 border border-slate-200 rounded-lg overflow-hidden">
                <div className="grid grid-cols-3 bg-slate-50 text-xs text-slate-600 p-2">
                  <span>Criterion</span><span>Points</span><span>Notes</span>
                </div>
                <div className="divide-y divide-slate-200">
                  {data.rubric.map((r, idx) => (
                    <div key={idx} className="grid grid-cols-3 text-xs p-2">
                      <span>{r.criterion}</span>
                      <span>{r.points}</span>
                      <span className="text-slate-600">{r.description || ""}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          {Array.isArray(data.attachments) && data.attachments.length > 0 && (
            <div className="mt-3">
              <h4 className="text-sm text-slate-900 font-medium">Attachments</h4>
              <div className="flex flex-wrap gap-2 mt-2">
                {data.attachments.map((a) => (
                  <a key={a.url} href={a.url} target="_blank" rel="noreferrer" className="text-xs px-2 py-1 rounded bg-slate-100 text-slate-700 hover:bg-slate-200 transition">
                    <span>{a.name}</span>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>

        <SubmissionEditor assignmentId={assignmentId} />
        <DiscussionThread assignmentId={assignmentId} />
      </div>

      <div className="space-y-4">
        <div className="bg-white/80 backdrop-blur-sm border border-white/30 rounded-xl p-4">
          <h4 className="text-slate-900 text-sm font-medium mb-1">Status & Feedback</h4>
          <p className="text-xs text-slate-600">Current status: <span className="text-slate-900">{data.status}</span></p>
          {grade !== null && <p className="text-xs text-slate-600 mt-1">Latest grade: <span className="text-slate-900">{grade}</span></p>}
          {feedback.length > 0 && (
            <div className="mt-2 space-y-1">
              {feedback.map((f) => (
                <div key={f.id} className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1">
                  {typeof f.grade === "number" && <p>Grade: {f.grade}</p>}
                  {f.teacherComments && <p className="text-slate-700">{f.teacherComments}</p>}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white/80 backdrop-blur-sm border border-white/30 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-slate-900 text-sm font-medium">AI Tips</h4>
            <button onClick={loadAi} className="px-2 py-1 text-xs rounded bg-slate-900 text-white">Get Tips</button>
          </div>
          {!ai && <p className="text-xs text-slate-600">Get concise suggestions powered by AI.</p>}
          {ai && (
            <div className="space-y-2">
              <div>
                <p className="text-[11px] text-slate-500">Tips</p>
                <ul className="list-disc pl-4 text-xs text-slate-700">
                  {ai.tips.map((t, i) => (<li key={i}>{t}</li>))}
                </ul>
              </div>
              <div>
                <p className="text-[11px] text-slate-500">Outline</p>
                <ul className="list-disc pl-4 text-xs text-slate-700">
                  {ai.outline.map((t, i) => (<li key={i}>{t}</li>))}
                </ul>
              </div>
              <div>
                <p className="text-[11px] text-slate-500">Checklist</p>
                <ul className="list-disc pl-4 text-xs text-slate-700">
                  {ai.checklist.map((t, i) => (<li key={i}>{t}</li>))}
                </ul>
              </div>
            </div>
          )}
        </div>

        <div className="bg-white/80 backdrop-blur-sm border border-white/30 rounded-xl p-4">
          <h4 className="text-slate-900 text-sm font-medium mb-1">Submission Guidelines</h4>
          <ul className="text-xs text-slate-700 list-disc pl-4">
            <li>Accepted formats: PDF, DOCX, PPTX, images</li>
            <li>Ensure readable filenames (no spaces)</li>
            <li>Attach all required files before final submit</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
