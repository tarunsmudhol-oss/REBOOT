import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { CosmicAnalyticsProvider } from "cosmic-analytics";
import { AuthProvider } from "cosmic-authentication";
import BrandingTextRemover from "@/app/components/BrandingTextRemover";

const primaryFont = Inter({
  weight: ["300", "400", "500", "600", "700"],
  subsets: ["latin"]
});

// Change the title and description to your own.
export const metadata: Metadata = {
  title: "Smart Student Portal - Connecting Students, Resources, and Success",
  description: "A comprehensive education platform connecting students, teachers, and parents. Manage coursework, track progress, and foster educational success."
};

export default function RootLayout({
  children
}: Readonly<{children: React.ReactNode;}>) {
  return (
    <html data-editor-id="app/layout.tsx:27:5" lang="en" className={primaryFont.className}>
      <body data-editor-id="app/layout.tsx:31:7" className="antialiased">
        <main data-editor-id="app/layout.tsx:32:9" className="min-h-screen">
          <CosmicAnalyticsProvider>
            <AuthProvider>
              {children}
            </AuthProvider>
          </CosmicAnalyticsProvider>
        </main>
        {process.env.VISUAL_EDITOR_ACTIVE === 'true' &&
        <script data-editor-id="app/layout.tsx:50:9" src="/editor.js" async />
        }
        {/* Inject a global helper to strip only the branding text while keeping the badge */}
        {/*COSMIC-SAFE-BRANDING-REMOVAL*/}
        <BrandingTextRemover />
      </body>
    </html>);

}