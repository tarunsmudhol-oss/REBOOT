import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface FeedbackDoc {
  userId: string;
  role: string;
  feedbackType: string;
  rating?: number;
  text?: string;
  mcqAnswers?: Record<string, string>;
  emojiMatrix?: Record<string, unknown>;
  subject?: string;
  course?: string;
  context?: string;
  status: 'new' | 'responded' | 'in-progress';
  createdAt?: unknown;
  updatedAt?: unknown;
}

async function getUserRoleByEmail(email: string | undefined): Promise<string | null> {
  try {
    if (!email) return null;
    const snap = await db.collection('users').where('email', '==', email).limit(1).get();
    if (snap.empty) return null;
    const data = snap.docs[0].data() as { role?: string };
    return data?.role || null;
  } catch {
    return null;
  }
}

function isStaff(role: string | null): boolean {
  return role === 'teacher' || role === 'admin' || role === 'staff';
}

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    const url = new URL(request.url);
    const since = url.searchParams.get('since');

    const role = await getUserRoleByEmail(String(user.email || ''));

    if (isStaff(role)) {
      // Staff: fetch recent feedback (limit for performance), optionally filter by since client-side
      const snap = await db
        .collection('feedback')
        .orderBy('createdAt', 'desc')
        .limit(200)
        .get();
      const items = snap.docs.map((d) => ({ id: d.id, ...(d.data() as object) }));

      if (since) {
        const sinceNum = Number(since);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const filtered = items.filter((it: any) => {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const ts = (it.createdAt && typeof (it.createdAt as any).toDate === 'function') ? (it.createdAt as any).toDate().getTime() : 0;
          return ts > sinceNum;
        });
        return NextResponse.json({ items: filtered });
      }

      return NextResponse.json({ items });
    }

    // Non-staff: return only their own submissions
    const mySnap = await db
      .collection('feedback')
      .where('userId', '==', user.uid)
      .limit(100)
      .get();

    const items = mySnap.docs.map((d) => ({ id: d.id, ...(d.data() as object) }));
    return NextResponse.json({ items });
  } catch (error) {
    console.error('Feedback GET error', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    const body = await request.json();
    const {
      feedbackType,
      rating,
      text,
      mcqAnswers,
      emojiMatrix,
      subject,
      course,
      context
    } = body as Partial<FeedbackDoc>;

    if (!feedbackType) {
      return NextResponse.json({ error: 'feedbackType is required' }, { status: 400 });
    }

    const role = await getUserRoleByEmail(String(user.email || ''));

    const doc: FeedbackDoc = {
      userId: user.uid,
      role: role || 'student',
      feedbackType: String(feedbackType),
      rating: typeof rating === 'number' ? rating : undefined,
      text: typeof text === 'string' ? text : undefined,
      mcqAnswers: mcqAnswers && typeof mcqAnswers === 'object' ? mcqAnswers as Record<string, string> : undefined,
      emojiMatrix: emojiMatrix && typeof emojiMatrix === 'object' ? emojiMatrix as Record<string, unknown> : undefined,
      subject: subject ? String(subject) : undefined,
      course: course ? String(course) : undefined,
      context: context ? String(context) : undefined,
      status: 'new',
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const ref = await db.collection('feedback').add(doc);
    return NextResponse.json({ success: true, id: ref.id });
  } catch (error) {
    console.error('Feedback POST error', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    const role = await getUserRoleByEmail(String(user.email || ''));
    if (!isStaff(role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const { id, status } = body as { id?: string; status?: FeedbackDoc['status'] };
    if (!id || !status) return NextResponse.json({ error: 'id and status required' }, { status: 400 });

    await db.collection('feedback').doc(id).update({ status, updatedAt: db.FieldValue.serverTimestamp() });
    // Audit log entry for staff action
    await db.collection('feedback_audit').add({
      feedbackId: id,
      action: 'update_status',
      newStatus: status,
      actorId: user.uid,
      updatedAt: db.FieldValue.serverTimestamp(),
      createdAt: db.FieldValue.serverTimestamp()
    });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Feedback PUT error', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
