import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

async function getUserRoleByEmail(email: string | undefined): Promise<string | null> {
  try {
    if (!email) return null;
    const snap = await db.collection('users').where('email', '==', email).limit(1).get();
    if (snap.empty) return null;
    const data = snap.docs[0].data() as { role?: string };
    return data?.role || null;
  } catch {
    return null;
  }
}

function isStaff(role: string | null): boolean {
  return role === 'teacher' || role === 'admin' || role === 'staff';
}

export async function GET() {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    const role = await getUserRoleByEmail(String(user.email || ''));
    if (!isStaff(role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    // Fetch recent feedback
    const snap = await db.collection('feedback').orderBy('createdAt', 'desc').limit(500).get();
    const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));

    // Aggregate stats client-side to avoid composite indexes
    const countsByType: Record<string, number> = {};
    const countsByRole: Record<string, number> = {};
    let totalRating = 0;
    let ratingCount = 0;

    const trendByDay: Record<string, number> = {}; // YYYY-MM-DD -> count

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    for (const it of items as any[]) {
      const t = String(it.feedbackType || 'general');
      countsByType[t] = (countsByType[t] || 0) + 1;

      const r = String(it.role || 'unknown');
      countsByRole[r] = (countsByRole[r] || 0) + 1;

      if (typeof it.rating === 'number') {
        totalRating += it.rating;
        ratingCount += 1;
      }

      const ts = it.createdAt && typeof it.createdAt.toDate === 'function' ? it.createdAt.toDate() : null;
      const key = ts ? ts.toISOString().slice(0, 10) : 'unknown';
      trendByDay[key] = (trendByDay[key] || 0) + 1;
    }

    const avgRating = ratingCount > 0 ? Number((totalRating / ratingCount).toFixed(2)) : null;
    const total = items.length;

    return NextResponse.json({ total, avgRating, countsByType, countsByRole, trendByDay });
  } catch (error) {
    console.error('Feedback stats error', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
