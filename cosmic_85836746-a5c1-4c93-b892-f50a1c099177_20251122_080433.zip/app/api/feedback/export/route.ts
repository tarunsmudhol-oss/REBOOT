import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

async function getUserRoleByEmail(email: string | undefined): Promise<string | null> {
  try {
    if (!email) return null;
    const snap = await db.collection('users').where('email', '==', email).limit(1).get();
    if (snap.empty) return null;
    const data = snap.docs[0].data() as { role?: string };
    return data?.role || null;
  } catch {
    return null;
  }
}

function isStaff(role: string | null): boolean {
  return role === 'teacher' || role === 'admin' || role === 'staff';
}

function toCsv(rows: Array<Record<string, unknown>>): string {
  if (rows.length === 0) return '';
  const headers = Array.from(
    rows.reduce((set, row) => {
      Object.keys(row).forEach((k) => set.add(k));
      return set;
    }, new Set<string>())
  );
  const escape = (val: unknown) => {
    const s = typeof val === 'string' ? val : JSON.stringify(val ?? '');
    return '"' + s.replace(/"/g, '""') + '"';
  };
  const lines = [headers.join(',')];
  for (const row of rows) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    lines.push(headers.map((h) => escape((row as any)[h])).join(','));
  }
  return lines.join('\n');
}

export async function GET() {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    const role = await getUserRoleByEmail(String(user.email || ''));
    if (!isStaff(role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

    const snap = await db.collection('feedback').orderBy('createdAt', 'desc').limit(1000).get();
    const rows = snap.docs.map((d) => {
      const data = d.data() as Record<string, unknown>;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const createdAt = (data.createdAt && (data.createdAt as any).toDate) ? (data.createdAt as any).toDate().toISOString() : '';
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const updatedAt = (data.updatedAt && (data.updatedAt as any).toDate) ? (data.updatedAt as any).toDate().toISOString() : '';
      return { id: d.id, ...data, createdAt, updatedAt };
    });

    const csv = toCsv(rows);
    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': 'attachment; filename="feedback-export.csv"'
      }
    });
  } catch (error) {
    console.error('Feedback export error', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
