import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

export async function GET() {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ text: 'Academic Progress Overview (locked until verified)', verified: false }, { status: 200 });
    }

    const doc = await db.collection('parentsGuardians').doc(sessionUser.uid).get();
    const isVerified = doc.exists ? Boolean((doc.data() as { isVerified?: boolean }).isVerified) : false;

    if (!isVerified) {
      return NextResponse.json({ text: 'Academic Progress Overview (locked until verified)', verified: false }, { status: 200 });
    }

    return NextResponse.json({ text: 'Academic Progress: 68% (example)', verified: true }, { status: 200 });
  } catch {
    return NextResponse.json({ text: 'Academic Progress Overview (locked until verified)', verified: false }, { status: 200 });
  }
}
