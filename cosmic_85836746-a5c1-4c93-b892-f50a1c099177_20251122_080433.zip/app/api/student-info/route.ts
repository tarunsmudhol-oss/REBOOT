import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface StudentInfo {
  uid: string;
  studentName: string;
  dob: string; // ISO date string
  classLevel: string;
  school: string;
  targetExam: string;
  gender: string;
  previousYearMarks: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

function calculateAge(dobIso: string): number {
  const today = new Date();
  const birthDate = new Date(dobIso);
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age -= 1;
  }
  return age;
}

function validatePayload(body: Partial<StudentInfo>): { valid: boolean; error?: string } {
  if (!body.studentName || !body.dob || !body.classLevel || !body.school || !body.targetExam || !body.gender || typeof body.previousYearMarks !== 'number') {
    return { valid: false, error: 'All fields are required and marks must be a number' };
  }
  if (calculateAge(body.dob) < 15) {
    return { valid: false, error: 'Students must be at least 15 years old' };
  }
  return { valid: true };
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const uid = searchParams.get('uid');

    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const targetUid = uid || sessionUser.uid;
    if (!targetUid) {
      return NextResponse.json({ error: 'Missing uid' }, { status: 400 });
    }

    const docRef = db.collection('studentInfo').doc(targetUid);
    const doc = await docRef.get();
    if (!doc.exists) {
      return NextResponse.json({ exists: false }, { status: 200 });
    }

    return NextResponse.json({ exists: true, id: doc.id, ...doc.data() }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('Error fetching student info:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const body = (await request.json()) as Partial<StudentInfo>;
    const { valid, error } = validatePayload(body);
    if (!valid) {
      return NextResponse.json({ error }, { status: 400 });
    }

    const payload: StudentInfo = {
      uid: sessionUser.uid,
      studentName: body.studentName as string,
      dob: body.dob as string,
      classLevel: body.classLevel as string,
      school: body.school as string,
      targetExam: body.targetExam as string,
      gender: body.gender as string,
      previousYearMarks: body.previousYearMarks as number,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const docRef = db.collection('studentInfo').doc(sessionUser.uid);
    await docRef.set(payload);

    return NextResponse.json({ success: true, id: sessionUser.uid, data: payload }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('Error saving student info:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const body = (await request.json()) as Partial<StudentInfo>;
    const { valid, error } = validatePayload(body);
    if (!valid) {
      return NextResponse.json({ error }, { status: 400 });
    }

    const updatePayload = {
      studentName: body.studentName,
      dob: body.dob,
      classLevel: body.classLevel,
      school: body.school,
      targetExam: body.targetExam,
      gender: body.gender,
      previousYearMarks: body.previousYearMarks,
      updatedAt: db.FieldValue.serverTimestamp()
    };

    await db.collection('studentInfo').doc(sessionUser.uid).set(updatePayload, { merge: true });

    return NextResponse.json({ success: true, id: sessionUser.uid }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('Error updating student info:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
