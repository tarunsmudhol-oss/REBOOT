import { NextResponse } from "next/server";
import { getServerSession } from "cosmic-authentication";
import { db } from "cosmic-database";

interface AttachmentMeta { name: string; url: string; type: string }
interface RubricItem { criterion: string; points: number; description?: string }

type Status = "pending" | "submitted" | "graded" | "overdue";

export async function GET(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    const status = searchParams.get("status");
    const subject = searchParams.get("subject");

    if (id) {
      const doc = await db.collection("assignments").doc(id).get();
      if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 });
      const data = doc.data() as Record<string, unknown>;
      if (data.userId !== session.uid) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
      return NextResponse.json({ id: doc.id, ...data });
    }

    const snap = await db.collection("assignments").where("userId", "==", session.uid).limit(200).get();
    const all = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));

    const filtered = all.filter((a) => {
      const s = (a["status"] as string) || "";
      const subj = ((a["subject"] as string) || "").toLowerCase();
      const okStatus = status ? s === status : true;
      const okSubject = subject ? subj.includes(subject.toLowerCase()) : true;
      return okStatus && okSubject;
    });

    return NextResponse.json({ items: filtered });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const body = await request.json();
    const title: string = body.title;
    const subject: string = body.subject || "General";
    const dueAt: string = body.dueAt; // ISO string
    const description: string = body.description || "";
    const attachments: AttachmentMeta[] = Array.isArray(body.attachments) ? body.attachments : [];
    const rubric: RubricItem[] = Array.isArray(body.rubric) ? body.rubric : [];

    if (!title || !dueAt) {
      return NextResponse.json({ error: "title and dueAt are required" }, { status: 400 });
    }

    const status: Status = "pending";

    const payload = {
      userId: session.uid,
      title,
      subject,
      dueAt,
      description,
      attachments,
      rubric,
      status,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const ref = await db.collection("assignments").add(payload);
    return NextResponse.json({ success: true, id: ref.id });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const body = await request.json();
    const id: string = body.id;
    if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });

    const doc = await db.collection("assignments").doc(id).get();
    if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const data = doc.data() as Record<string, unknown>;
    if (data.userId !== session.uid) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const updates: Record<string, unknown> = {};
    if (typeof body.title === "string") updates.title = body.title;
    if (typeof body.subject === "string") updates.subject = body.subject;
    if (typeof body.description === "string") updates.description = body.description;
    if (typeof body.dueAt === "string") updates.dueAt = body.dueAt;
    if (typeof body.status === "string") updates.status = body.status as Status;
    if (Array.isArray(body.attachments)) updates.attachments = body.attachments as AttachmentMeta[];
    if (Array.isArray(body.rubric)) updates.rubric = body.rubric as RubricItem[];

    updates.updatedAt = db.FieldValue.serverTimestamp();

    await db.collection("assignments").doc(id).update(updates);
    return NextResponse.json({ success: true });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id is required" }, { status: 400 });

    const doc = await db.collection("assignments").doc(id).get();
    if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const data = doc.data() as Record<string, unknown>;
    if (data.userId !== session.uid) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    await db.collection("assignments").doc(id).delete();
    return NextResponse.json({ success: true });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
