import { NextResponse } from "next/server";
import { getServerSession } from "cosmic-authentication";
import { db } from "cosmic-database";

interface Feedback {
  assignmentId: string;
  submissionId?: string;
  userId: string;
  grade?: number;
  teacherComments?: string;
}

export async function GET(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const assignmentId = searchParams.get("assignmentId");

    const snap = await db.collection("feedback").where("userId", "==", session.uid).limit(200).get();
    const all = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));

    const filtered = assignmentId ? all.filter((f) => String(f["assignmentId"]) === assignmentId) : all;

    return NextResponse.json({ items: filtered });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const body = await request.json();
    const assignmentId: string = body.assignmentId;
    const submissionId: string | undefined = body.submissionId || undefined;
    const grade: number | undefined = typeof body.grade === "number" ? body.grade : undefined;
    const teacherComments: string | undefined = body.teacherComments || undefined;

    if (!assignmentId) return NextResponse.json({ error: "assignmentId is required" }, { status: 400 });

    const payload: Feedback & { createdAt: unknown; updatedAt: unknown } = {
      assignmentId,
      submissionId,
      userId: session.uid,
      grade,
      teacherComments,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const ref = await db.collection("feedback").add(payload);

    // Attempt to update assignment & submission status
    try {
      await db.collection("assignments").doc(assignmentId).update({ status: "graded", updatedAt: db.FieldValue.serverTimestamp() });
      if (submissionId) {
        await db.collection("submissions").doc(submissionId).update({ status: "graded", updatedAt: db.FieldValue.serverTimestamp() });
      }
    } catch {
      // ignore
    }

    return NextResponse.json({ success: true, id: ref.id });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
