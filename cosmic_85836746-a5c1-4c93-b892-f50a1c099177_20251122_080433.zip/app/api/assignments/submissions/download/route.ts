import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const fileId = searchParams.get("fileId");
    if (!fileId) return NextResponse.json({ error: "fileId is required" }, { status: 400 });

    const userId = process.env.USER_ID || "";
    const projectId = process.env.NEXT_PUBLIC_CLIENT_ID || "";
    const url = `https://files.cosmic.new/files/${encodeURIComponent(userId)}/${encodeURIComponent(projectId)}?fileId=${encodeURIComponent(fileId)}`;

    const res = await fetch(url);
    const headers = new Headers();
    res.headers.forEach((v, k) => headers.set(k, v));
    return new NextResponse(res.body, { status: res.status, headers });
  } catch {
    return NextResponse.json({ error: "Download failed" }, { status: 500 });
  }
}
