import { NextResponse } from "next/server";
import { getServerSession } from "cosmic-authentication";
import { db } from "cosmic-database";

interface FileMeta { fileId: string; fileName: string; fileType: string; fileSize: number }

export async function GET(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const assignmentId = searchParams.get("assignmentId");

    const snap = await db.collection("submissions").where("userId", "==", session.uid).limit(200).get();
    const all = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));

    const filtered = assignmentId
      ? all.filter((s) => String(s["assignmentId"]) === assignmentId)
      : all;

    return NextResponse.json({ items: filtered });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const contentType = request.headers.get("content-type") || "";
    const isMultipart = contentType.toLowerCase().includes("multipart/form-data");

    if (!isMultipart) {
      const body = await request.json();
      const assignmentId: string = body.assignmentId;
      const textAnswer: string = body.textAnswer || "";
      const isFinal: boolean = Boolean(body.isFinal);

      if (!assignmentId) return NextResponse.json({ error: "assignmentId is required" }, { status: 400 });

      // Compute next version
      const snap = await db.collection("submissions").where("userId", "==", session.uid).limit(200).get();
      const all = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));
      const existing = all.filter((s) => String(s["assignmentId"]) === assignmentId);
      const version = existing.length + 1;

      const status: "draft" | "submitted" | "graded" = isFinal ? "submitted" : "draft";

      const docPayload = {
        assignmentId,
        userId: session.uid,
        assignmentUserKey: `${assignmentId}_${session.uid}`,
        textAnswer,
        files: [] as FileMeta[],
        version,
        status,
        submittedAt: isFinal ? db.FieldValue.serverTimestamp() : null,
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      };

      const ref = await db.collection("submissions").add(docPayload);

      if (isFinal) {
        try {
          await db.collection("assignments").doc(assignmentId).update({ status: "submitted", updatedAt: db.FieldValue.serverTimestamp() });
        } catch {
          // ignore if assignment missing
        }
      }

      return NextResponse.json({ success: true, id: ref.id, version });
    }

    // Multipart upload case
    const form = await request.formData();
    const assignmentId = String(form.get("assignmentId") || "");
    const textAnswer = String(form.get("textAnswer") || "");
    const isFinal = String(form.get("isFinal") || "false").toLowerCase() === "true";

    if (!assignmentId) return NextResponse.json({ error: "assignmentId is required" }, { status: 400 });

    const uploads: FileMeta[] = [];
    const files: File[] = [];

    form.forEach((value, key) => {
      if (value instanceof File && (key === "file" || key === "files")) {
        files.push(value);
      }
    });

    const apiKey = process.env.COSMIC_FILES_SECRET || process.env.COSMIC_FILES_API_KEY || "";
    const userId = process.env.USER_ID || "";
    const projectId = process.env.NEXT_PUBLIC_CLIENT_ID || "";

    for (const f of files) {
      const out = new FormData();
      out.set("userId", userId);
      out.set("projectId", projectId);
      out.set("creatorId", session.uid);
      out.set("file", f, f.name);

      const res = await fetch("https://files.cosmic.new/files/upload", {
        method: "POST",
        headers: { "X-API-Key": apiKey },
        body: out
      });
      if (!res.ok) {
        // Fallback: skip this file
        continue;
      }
      const j = (await res.json()) as { fileId: string; fileName: string; fileType: string; fileSize: number };
      uploads.push({ fileId: j.fileId, fileName: j.fileName, fileType: j.fileType, fileSize: j.fileSize });
    }

    // Compute next version
    const snap = await db.collection("submissions").where("userId", "==", session.uid).limit(200).get();
    const all = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));
    const existing = all.filter((s) => String(s["assignmentId"]) === assignmentId);
    const version = existing.length + 1;

    const status: "draft" | "submitted" | "graded" = isFinal ? "submitted" : "draft";

    const docPayload = {
      assignmentId,
      userId: session.uid,
      assignmentUserKey: `${assignmentId}_${session.uid}`,
      textAnswer,
      files: uploads,
      version,
      status,
      submittedAt: isFinal ? db.FieldValue.serverTimestamp() : null,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const ref = await db.collection("submissions").add(docPayload);

    if (isFinal) {
      try {
        await db.collection("assignments").doc(assignmentId).update({ status: "submitted", updatedAt: db.FieldValue.serverTimestamp() });
      } catch {
        // ignore
      }
    }

    return NextResponse.json({ success: true, id: ref.id, version, files: uploads });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const body = await request.json();
    const submissionId: string = body.submissionId;
    if (!submissionId) return NextResponse.json({ error: "submissionId is required" }, { status: 400 });

    const doc = await db.collection("submissions").doc(submissionId).get();
    if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const data = doc.data() as Record<string, unknown>;
    if (data.userId !== session.uid) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const updates: Record<string, unknown> = {};
    if (typeof body.textAnswer === "string") updates.textAnswer = body.textAnswer;
    if (Array.isArray(body.files)) updates.files = body.files as FileMeta[];
    if (typeof body.status === "string") updates.status = body.status as "draft" | "submitted" | "graded";

    updates.updatedAt = db.FieldValue.serverTimestamp();

    await db.collection("submissions").doc(submissionId).update(updates);
    return NextResponse.json({ success: true });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
