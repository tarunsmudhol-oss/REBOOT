import { NextResponse } from "next/server";
import { getServerSession } from "cosmic-authentication";

export async function POST(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const body = await request.json();
    const subject: string = body.subject || "";
    const assignmentText: string = body.assignmentText || "";

    const apiKey = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY || "";
    if (!apiKey) {
      return NextResponse.json({
        tips: [
          "Break the task into smaller parts and set mini-deadlines.",
          "Skim the rubric; highlight verbs like describe, compare, evaluate.",
          "Draft -> revise -> proofread. Submit with a short self‑reflection."
        ],
        outline: ["Introduction", "Main Arguments with Evidence", "Conclusion + References"],
        checklist: ["Follow rubric", "Proper citations", "File names clear", "Submitted before deadline"]
      });
    }

    const prompt = `Return concise JSON for assignment assistance with fields: tips (array of strings), outline (array of strings), checklist (array of strings). Subject: ${subject}. Details: ${assignmentText}. Keep it simple and actionable.`;

    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}` , {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.4 }
        })
      });

      if (!res.ok) throw new Error("Gemini request failed");
      const data = await res.json();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const text: string = (data as any)?.candidates?.[0]?.content?.parts?.[0]?.text || "";
      try {
        const parsed = JSON.parse(text);
        return NextResponse.json(parsed);
      } catch {
        // Fallback basic parsing
        return NextResponse.json({
          tips: ["Scan rubric and plan sections", "Draft quickly, then refine"],
          outline: ["Intro", "Body", "Conclusion"],
          checklist: ["Citations", "Formatting", "Deadline"]
        });
      }
    } catch {
      return NextResponse.json({
        tips: ["Create a 3‑step plan and timeline", "Ask clarifying questions if needed"],
        outline: ["Overview", "Key Points", "References"],
        checklist: ["Clarity", "Evidence", "Submission"]
      });
    }
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
