import { NextResponse } from "next/server";
import { getServerSession } from "cosmic-authentication";
import { db } from "cosmic-database";

interface MessageDoc {
  assignmentId: string;
  assignmentUserKey: string;
  userId: string;
  senderId: string;
  text: string;
}

export async function GET(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const assignmentId = searchParams.get("assignmentId");
    if (!assignmentId) return NextResponse.json({ error: "assignmentId is required" }, { status: 400 });

    const key = `${assignmentId}_${session.uid}`;
    const snap = await db.collection("assignmentThreads").where("assignmentUserKey", "==", key).limit(200).get();
    const items = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));

    // Sort client-side by createdAt if available
    items.sort((a, b) => {
      const at = (a["createdAt"] as { toDate: () => Date } | undefined)?.toDate?.()?.getTime?.() || 0;
      const bt = (b["createdAt"] as { toDate: () => Date } | undefined)?.toDate?.()?.getTime?.() || 0;
      return at - bt;
    });

    return NextResponse.json({ items });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const body = await request.json();
    const assignmentId: string = body.assignmentId;
    const text: string = body.text || "";
    if (!assignmentId || !text) return NextResponse.json({ error: "assignmentId and text are required" }, { status: 400 });

    const payload: MessageDoc & { createdAt: unknown; updatedAt: unknown } = {
      assignmentId,
      assignmentUserKey: `${assignmentId}_${session.uid}`,
      userId: session.uid,
      senderId: session.uid,
      text,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const ref = await db.collection("assignmentThreads").add(payload);

    return NextResponse.json({ success: true, id: ref.id });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
