import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';

export async function POST(request: Request) {
  try {
    const data = await request.json();
    const { email, role, birthdate } = data;

    // Age validation for students
    if (role === 'student') {
      if (!birthdate) {
        return NextResponse.json(
          { error: 'Birthdate is required for student accounts' }, 
          { status: 400 }
        );
      }

      const today = new Date();
      const birthDate = new Date(birthdate);
      const age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      
      // Adjust age if birthday hasn't occurred this year
      const adjustedAge = monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate()) 
        ? age - 1 
        : age;

      if (adjustedAge < 15) {
        return NextResponse.json(
          { error: 'Students must be at least 15 years old to create an account' }, 
          { status: 403 }
        );
      }
    }

    // Create user document
    const userData = {
      email,
      role,
      ...(role === 'student' && { birthdate }),
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };
    
    const docRef = await db.collection('users').add(userData);
    
    return NextResponse.json({ 
      success: true, 
      id: docRef.id,
      role 
    });
  } catch (error) {
    console.error('Error creating user:', error);
    return NextResponse.json(
      { error: 'Internal server error' }, 
      { status: 500 }
    );
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('id');
    const email = searchParams.get('email');
    
    if (userId) {
      // Get specific user by ID
      const doc = await db.collection('users').doc(userId).get();
      if (!doc.exists) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 });
      }
      return NextResponse.json({ id: doc.id, ...doc.data() });
    } else if (email) {
      // Get user by email
      const snapshot = await db.collection('users')
        .where('email', '==', email)
        .limit(1)
        .get();
      
      if (snapshot.empty) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 });
      }
      
      const doc = snapshot.docs[0];
      return NextResponse.json({ id: doc.id, ...doc.data() });
    }
    
    return NextResponse.json({ error: 'User ID or email required' }, { status: 400 });
  } catch (error) {
    console.error('Error fetching user:', error);
    return NextResponse.json(
      { error: 'Internal server error' }, 
      { status: 500 }
    );
  }
}