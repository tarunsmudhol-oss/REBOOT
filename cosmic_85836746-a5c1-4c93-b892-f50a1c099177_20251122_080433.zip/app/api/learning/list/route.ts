import { NextResponse } from "next/server";
import { getServerSession } from "cosmic-authentication";
import { db } from "cosmic-database";

export async function GET(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type");
    const subject = searchParams.get("subject");

    // Single-field query to avoid composite indexes
    const snap = await db.collection("learningContent").where("userId", "==", session.uid).limit(100).get();
    const all = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));

    const filtered = all.filter((d) => {
      const t = (d["type"] as string) || "";
      const s = ((d["subject"] as string) || "").toLowerCase();
      const okType = type ? t === type : true;
      const okSubject = subject ? s.includes(subject.toLowerCase()) : true;
      return okType && okSubject;
    });

    return NextResponse.json({ items: filtered });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
