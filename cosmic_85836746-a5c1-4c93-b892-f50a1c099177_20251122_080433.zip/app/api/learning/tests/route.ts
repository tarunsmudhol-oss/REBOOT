import { NextResponse } from "next/server";
import { getServerSession } from "cosmic-authentication";
import { db } from "cosmic-database";

interface MCQItem {
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
}

async function callOpenAI(subject: string, topic?: string): Promise<MCQItem[]> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return fallbackTest(subject, topic);

  const prompt = `Create a short practice test for subject "${subject}"${topic ? ` and topic "${topic}"` : ""}. Return ONLY JSON array. Each item: {question, options:[A,B,C,D], correctIndex:number (0-3), explanation:string}. Include 10-12 items.`;

  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Output strictly valid JSON only." },
          { role: "user", content: prompt }
        ],
        temperature: 0.2
      })
    });
    if (!res.ok) return fallbackTest(subject, topic);
    const data = (await res.json()) as { choices: Array<{ message: { content: string } }> };
    const raw = data.choices?.[0]?.message?.content || "[]";
    try {
      const parsed = JSON.parse(raw) as MCQItem[];
      return Array.isArray(parsed) && parsed.length > 0 ? parsed : fallbackTest(subject, topic);
    } catch {
      return fallbackTest(subject, topic);
    }
  } catch {
    return fallbackTest(subject, topic);
  }
}

function fallbackTest(subject: string, topic?: string): MCQItem[] {
  return Array.from({ length: 8 }).map((_, i) => ({
    question: `${subject}${topic ? ` (${topic})` : ""}: Sample MCQ ${i + 1}`,
    options: ["Option A", "Option B", "Option C", "Option D"],
    correctIndex: 0,
    explanation: "Practice-only placeholder."
  }));
}

async function uploadTextFile(filename: string, content: string, creatorId: string) {
  const apiKey = process.env.COSMIC_FILES_SECRET;
  const userId = process.env.USER_ID;
  const projectId = process.env.NEXT_PUBLIC_CLIENT_ID;
  if (!apiKey || !userId || !projectId) return null;

  const form = new FormData();
  form.append("userId", userId);
  form.append("projectId", projectId);
  form.append("creatorId", creatorId);
  const blob = new Blob([content], { type: "application/json" });
  form.append("file", blob, filename);

  const up = await fetch("https://files.cosmic.new/files/upload", {
    method: "POST",
    headers: { "X-API-Key": apiKey },
    body: form
  });
  if (!up.ok) return null;
  const meta = (await up.json()) as { fileId: string; fileName: string };
  const fileUrl = `https://files.cosmic.new/files/${userId}/${projectId}?fileId=${meta.fileId}`;
  return { ...meta, fileUrl };
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const body = (await request.json()) as { subject?: string; topic?: string; offline?: boolean };
    const subject = (body.subject || "").trim();
    const topic = (body.topic || "").trim() || undefined;
    const offline = Boolean(body.offline);
    if (!subject) return NextResponse.json({ error: "Subject is required" }, { status: 400 });

    const items = await callOpenAI(subject, topic);

    const payload = {
      userId: session.uid,
      type: "tests" as const,
      subject,
      topic: topic || null,
      items,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const ref = await db.collection("learningContent").add(payload);

    let file: { fileId: string; fileName: string; fileUrl: string } | null = null;
    if (offline) {
      file = await uploadTextFile(
        `tests-${subject.toLowerCase().replace(/\s+/g, "-")}-${Date.now()}.json`,
        JSON.stringify({ subject, topic, items }, null, 2),
        session.uid
      );
    }

    return NextResponse.json({ success: true, id: ref.id, items, file });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg, items: [] }, { status: 200 });
  }
}
