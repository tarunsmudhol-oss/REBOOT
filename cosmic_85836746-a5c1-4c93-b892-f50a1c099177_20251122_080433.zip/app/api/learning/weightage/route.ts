import { NextResponse } from "next/server";
import { getServerSession } from "cosmic-authentication";
import { db } from "cosmic-database";

interface WeightItem {
  topic: string;
  weight: number; // 0-100
}

async function callOpenAI(subject: string): Promise<WeightItem[]> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return fallbackWeightage(subject);

  const prompt = `For subject "${subject}", propose a topic-wise weightage distribution that sums to 100. Return ONLY JSON array of {topic, weight:number}. 6-10 topics preferred.`;

  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Output strictly valid JSON only." },
          { role: "user", content: prompt }
        ],
        temperature: 0.2
      })
    });
    if (!res.ok) return fallbackWeightage(subject);
    const data = (await res.json()) as { choices: Array<{ message: { content: string } }> };
    const raw = data.choices?.[0]?.message?.content || "[]";
    try {
      const parsed = JSON.parse(raw) as WeightItem[];
      return Array.isArray(parsed) && parsed.length > 0 ? parsed : fallbackWeightage(subject);
    } catch {
      return fallbackWeightage(subject);
    }
  } catch {
    return fallbackWeightage(subject);
  }
}

function fallbackWeightage(subject: string): WeightItem[] {
  const topics = ["Foundations", "Core Concepts", "Applications", "Advanced", "Practice", "Revision"];
  const even = Math.floor(100 / topics.length);
  const remaining = 100 - even * topics.length;
  return topics.map((t, i) => ({ topic: `${subject} ${t}`, weight: even + (i === 0 ? remaining : 0) }));
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession();
    if (!session) return NextResponse.json({ error: "Authentication required" }, { status: 401 });

    const body = (await request.json()) as { subject?: string };
    const subject = (body.subject || "").trim();
    if (!subject) return NextResponse.json({ error: "Subject is required" }, { status: 400 });

    const items = await callOpenAI(subject);

    // Normalize to 100
    const total = items.reduce((s, i) => s + (i.weight || 0), 0) || 1;
    const normalized = items.map((i) => ({ topic: i.topic, weight: Math.round((i.weight / total) * 100) }));

    const payload = {
      userId: session.uid,
      type: "weightage" as const,
      subject,
      items: normalized,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const ref = await db.collection("learningContent").add(payload);

    return NextResponse.json({ success: true, id: ref.id, items: normalized });
  } catch (e) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const msg = (e as any)?.message || "Internal server error";
    return NextResponse.json({ error: msg, items: [] }, { status: 200 });
  }
}
