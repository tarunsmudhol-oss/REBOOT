import { NextResponse } from "next/server";
import { getServerSession } from "cosmic-authentication";
import { db } from "cosmic-database";

interface TeacherProfile {
  displayName: string;
  email?: string;
  onboardingCompleted: boolean;
  subjects: string[];
  bio: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any;
}

function pickProfile(data: Record<string, unknown>): TeacherProfile {
  return {
    displayName: typeof data.displayName === "string" ? data.displayName : "",
    email: typeof data.email === "string" ? data.email : undefined,
    onboardingCompleted: typeof data.onboardingCompleted === "boolean" ? data.onboardingCompleted : false,
    subjects: Array.isArray(data.subjects) ? (data.subjects as string[]) : [],
    bio: typeof data.bio === "string" ? data.bio : ""
  };
}

export async function GET() {
  try {
    const user = await getServerSession();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const uid = user.uid;
    const docRef = db.collection("teachers").doc(uid);
    const doc = await docRef.get();

    if (!doc.exists) {
      const seed: TeacherProfile = {
        displayName: user.displayName || "",
        email: user.email,
        onboardingCompleted: false,
        subjects: [],
        bio: ""
      };

      await docRef.set({
        ...seed,
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });

      return NextResponse.json({ profile: seed }, { status: 200 });
    }

    const data = doc.data() as Record<string, unknown>;
    const profile = pickProfile(data);
    return NextResponse.json({ profile }, { status: 200 });
  } catch (err) {
    console.error("/api/teacher GET error", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const uid = user.uid;
    const payload = await request.json();

    // Sanitize allowed fields
    const update: Partial<TeacherProfile> = {};
    if (typeof payload.displayName === "string") update.displayName = payload.displayName;
    if (typeof payload.bio === "string") update.bio = payload.bio;
    if (typeof payload.onboardingCompleted === "boolean") update.onboardingCompleted = payload.onboardingCompleted;
    if (Array.isArray(payload.subjects)) update.subjects = payload.subjects.filter((s: unknown): s is string => typeof s === "string");

    const docRef = db.collection("teachers").doc(uid);
    const snap = await docRef.get();
    if (!snap.exists) {
      // Ensure document exists first in case PUT is called before GET
      await docRef.set({
        displayName: user.displayName || "",
        email: user.email,
        onboardingCompleted: false,
        subjects: [],
        bio: "",
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });
    }

    await docRef.update({
      ...update,
      updatedAt: db.FieldValue.serverTimestamp()
    });

    const updated = await docRef.get();
    const data = updated.data() as Record<string, unknown>;
    const profile = pickProfile(data);
    return NextResponse.json({ success: true, profile }, { status: 200 });
  } catch (err) {
    console.error("/api/teacher PUT error", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
