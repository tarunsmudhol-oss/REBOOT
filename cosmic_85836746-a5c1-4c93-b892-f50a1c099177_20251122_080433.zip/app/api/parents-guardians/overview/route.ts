import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

export async function GET() {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    // Attempt to compute a quick overview using counts; all queries are single-field (guardianId)
    const [assignSnap, notifSnap] = await Promise.all([
      db.collection('guardianAssignments').where('guardianId', '==', user.uid).limit(100).get(),
      db.collection('guardianNotifications').where('guardianId', '==', user.uid).limit(50).get()
    ]);

    const assignments = assignSnap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));
    const pendingCount = assignments.filter((a) => (a as { status?: string }).status === 'pending').length;
    const submittedCount = assignments.filter((a) => (a as { status?: string }).status === 'submitted').length;
    const gradedCount = assignments.filter((a) => (a as { status?: string }).status === 'graded').length;

    // Simple progress metric (demo): graded / total
    const total = assignments.length || 1;
    const progressPct = Math.round((gradedCount / total) * 100);

    const notifications = notifSnap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));

    const overview = {
      progressPct,
      assignments: { total: assignments.length, pending: pendingCount, submitted: submittedCount, graded: gradedCount },
      notificationsCount: notifications.length,
      announcements: notifications.filter((n) => (n as { type?: string }).type === 'announcement').slice(0, 3)
    };

    return NextResponse.json({ overview }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('GET /parents-guardians/overview error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
