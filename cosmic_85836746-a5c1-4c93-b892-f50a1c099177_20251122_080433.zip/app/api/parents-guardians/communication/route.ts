import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface MessageRecord {
  guardianId: string;
  to: string; // teacher/counselor id or name
  subject: string;
  body: string;
  status: 'sent' | 'read' | 'responded';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export async function GET() {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const snap = await db.collection('guardianMessages').where('guardianId', '==', user.uid).limit(100).get();
    const messages = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));
    return NextResponse.json({ messages }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('GET /parents-guardians/communication error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const body = (await request.json()) as Partial<MessageRecord>;
    if (!body.to || !body.subject || !body.body) {
      return NextResponse.json({ error: 'to, subject and body are required' }, { status: 400 });
    }
    const payload: MessageRecord = {
      guardianId: user.uid,
      to: body.to,
      subject: body.subject,
      body: body.body,
      status: 'sent',
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };
    const ref = await db.collection('guardianMessages').add(payload);
    return NextResponse.json({ success: true, id: ref.id }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('POST /parents-guardians/communication error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
