import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface GuardianRecord {
  userId: string;
  guardianName: string;
  guardianEmail: string;
  childDob: string; // ISO string
  isVerified: boolean;
  verificationTimestamp?: unknown | null;
  associatedChildUid?: string | null;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export async function GET() {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const doc = await db.collection('parentsGuardians').doc(sessionUser.uid).get();
    if (!doc.exists) {
      return NextResponse.json({ exists: false }, { status: 200 });
    }

    return NextResponse.json({ exists: true, id: doc.id, ...doc.data() }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('GET /parents-guardians error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const body = await request.json() as Partial<GuardianRecord>;
    if (!body.guardianName || !body.guardianEmail || !body.childDob) {
      return NextResponse.json({ error: 'guardianName, guardianEmail, and childDob are required' }, { status: 400 });
    }

    const payload: GuardianRecord = {
      userId: sessionUser.uid,
      guardianName: body.guardianName,
      guardianEmail: body.guardianEmail,
      childDob: body.childDob,
      isVerified: false, // Always reset until explicit verify
      verificationTimestamp: null,
      associatedChildUid: body.associatedChildUid || null,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    await db.collection('parentsGuardians').doc(sessionUser.uid).set(payload, { merge: true });

    return NextResponse.json({ success: true, id: sessionUser.uid });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('POST /parents-guardians error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
