import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface GuardianProfile {
  guardianId: string;
  preferences?: {
    emailNotifications?: boolean;
    shareReportsWithOtherGuardians?: boolean;
  };
  createdAt?: unknown;
  updatedAt?: unknown;
}

export async function GET() {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    const doc = await db.collection('guardianProfile').doc(user.uid).get();
    if (!doc.exists) return NextResponse.json({ exists: false }, { status: 200 });
    return NextResponse.json({ exists: true, id: doc.id, ...(doc.data() as Record<string, unknown>) }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('GET /parents-guardians/profile error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const body = (await request.json()) as Partial<GuardianProfile>;
    const payload: GuardianProfile = {
      guardianId: user.uid,
      preferences: body.preferences || { emailNotifications: true, shareReportsWithOtherGuardians: false },
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };
    await db.collection('guardianProfile').doc(user.uid).set(payload, { merge: true });
    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('POST /parents-guardians/profile error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
