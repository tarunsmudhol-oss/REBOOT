import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const { searchParams } = new URL(request.url);
    const childId = searchParams.get('childId');

    const assignSnap = await db.collection('guardianAssignments').where('guardianId', '==', user.uid).limit(200).get();
    const rows = assignSnap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }))
      .filter((a) => (childId ? (a as { childId?: string }).childId === childId : true));

    const header = ['Assignment ID', 'Title', 'Due Date', 'Status', 'Grade', 'Teacher Comment'];
    const csv = [
      header.join(','),
      ...rows.map((r) => [
        (r as { id: string }).id,
        JSON.stringify((r as { title?: string }).title || ''),
        JSON.stringify((r as { dueDate?: string }).dueDate || ''),
        JSON.stringify((r as { status?: string }).status || ''),
        JSON.stringify((r as { grade?: string }).grade || ''),
        JSON.stringify((r as { teacherComment?: string }).teacherComment || '')
      ].join(','))
    ].join('\n');

    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': 'attachment; filename="progress_report.csv"'
      }
    });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('GET /parents-guardians/reports error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
