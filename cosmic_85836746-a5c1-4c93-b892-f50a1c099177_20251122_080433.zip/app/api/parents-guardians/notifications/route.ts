import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface NotificationRecord {
  guardianId: string;
  title: string;
  type?: 'announcement' | 'reminder' | 'alert';
  date: string; // ISO
  read?: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export async function GET() {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const snap = await db.collection('guardianNotifications').where('guardianId', '==', user.uid).limit(100).get();
    const notifications = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));
    return NextResponse.json({ notifications }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('GET /parents-guardians/notifications error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const body = (await request.json()) as Partial<NotificationRecord>;
    if (!body.title || !body.date) {
      return NextResponse.json({ error: 'title and date are required' }, { status: 400 });
    }
    const payload: NotificationRecord = {
      guardianId: user.uid,
      title: body.title,
      type: (body.type as NotificationRecord['type']) || 'announcement',
      date: body.date,
      read: false,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };
    const ref = await db.collection('guardianNotifications').add(payload);
    return NextResponse.json({ success: true, id: ref.id }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('POST /parents-guardians/notifications error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
