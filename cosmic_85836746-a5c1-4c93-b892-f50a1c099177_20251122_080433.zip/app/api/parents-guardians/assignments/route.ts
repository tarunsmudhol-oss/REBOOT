import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface AssignmentRecord {
  guardianId: string;
  childId?: string;
  title: string;
  dueDate: string; // ISO
  status: 'pending' | 'submitted' | 'graded';
  grade?: string;
  teacherComment?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const { searchParams } = new URL(request.url);
    const childId = searchParams.get('childId');

    const snap = await db.collection('guardianAssignments').where('guardianId', '==', user.uid).limit(100).get();
    let assignments = snap.docs.map((doc) => ({ id: doc.id, ...(doc.data() as Record<string, unknown>) }));
    if (childId) assignments = assignments.filter((a) => (a as { childId?: string }).childId === childId);
    return NextResponse.json({ assignments }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('GET /parents-guardians/assignments error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    const body = (await request.json()) as Partial<AssignmentRecord>;
    if (!body.title || !body.dueDate) {
      return NextResponse.json({ error: 'title and dueDate are required' }, { status: 400 });
    }
    const payload: AssignmentRecord = {
      guardianId: user.uid,
      childId: body.childId || '',
      title: body.title,
      dueDate: body.dueDate,
      status: (body.status as AssignmentRecord['status']) || 'pending',
      grade: body.grade || '',
      teacherComment: body.teacherComment || '',
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const ref = await db.collection('guardianAssignments').add(payload);
    return NextResponse.json({ success: true, id: ref.id }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('POST /parents-guardians/assignments error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
