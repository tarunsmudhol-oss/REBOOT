import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

function calculateAge(dobIso: string): number {
  const today = new Date();
  const birthDate = new Date(dobIso);
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age -= 1;
  }
  return age;
}

export async function POST() {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const ref = db.collection('parentsGuardians').doc(sessionUser.uid);
    const doc = await ref.get();
    if (!doc.exists) {
      return NextResponse.json({ error: 'Please save guardian details first' }, { status: 400 });
    }
    const data = doc.data() as { childDob?: string };
    if (!data?.childDob) {
      return NextResponse.json({ error: 'Missing child date of birth' }, { status: 400 });
    }

    const age = calculateAge(data.childDob);
    if (age < 14) {
      return NextResponse.json({ error: 'Access denied: associated child must be at least 14 years old' }, { status: 403 });
    }

    await ref.set({
      isVerified: true,
      verificationTimestamp: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    }, { merge: true });

    return NextResponse.json({ success: true });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('POST /parents-guardians/verify error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
