import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface FeeRecord {
  guardianId: string;
  childId?: string;
  term: string;
  amount: number;
  dueDate: string; // ISO
  status: 'due' | 'paid' | 'overdue';
  receiptUrl?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const { searchParams } = new URL(request.url);
    const childId = searchParams.get('childId');

    const snap = await db.collection('guardianFees').where('guardianId', '==', user.uid).limit(100).get();
    let fees = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));
    if (childId) fees = fees.filter((f) => (f as { childId?: string }).childId === childId);
    return NextResponse.json({ fees }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('GET /parents-guardians/fees error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const body = (await request.json()) as Partial<FeeRecord>;
    if (!body.term || typeof body.amount !== 'number' || !body.dueDate) {
      return NextResponse.json({ error: 'term, amount, dueDate are required' }, { status: 400 });
    }
    const payload: FeeRecord = {
      guardianId: user.uid,
      childId: body.childId || '',
      term: body.term,
      amount: body.amount,
      dueDate: body.dueDate,
      status: (body.status as FeeRecord['status']) || 'due',
      receiptUrl: body.receiptUrl || '',
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };
    const ref = await db.collection('guardianFees').add(payload);
    return NextResponse.json({ success: true, id: ref.id }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('POST /parents-guardians/fees error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
