import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface WellbeingRecord {
  guardianId: string;
  childId?: string;
  date: string; // ISO
  mood?: string;
  note?: string;
  counselorNote?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const { searchParams } = new URL(request.url);
    const childId = searchParams.get('childId');

    const snap = await db.collection('guardianWellbeing').where('guardianId', '==', user.uid).limit(100).get();
    let items = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Record<string, unknown>) }));
    if (childId) items = items.filter((it) => (it as { childId?: string }).childId === childId);
    return NextResponse.json({ items }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('GET /parents-guardians/wellbeing error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const body = (await request.json()) as Partial<WellbeingRecord>;
    if (!body.date) {
      return NextResponse.json({ error: 'date is required' }, { status: 400 });
    }
    const payload: WellbeingRecord = {
      guardianId: user.uid,
      childId: body.childId || '',
      date: body.date,
      mood: body.mood || '',
      note: body.note || '',
      counselorNote: body.counselorNote || '',
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };
    const ref = await db.collection('guardianWellbeing').add(payload);
    return NextResponse.json({ success: true, id: ref.id }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('POST /parents-guardians/wellbeing error:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
