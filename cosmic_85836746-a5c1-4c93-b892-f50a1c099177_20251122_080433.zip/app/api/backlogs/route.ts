import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';
import { getServerSession } from 'cosmic-authentication';

interface BacklogItem {
  id?: string;
  userId: string;
  topic: string;
  status: 'red' | 'yellow' | 'green';
  notes?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

function validateStatus(status: unknown): status is 'red' | 'yellow' | 'green' {
  return status === 'red' || status === 'yellow' || status === 'green';
}

export async function GET() {
  try {
    const user = await getServerSession();
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const snapshot = await db
      .collection('backlogs')
      .where('userId', '==', user.uid)
      .limit(500)
      .get();

    const items: BacklogItem[] = snapshot.docs.map((doc) => ({ id: doc.id, ...(doc.data() as Omit<BacklogItem, 'id'>) }));

    return NextResponse.json({ items }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('Error fetching backlogs:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const body = (await request.json()) as Partial<BacklogItem>;

    if (!body.topic || typeof body.topic !== 'string') {
      return NextResponse.json({ error: 'Topic is required' }, { status: 400 });
    }
    if (!validateStatus(body.status)) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 });
    }

    const payload: BacklogItem = {
      userId: user.uid,
      topic: body.topic.trim(),
      status: body.status,
      notes: (body.notes || '').toString().slice(0, 2000),
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    const ref = await db.collection('backlogs').add(payload);

    return NextResponse.json({ success: true, id: ref.id, item: { id: ref.id, ...payload } }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('Error creating backlog:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const body = (await request.json()) as Partial<BacklogItem> & { id?: string };
    const { id } = body;
    if (!id) {
      return NextResponse.json({ error: 'Missing id' }, { status: 400 });
    }

    const update: Record<string, unknown> = { updatedAt: db.FieldValue.serverTimestamp() };

    if (typeof body.topic === 'string') {
      update.topic = body.topic.trim();
    }
    if (typeof body.notes === 'string') {
      update.notes = body.notes.slice(0, 2000);
    }
    if (body.status && validateStatus(body.status)) {
      update.status = body.status;
    }

    // Verify ownership before update (single-field query to avoid composite index)
    const docRef = db.collection('backlogs').doc(id);
    const doc = await docRef.get();
    if (!doc.exists) {
      return NextResponse.json({ error: 'Item not found' }, { status: 404 });
    }
    const data = doc.data() as BacklogItem;
    if (data.userId !== user.uid) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    await docRef.set(update, { merge: true });

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error('Error updating backlog:', (error as any)?.message || error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
