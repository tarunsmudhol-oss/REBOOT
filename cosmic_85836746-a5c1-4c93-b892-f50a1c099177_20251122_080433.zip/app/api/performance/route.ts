import { NextResponse } from "next/server";
import { db } from "cosmic-database";
import { getServerSession } from "cosmic-authentication";

interface TimetableItem {
  id: string;
  label: string;
  subject?: string;
  topic?: string;
  exam?: string;
  done: boolean;
}

interface PerformanceDoc {
  uid: string;
  userGoal?: {
    subjects?: string[];
    exams?: string[];
    notes?: string;
  };
  profile?: {
    grade?: string;
    subjects?: string[];
    targetExam?: string;
  };
  courseProgress?: {
    level?: string; // "1-8" | "10-12" | "UG" | "PG"
    selectionType?: "subject" | "topic" | "exam";
    selectionValue?: string;
  };
  aiAssist?: {
    input?: {
      grades?: string;
      marks?: string;
      performanceNotes?: string;
    };
    plan?: {
      dailyGoals?: string[];
      timetable?: string[];
      testSchedule?: {
        weekly?: string;
        monthly?: string;
      };
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recommendations?: any;
    };
    lastPlanAt?: unknown;
  };
  timetable?: {
    items?: TimetableItem[];
  };
  reminders?: {
    daily?: boolean;
    lastCompletedDate?: string; // ISO date string (yyyy-mm-dd)
    streakCount?: number;
  };
  preferences?: {
    overlayEnabled?: boolean;
    overlayIntensity?: number;
    nightMode?: boolean;
  };
  metrics?: {
    timeSpentSec?: number;
    accuracy?: number;
    updatedAt?: string;
  };
  createdAt?: unknown;
  updatedAt?: unknown;
}

export async function GET(request: Request) {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const uid = searchParams.get("uid") || sessionUser.uid;

    const ref = db.collection("performance").doc(uid);
    const doc = await ref.get();
    if (!doc.exists) {
      return NextResponse.json({ exists: false, data: {} }, { status: 200 });
    }
    return NextResponse.json({ exists: true, id: doc.id, ...doc.data() }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error("Error fetching performance:", (error as any)?.message || error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const body = (await request.json()) as Partial<PerformanceDoc>;

    const payload: PerformanceDoc = {
      uid: sessionUser.uid,
      userGoal: body.userGoal || {},
      profile: body.profile || {},
      courseProgress: body.courseProgress || {},
      aiAssist: body.aiAssist || {},
      timetable: body.timetable || { items: [] },
      reminders: body.reminders || { daily: true, streakCount: 0 },
      preferences: body.preferences || { overlayEnabled: false, overlayIntensity: 0.6 },
      metrics: body.metrics || {},
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp()
    };

    await db.collection("performance").doc(sessionUser.uid).set(payload);
    return NextResponse.json({ success: true, id: sessionUser.uid, data: payload }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error("Error creating performance:", (error as any)?.message || error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const body = (await request.json()) as {
      section?: keyof PerformanceDoc;
      data?: unknown;
      operation?: string;
    };

    const ref = db.collection("performance").doc(sessionUser.uid);
    const snap = await ref.get();
    const existing = (snap.exists ? (snap.data() as PerformanceDoc) : { uid: sessionUser.uid }) as PerformanceDoc;

    // Handle special operation for reminders: completeDaily
    if (body.section === "reminders" && body.operation === "completeDaily") {
      const todayIso = new Date().toISOString().split("T")[0];
      const last = existing.reminders?.lastCompletedDate;
      let streak = existing.reminders?.streakCount || 0;

      if (!last) {
        streak = 1;
      } else {
        const lastDate = new Date(last);
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const lastIso = lastDate.toISOString().split("T")[0];
        const yIso = yesterday.toISOString().split("T")[0];
        if (lastIso === todayIso) {
          // already counted today
        } else if (lastIso === yIso) {
          streak += 1;
        } else {
          streak = 1;
        }
      }

      const update: Partial<PerformanceDoc> = {
        reminders: {
          daily: true,
          lastCompletedDate: todayIso,
          streakCount: streak
        }
      };

      await ref.set({ ...existing, ...update, updatedAt: db.FieldValue.serverTimestamp() }, { merge: true });
      return NextResponse.json({ success: true, reminders: update.reminders }, { status: 200 });
    }

    // Generic merge by section
    if (body.section) {
      const update = { [body.section]: body.data } as Partial<PerformanceDoc>;
      await ref.set({ ...existing, ...update, updatedAt: db.FieldValue.serverTimestamp() }, { merge: true });
      return NextResponse.json({ success: true }, { status: 200 });
    }

    return NextResponse.json({ error: "Missing section" }, { status: 400 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error("Error updating performance:", (error as any)?.message || error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
