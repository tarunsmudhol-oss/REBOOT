import { NextResponse } from "next/server";
import { db } from "cosmic-database";
import { getServerSession } from "cosmic-authentication";

interface AiAssistInput {
  grades?: string;
  marks?: string;
  performanceNotes?: string;
}

export async function POST(request: Request) {
  try {
    const sessionUser = await getServerSession();
    if (!sessionUser) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const body = (await request.json()) as { input: AiAssistInput };
    const input = body?.input || {};

    let plan: {
      dailyGoals: string[];
      timetable: string[];
      testSchedule: { weekly: string; monthly: string };
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recommendations?: any;
    } | null = null;

    // Prefer Google Generative AI (Gemini)
    const googleKey = process.env.GOOGLE_API_KEY;
    if (googleKey) {
      try {
        const model = "gemini-1.5-flash";
        const prompt = `You are an academic coach. Based on the student's grades, marks, and notes, produce a compact JSON object with keys: dailyGoals (array of 5 concise tasks), timetable (array of 5 concise time-slot strings), testSchedule ({ weekly, monthly }), and recommendations (array of 3 resource suggestions). Keep responses short and JSON-only.`;
        const userContent = `Grades: ${input.grades || "-"}\nMarks: ${input.marks || "-"}\nNotes: ${input.performanceNotes || "-"}`;

        const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${googleKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              { role: "user", parts: [{ text: `${prompt}\n\n${userContent}` }] }
            ],
            generationConfig: { temperature: 0.3 }
          })
        });
        if (resp.ok) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const json = (await resp.json()) as any;
          const text: string = json?.candidates?.[0]?.content?.parts?.[0]?.text || "";
          const start = text.indexOf("{");
          const end = text.lastIndexOf("}");
          if (start !== -1 && end !== -1) {
            const slice = text.slice(start, end + 1);
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const parsed = JSON.parse(slice) as any;
            plan = {
              dailyGoals: Array.isArray(parsed.dailyGoals) ? parsed.dailyGoals.slice(0, 5).map((s: unknown) => String(s)) : [
                "Study 45 min",
                "Revise notes",
                "Practice 10 MCQs",
                "Review mistakes",
                "Read 10 pages"
              ],
              timetable: Array.isArray(parsed.timetable) ? parsed.timetable.slice(0, 5).map((s: unknown) => String(s)) : [
                "6-7am Reading",
                "7-7:45am Math",
                "5-6pm Science",
                "6-6:30pm Break",
                "6:30-7pm Review"
              ],
              testSchedule: {
                weekly: parsed?.testSchedule?.weekly ? String(parsed.testSchedule.weekly) : "Weekly quiz every Sunday 6pm",
                monthly: parsed?.testSchedule?.monthly ? String(parsed.testSchedule.monthly) : "Monthly mock on last Saturday"
              },
              recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations.slice(0, 3) : [
                "Short recap video for weak topics",
                "10-question quiz on mistakes",
                "One-page notes summary"
              ]
            };
          }
        }
      } catch (err) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        console.warn("Google AI fallback:", (err as any)?.message || err);
      }
    }

    // Optional: fallback to OpenAI if configured
    if (!plan) {
      const key = process.env.OPENAI_API_KEY;
      if (key) {
        try {
          const prompt = `You are an academic coach. Based on the student's grades, marks, and notes, produce a compact JSON plan with keys dailyGoals (array of 5 concise tasks), timetable (array of 5 concise time-slot strings), and testSchedule (object with weekly and monthly strings). Keep answers short.`;
          const userContent = `Grades: ${input.grades || "-"}\nMarks: ${input.marks || "-"}\nNotes: ${input.performanceNotes || "-"}`;
          const resp = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${key}`
            },
            body: JSON.stringify({
              model: "gpt-4o-mini",
              messages: [
                { role: "system", content: prompt },
                { role: "user", content: userContent }
              ],
              temperature: 0.3
            })
          });
          if (resp.ok) {
            const json = (await resp.json()) as { choices?: Array<{ message?: { content?: string } }> };
            const text = json?.choices?.[0]?.message?.content || "";
            const start = text.indexOf("{");
            const end = text.lastIndexOf("}");
            if (start !== -1 && end !== -1) {
              const slice = text.slice(start, end + 1);
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              const parsed = JSON.parse(slice) as any;
              plan = {
                dailyGoals: Array.isArray(parsed.dailyGoals) ? parsed.dailyGoals.slice(0, 5).map((s: unknown) => String(s)) : ["Study 45 min", "Revise notes", "Practice 10 MCQs", "Review mistakes", "Read 10 pages"],
                timetable: Array.isArray(parsed.timetable) ? parsed.timetable.slice(0, 5).map((s: unknown) => String(s)) : ["6-7am Reading", "7-7:45am Math", "5-6pm Science", "6-6:30pm Break", "6:30-7pm Review"],
                testSchedule: {
                  weekly: parsed?.testSchedule?.weekly ? String(parsed.testSchedule.weekly) : "Weekly quiz every Sunday 6pm",
                  monthly: parsed?.testSchedule?.monthly ? String(parsed.testSchedule.monthly) : "Monthly mock on last Saturday"
                }
              };
            }
          }
        } catch (err) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          console.warn("OpenAI fallback:", (err as any)?.message || err);
        }
      }
    }

    if (!plan) {
      // Final fallback simple plan
      plan = {
        dailyGoals: ["Study 45 min", "Revise notes", "Practice 10 MCQs", "Review mistakes", "Plan tomorrow"],
        timetable: ["6-7am Reading", "7-7:45am Math", "5-6pm Science", "6-6:30pm Break", "6:30-7pm Review"],
        testSchedule: { weekly: "Weekly quiz every Sunday 6pm", monthly: "Monthly mock on last Saturday" }
      };
    }

    // Save to DB
    const ref = db.collection("performance").doc(sessionUser.uid);
    await ref.set(
      {
        uid: sessionUser.uid,
        aiAssist: {
          input,
          plan,
          provider: googleKey ? "google" : (process.env.OPENAI_API_KEY ? "openai" : "fallback"),
          lastPlanAt: db.FieldValue.serverTimestamp()
        },
        updatedAt: db.FieldValue.serverTimestamp(),
        createdAt: db.FieldValue.serverTimestamp()
      },
      { merge: true }
    );

    return NextResponse.json({ success: true, plan }, { status: 200 });
  } catch (error) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    console.error("AI Assist error:", (error as any)?.message || error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
