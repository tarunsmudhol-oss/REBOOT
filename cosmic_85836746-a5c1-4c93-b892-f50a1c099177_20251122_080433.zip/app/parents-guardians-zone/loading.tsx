export default function Loading() {
  return (
    <div className="min-h-screen bg-white text-slate-900">
      <div className="max-w-5xl mx-auto px-4 md:px-6 py-16">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-64 bg-slate-200 rounded" />
          <div className="h-32 bg-slate-200/80 rounded-xl" />
          <div className="h-24 bg-slate-200/70 rounded-xl" />
        </div>
      </div>
    </div>
  );
}
