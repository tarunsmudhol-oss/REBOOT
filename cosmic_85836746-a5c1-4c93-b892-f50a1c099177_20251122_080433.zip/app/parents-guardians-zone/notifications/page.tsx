"use client";

import React, { useEffect, useState } from "react";

interface NotificationItem {
  id: string;
  title: string;
  type?: string;
  date: string;
  read?: boolean;
}

export default function GuardianNotificationsPage() {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const load = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/parents-guardians/notifications', { cache: 'no-store' });
      const data = await res.json();
      if (res.ok) setItems((data.notifications || []) as NotificationItem[]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">Notifications & Alerts</h1>
        <p className="text-sm text-slate-600 mt-1">In-app alerts for guardian updates.</p>
      </section>
      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        {loading ? (
          <p className="text-sm text-slate-600">Loading…</p>
        ) : items.length === 0 ? (
          <p className="text-sm text-slate-600">No notifications yet.</p>
        ) : (
          <ul className="space-y-2">
            {items.map((n) => (
              <li key={n.id} className="rounded border border-slate-200 p-3 bg-slate-50">
                <p className="text-sm text-slate-900">{n.title}</p>
                <p className="text-xs text-slate-600">{n.type || '—'} · {n.date}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
