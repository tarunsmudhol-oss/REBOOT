"use client";

import React, { useEffect, useState } from "react";

interface Preferences {
  emailNotifications?: boolean;
  shareReportsWithOtherGuardians?: boolean;
}

export default function GuardianPrivacySecurityPage() {
  const [prefs, setPrefs] = useState<Preferences>({ emailNotifications: true, shareReportsWithOtherGuardians: false });
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [message, setMessage] = useState<string>("");

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch('/api/parents-guardians/profile', { cache: 'no-store' });
        const data = await res.json();
        if (res.ok && data.exists && data.preferences) setPrefs(data.preferences as Preferences);
      } finally {
        setLoading(false);
      }
    };
    void load();
  }, []);

  const save = async () => {
    try {
      setSaving(true);
      setMessage('');
      const res = await fetch('/api/parents-guardians/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ preferences: prefs })
      });
      if (res.ok) setMessage('Saved');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">Privacy & Security</h1>
        <p className="text-sm text-slate-600 mt-1">Role-based access and data visibility controls.</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        {loading ? (
          <p className="text-sm text-slate-600">Loading…</p>
        ) : (
          <div className="rounded border border-slate-200 p-4 bg-white">
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm text-slate-900">Email notifications</p>
                <p className="text-xs text-slate-500">Receive updates about assignments, events, and messages.</p>
              </div>
              <input type="checkbox" checked={Boolean(prefs.emailNotifications)} onChange={(e) => setPrefs({ ...prefs, emailNotifications: e.target.checked })} className="h-4 w-4" />
            </div>
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="text-sm text-slate-900">Share reports with other guardians</p>
                <p className="text-xs text-slate-500">Allow co-guardians to view downloadable reports.</p>
              </div>
              <input type="checkbox" checked={Boolean(prefs.shareReportsWithOtherGuardians)} onChange={(e) => setPrefs({ ...prefs, shareReportsWithOtherGuardians: e.target.checked })} className="h-4 w-4" />
            </div>
            <div className="mt-3">
              <button onClick={save} disabled={saving} className="h-9 px-4 rounded bg-slate-900 text-white text-sm disabled:opacity-60">{saving ? 'Saving…' : 'Save Settings'}</button>
              {message && <span className="ml-3 text-sm text-green-600">{message}</span>}
            </div>
            <div className="mt-4 rounded-md border border-yellow-300 bg-yellow-50 text-yellow-900 p-3 text-xs">
              <p>Only verified parents/guardians can access this data. Children under 14 are blocked.</p>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
