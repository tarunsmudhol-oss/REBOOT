"use client";

import React, { useEffect, useState } from "react";

interface EventItem {
  id: string;
  title: string;
  date: string;
  location?: string;
  rsvp?: 'yes' | 'no' | 'maybe' | '';
}

export default function GuardianEventsPage() {
  const [items, setItems] = useState<EventItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [form, setForm] = useState<Omit<EventItem, 'id'>>({ title: '', date: '', location: '', rsvp: '' });
  const [saving, setSaving] = useState<boolean>(false);

  const load = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/parents-guardians/events', { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to load');
      setItems((data.events || []) as EventItem[]);
    } catch {
      setError('Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const add = async () => {
    try {
      setSaving(true);
      setError('');
      const res = await fetch('/api/parents-guardians/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to add');
      setForm({ title: '', date: '', location: '', rsvp: '' });
      await load();
    } catch {
      setError('Failed to add');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">School Events & Calendar</h1>
        <p className="text-sm text-slate-600 mt-1">Interactive calendar with RSVP.</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <div className="rounded border border-slate-200 p-4 bg-white">
          <h2 className="text-base font-medium text-slate-900 mb-3">Add Event</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Title</span>
              <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Date</span>
              <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Location</span>
              <input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">RSVP</span>
              <select value={form.rsvp} onChange={(e) => setForm({ ...form, rsvp: e.target.value as EventItem['rsvp'] })} className="h-9 w-full border border-slate-300 rounded px-3 bg-white">
                <option value="">—</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
                <option value="maybe">Maybe</option>
              </select>
            </label>
          </div>
          <div className="mt-3">
            <button onClick={add} disabled={saving} className="h-9 px-4 rounded bg-slate-900 text-white text-sm disabled:opacity-60">{saving ? 'Saving…' : 'Add'}</button>
            {error && <span className="ml-3 text-sm text-red-600">{error}</span>}
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <h2 className="text-base font-medium text-slate-900 mb-2">Events</h2>
        {loading ? (
          <p className="text-sm text-slate-600">Loading…</p>
        ) : items.length === 0 ? (
          <p className="text-sm text-slate-600">No events.</p>
        ) : (
          <ul className="space-y-2">
            {items.map((it) => (
              <li key={it.id} className="rounded border border-slate-200 p-3 bg-slate-50">
                <p className="text-sm text-slate-900">{it.title}</p>
                <p className="text-xs text-slate-600">{it.date} · {it.location || '-'} · RSVP: {it.rsvp || '—'}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
