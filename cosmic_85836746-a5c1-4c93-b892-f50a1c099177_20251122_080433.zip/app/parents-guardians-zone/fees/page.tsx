"use client";

import React, { useEffect, useMemo, useState } from "react";

interface FeeItem {
  id: string;
  term: string;
  amount: number;
  dueDate: string;
  status: 'due' | 'paid' | 'overdue';
  receiptUrl?: string;
}

export default function GuardianFeesPage() {
  const [items, setItems] = useState<FeeItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [form, setForm] = useState<Omit<FeeItem, 'id'>>({ term: '', amount: 0, dueDate: '', status: 'due', receiptUrl: '' });
  const [saving, setSaving] = useState<boolean>(false);

  const totalDue = useMemo(() => items.filter(i => i.status !== 'paid').reduce((sum, i) => sum + (Number(i.amount) || 0), 0), [items]);

  const load = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/parents-guardians/fees', { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to load');
      setItems((data.fees || []) as FeeItem[]);
    } catch {
      setError('Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const add = async () => {
    try {
      setSaving(true);
      setError('');
      const res = await fetch('/api/parents-guardians/fees', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, amount: Number(form.amount) })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to add');
      setForm({ term: '', amount: 0, dueDate: '', status: 'due', receiptUrl: '' });
      await load();
    } catch {
      setError('Failed to add');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">Fee Management</h1>
        <p className="text-sm text-slate-600 mt-1">Overview of fees, schedules, receipts, and payment placeholder.</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="rounded border border-slate-200 p-4 bg-white">
            <p className="text-xs text-slate-500">Total Due</p>
            <p className="text-2xl text-slate-900 mt-1">₹ {totalDue}</p>
          </div>
          <div className="rounded border border-slate-200 p-4 bg-white sm:col-span-2">
            <p className="text-xs text-slate-500 mb-2">Payment Placeholder</p>
            <p className="text-xs text-slate-600">Gateway integration can be added here. For now, view receipts when available.</p>
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <div className="rounded border border-slate-200 p-4 bg-white">
          <h2 className="text-base font-medium text-slate-900 mb-3">Add Fee</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Term</span>
              <input value={form.term} onChange={(e) => setForm({ ...form, term: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Amount</span>
              <input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Due Date</span>
              <input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Status</span>
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as FeeItem['status'] })} className="h-9 w-full border border-slate-300 rounded px-3 bg-white">
                <option value="due">Due</option>
                <option value="paid">Paid</option>
                <option value="overdue">Overdue</option>
              </select>
            </label>
          </div>
          <div className="mt-3">
            <button onClick={add} disabled={saving} className="h-9 px-4 rounded bg-slate-900 text-white text-sm disabled:opacity-60">{saving ? 'Saving…' : 'Add'}</button>
            {error && <span className="ml-3 text-sm text-red-600">{error}</span>}
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <h2 className="text-base font-medium text-slate-900 mb-2">Fees</h2>
        {loading ? (
          <p className="text-sm text-slate-600">Loading…</p>
        ) : items.length === 0 ? (
          <p className="text-sm text-slate-600">No fee items.</p>
        ) : (
          <ul className="space-y-2">
            {items.map((it) => (
              <li key={it.id} className="rounded border border-slate-200 p-3 bg-slate-50">
                <p className="text-sm text-slate-900">{it.term} — ₹ {it.amount}</p>
                <p className="text-xs text-slate-600">Due: {it.dueDate} · Status: {it.status}</p>
                {it.receiptUrl ? <a href={it.receiptUrl} className="text-xs text-blue-700 underline">View Receipt</a> : null}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
