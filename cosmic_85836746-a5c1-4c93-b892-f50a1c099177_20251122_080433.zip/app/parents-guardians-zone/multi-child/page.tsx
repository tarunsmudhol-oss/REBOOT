"use client";

import React, { useEffect, useState } from "react";

interface ChildItem {
  id: string;
  name: string;
  dob: string;
  grade?: string;
  school?: string;
  targetExam?: string;
}

export default function GuardianMultiChildPage() {
  const [children, setChildren] = useState<ChildItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  const load = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/parents-guardians/children', { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to load');
      setChildren((data.children || []) as ChildItem[]);
    } catch {
      setError('Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">Multi-Child Account Management</h1>
        <p className="text-sm text-slate-600 mt-1">Manage profiles and notifications for multiple children.</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        {loading ? (
          <p className="text-sm text-slate-600">Loading…</p>
        ) : error ? (
          <p className="text-sm text-red-600">{error}</p>
        ) : children.length === 0 ? (
          <p className="text-sm text-slate-600">No children added yet. Add children in Profile & Reports.</p>
        ) : (
          <ul className="space-y-2">
            {children.map((c) => (
              <li key={c.id} className="rounded border border-slate-200 p-3 bg-slate-50">
                <p className="text-sm text-slate-900">{c.name}</p>
                <p className="text-xs text-slate-600">DOB: {c.dob} · Grade: {c.grade || '-'} · School: {c.school || '-'}</p>
                <div className="mt-2 text-xs text-slate-500">Notifications and fee tracking consolidate here.</div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
