"use client";

import React, { useEffect, useState } from "react";

interface OverviewData {
  progressPct: number;
  assignments: { total: number; pending: number; submitted: number; graded: number };
  notificationsCount: number;
  announcements: Array<Record<string, unknown>>;
}

export default function GuardianDashboardOverviewPage() {
  const [overview, setOverview] = useState<OverviewData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const res = await fetch('/api/parents-guardians/overview', { cache: 'no-store' });
        if (!res.ok) throw new Error('Failed to load');
        const data = await res.json();
        setOverview(data.overview);
      } catch {
        setError('Failed to load overview');
      } finally {
        setLoading(false);
      }
    };
    void load();
  }, []);

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">Dashboard Overview</h1>
        <p className="text-sm text-slate-600 mt-1">A quick summary of academic progress, upcoming assignments, and announcements.</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        {loading && <p className="text-sm text-slate-600">Loading…</p>}
        {error && <p className="text-sm text-red-600">{error}</p>}
        {overview && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="rounded-lg border border-slate-200 p-4 bg-white">
              <p className="text-xs text-slate-500">Overall Progress</p>
              <p className="text-2xl text-slate-900 mt-1">{overview.progressPct}%</p>
              <div className="mt-2 h-2 w-full bg-slate-100 rounded">
                <div className="h-2 bg-blue-600 rounded" style={{ width: `${overview.progressPct}%` }} />
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 p-4 bg-white">
              <p className="text-xs text-slate-500">Assignments</p>
              <p className="text-sm text-slate-700 mt-1">Total: {overview.assignments.total}</p>
              <p className="text-xs text-slate-600 mt-1">Pending: {overview.assignments.pending} · Submitted: {overview.assignments.submitted} · Graded: {overview.assignments.graded}</p>
            </div>
            <div className="rounded-lg border border-slate-200 p-4 bg-white">
              <p className="text-xs text-slate-500">Notifications</p>
              <p className="text-2xl text-slate-900 mt-1">{overview.notificationsCount}</p>
              <p className="text-xs text-slate-600 mt-1">Recent announcements shown below.</p>
            </div>
          </div>
        )}
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <h2 className="text-base font-medium text-slate-900 mb-2">Announcements</h2>
        {!overview || (overview.announcements?.length ?? 0) === 0 ? (
          <p className="text-sm text-slate-600">No announcements.</p>
        ) : (
          <ul className="space-y-2">
            {overview.announcements.map((a, idx) => (
              <li key={idx} className="rounded border border-slate-200 p-3 bg-slate-50">
                <p className="text-sm text-slate-800">{(a as { title?: string }).title || 'Announcement'}</p>
                <p className="text-xs text-slate-500">{(a as { date?: string }).date || ''}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
