"use client";

import React, { useEffect, useState } from "react";

interface ResourceItem {
  id: string;
  title: string;
  url: string;
  note?: string;
}

export default function GuardianResourcesPage() {
  const [items, setItems] = useState<ResourceItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [form, setForm] = useState<Omit<ResourceItem, 'id'>>({ title: '', url: '', note: '' });
  const [saving, setSaving] = useState<boolean>(false);

  const load = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/parents-guardians/resources', { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to load');
      setItems((data.resources || []) as ResourceItem[]);
    } catch {
      setError('Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const add = async () => {
    try {
      setSaving(true);
      setError('');
      const res = await fetch('/api/parents-guardians/resources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to add');
      setForm({ title: '', url: '', note: '' });
      await load();
    } catch {
      setError('Failed to add');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">Learning Resources</h1>
        <p className="text-sm text-slate-600 mt-1">Guides, videos, and links shared by teachers.</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <div className="rounded border border-slate-200 p-4 bg-white">
          <h2 className="text-base font-medium text-slate-900 mb-3">Add Resource</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Title</span>
              <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">URL</span>
              <input value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm md:col-span-3">
              <span className="block mb-1 text-slate-700">Note</span>
              <input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
          </div>
          <div className="mt-3">
            <button onClick={add} disabled={saving} className="h-9 px-4 rounded bg-slate-900 text-white text-sm disabled:opacity-60">{saving ? 'Saving…' : 'Add'}</button>
            {error && <span className="ml-3 text-sm text-red-600">{error}</span>}
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <h2 className="text-base font-medium text-slate-900 mb-2">Resources</h2>
        {loading ? (
          <p className="text-sm text-slate-600">Loading…</p>
        ) : items.length === 0 ? (
          <p className="text-sm text-slate-600">No resources yet.</p>
        ) : (
          <ul className="space-y-2">
            {items.map((it) => (
              <li key={it.id} className="rounded border border-slate-200 p-3 bg-slate-50">
                <a href={it.url} className="text-sm text-blue-700 underline">{it.title}</a>
                {it.note && <p className="text-xs text-slate-600">{it.note}</p>}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
