"use client";

import React, { useEffect, useState } from "react";

interface MessageItem {
  id: string;
  to: string;
  subject: string;
  body: string;
  status: string;
}

export default function GuardianCommunicationPage() {
  const [items, setItems] = useState<MessageItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [form, setForm] = useState<Omit<MessageItem, 'id' | 'status'>>({ to: '', subject: '', body: '' });
  const [saving, setSaving] = useState<boolean>(false);

  const load = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/parents-guardians/communication', { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to load');
      setItems((data.messages || []) as MessageItem[]);
    } catch {
      setError('Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const send = async () => {
    try {
      setSaving(true);
      setError('');
      const res = await fetch('/api/parents-guardians/communication', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to send');
      setForm({ to: '', subject: '', body: '' });
      await load();
    } catch {
      setError('Failed to send');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">Communication Hub</h1>
        <p className="text-sm text-slate-600 mt-1">Secure messaging with teachers and counselors.</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <div className="rounded border border-slate-200 p-4 bg-white">
          <h2 className="text-base font-medium text-slate-900 mb-3">New Message</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">To</span>
              <input value={form.to} onChange={(e) => setForm({ ...form, to: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm md:col-span-2">
              <span className="block mb-1 text-slate-700">Subject</span>
              <input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm md:col-span-3">
              <span className="block mb-1 text-slate-700">Message</span>
              <textarea value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} className="min-h-[90px] w-full border border-slate-300 rounded px-3 py-2" />
            </label>
          </div>
          <div className="mt-3">
            <button onClick={send} disabled={saving} className="h-9 px-4 rounded bg-slate-900 text-white text-sm disabled:opacity-60">{saving ? 'Sending…' : 'Send'}</button>
            {error && <span className="ml-3 text-sm text-red-600">{error}</span>}
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <h2 className="text-base font-medium text-slate-900 mb-2">Messages</h2>
        {loading ? (
          <p className="text-sm text-slate-600">Loading…</p>
        ) : items.length === 0 ? (
          <p className="text-sm text-slate-600">No messages yet.</p>
        ) : (
          <ul className="space-y-2">
            {items.map((it) => (
              <li key={it.id} className="rounded border border-slate-200 p-3 bg-slate-50">
                <p className="text-sm text-slate-900">To: {it.to} · {it.subject}</p>
                <p className="text-xs text-slate-600">{it.body}</p>
                <p className="text-xs text-slate-500 mt-1">Status: {it.status}</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
