import GuardianIntroPanel from "@/app/components/GuardianIntroPanel";
import GuardianIntakeForm from "@/app/components/GuardianIntakeForm";
import VerificationPreviewBox from "@/app/components/VerificationPreviewBox";
import DashboardSectionsOverview from "@/app/components/DashboardSectionsOverview";

export default function ParentsGuardiansZonePage() {
  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <GuardianIntroPanel />
      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-4">
        <div className="text-xs text-slate-500">This page is intended for parents or legal guardians only. Please proceed with verification.</div>
      </section>
      <GuardianIntakeForm />
      <VerificationPreviewBox />
      <DashboardSectionsOverview />
    </div>
  );
}
