"use client";

import React from "react";

export default function GuardianFeedbackSupportPage() {
  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">Feedback & Support</h1>
        <p className="text-sm text-slate-600 mt-1">Submit concerns or suggestions; our staff reviews analytics to improve continuously.</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <div className="rounded border border-slate-200 p-4 bg-white">
          <p className="text-sm text-slate-700">Use our feedback form to share your thoughts. You can also participate in quick polls.</p>
          <div className="mt-3">
            <a href="/feedback" className="h-9 inline-flex items-center px-4 rounded bg-slate-900 text-white text-sm">Open Feedback</a>
            <span className="ml-3 text-xs text-slate-500">Submissions work offline and sync when back online.</span>
          </div>
        </div>
      </section>
    </div>
  );
}
