"use client";

import React, { useEffect, useState } from "react";

interface ChildItem {
  id: string;
  name: string;
  dob: string;
  grade?: string;
  school?: string;
  targetExam?: string;
}

export default function GuardianProfileReportsPage() {
  const [children, setChildren] = useState<ChildItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [form, setForm] = useState<Omit<ChildItem, 'id'>>({ name: '', dob: '', grade: '', school: '', targetExam: '' });
  const [saving, setSaving] = useState<boolean>(false);

  const load = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/parents-guardians/children', { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to load');
      setChildren((data.children || []) as ChildItem[]);
    } catch {
      setError('Failed to load');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const addChild = async () => {
    try {
      setSaving(true);
      setError('');
      const res = await fetch('/api/parents-guardians/children', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Failed to add child');
      setForm({ name: '', dob: '', grade: '', school: '', targetExam: '' });
      await load();
    } catch {
      setError('Failed to add child');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 pb-14">
      <section className="max-w-5xl mx-auto px-4 md:px-6 pt-8 md:pt-12">
        <h1 className="text-2xl md:text-3xl font-medium">Student Profile & Academic Reports</h1>
        <p className="text-sm text-slate-600 mt-1">Manage your child profiles and download progress reports.</p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <div className="rounded-lg border border-slate-200 p-4 bg-white">
          <h2 className="text-base font-medium text-slate-900 mb-3">Add Child</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Name</span>
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Date of Birth</span>
              <input type="date" value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Grade</span>
              <input value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">School/College</span>
              <input value={form.school} onChange={(e) => setForm({ ...form, school: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
            <label className="text-sm">
              <span className="block mb-1 text-slate-700">Target Exam</span>
              <input value={form.targetExam} onChange={(e) => setForm({ ...form, targetExam: e.target.value })} className="h-9 w-full border border-slate-300 rounded px-3" />
            </label>
          </div>
          <div className="mt-3">
            <button onClick={addChild} disabled={saving} className="h-9 px-4 rounded bg-slate-900 text-white text-sm disabled:opacity-60">{saving ? 'Saving…' : 'Save Child'}</button>
            {error && <span className="ml-3 text-sm text-red-600">{error}</span>}
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-6 mt-6">
        <h2 className="text-base font-medium text-slate-900 mb-2">Children</h2>
        {loading ? (
          <p className="text-sm text-slate-600">Loading…</p>
        ) : children.length === 0 ? (
          <p className="text-sm text-slate-600">No children added yet.</p>
        ) : (
          <ul className="space-y-2">
            {children.map((c) => (
              <li key={c.id} className="rounded border border-slate-200 p-3 bg-white">
                <p className="text-sm text-slate-900">{c.name}</p>
                <p className="text-xs text-slate-600">Grade: {c.grade || '-'} · School: {c.school || '-'} · Target: {c.targetExam || '-'}</p>
                <div className="mt-2">
                  <a href={`/api/parents-guardians/reports?childId=${c.id}`} className="text-xs inline-block px-3 py-1 border border-slate-300 rounded bg-white text-slate-700">Download Progress CSV</a>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
