"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import TopHeader from "@/app/components/TopHeader";
import FeedbackForm from "@/app/components/FeedbackForm";
import FAQSection from "@/app/components/FAQSection";

interface PollState {
  course: string;
  facilities: string;
  instructor: string;
}

export default function FeedbackPage() {
  const [poll, setPoll] = useState<PollState>({ course: "", facilities: "", instructor: "" });
  const [pollMsg, setPollMsg] = useState<string>("");
  const [pollLoading, setPollLoading] = useState<boolean>(false);

  const submitPolls = async () => {
    setPollMsg("");
    setPollLoading(true);
    try {
      const payload = {
        feedbackType: 'survey',
        mcqAnswers: {
          course: poll.course,
          facilities: poll.facilities,
          instructor: poll.instructor
        },
        text: 'Quick poll responses'
      };
      const r = await fetch('/api/feedback', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'Failed to submit poll');
      setPollMsg('Thanks! Your poll responses were submitted.');
      setPoll({ course: '', facilities: '', instructor: '' });
    } catch (e) {
      setPollMsg(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setPollLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-white to-teal-50">
      <TopHeader />
      <div className="max-w-6xl mx-auto px-6 py-8">
        <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} transition={{duration:0.6}} className="mb-8">
          <h1 className="text-3xl md:text-4xl font-medium text-slate-900">Feedback</h1>
          <p className="text-slate-600 text-sm mt-2">Colorful, friendly, and fast—share thoughts with stars ⭐, emojis 😊, and quick polls.</p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <FeedbackForm />

            {/* Quick Surveys & Polls */}
            <section>
              <motion.div initial={{opacity:0, y:20}} animate={{opacity:1,y:0}} transition={{duration:0.5}} className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-medium text-slate-900">Quick Polls</h2>
                  <button onClick={submitPolls} disabled={pollLoading} className="text-sm px-3 py-1.5 rounded bg-slate-900 text-white disabled:opacity-50">{pollLoading? 'Submitting…':'Submit'}</button>
                </div>

                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-slate-700 mb-2">Course content quality</p>
                    <div className="flex gap-2">
                      {['Poor','Average','Good','Excellent'].map((opt)=> (
                        <label key={opt} className={`px-3 py-1.5 rounded-lg border cursor-pointer ${poll.course===opt? 'bg-teal-600 text-white border-teal-600':'border-slate-300 text-slate-700'}`}>
                          <input type="radio" name="course" value={opt} className="hidden" onChange={()=>setPoll({...poll, course: opt})} />
                          <span>{opt}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-slate-700 mb-2">Facilities satisfaction</p>
                    <div className="flex gap-2">
                      {['Needs work','Okay','Great'].map((opt)=> (
                        <label key={opt} className={`px-3 py-1.5 rounded-lg border cursor-pointer ${poll.facilities===opt? 'bg-teal-600 text-white border-teal-600':'border-slate-300 text-slate-700'}`}>
                          <input type="radio" name="facilities" value={opt} className="hidden" onChange={()=>setPoll({...poll, facilities: opt})} />
                          <span>{opt}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="md:col-span-2">
                    <p className="text-slate-700 mb-2">Instructor performance</p>
                    <div className="flex gap-2">
                      {['Unsatisfied','Neutral','Satisfied','Very satisfied'].map((opt)=> (
                        <label key={opt} className={`px-3 py-1.5 rounded-lg border cursor-pointer ${poll.instructor===opt? 'bg-teal-600 text-white border-teal-600':'border-slate-300 text-slate-700'}`}>
                          <input type="radio" name="instructor" value={opt} className="hidden" onChange={()=>setPoll({...poll, instructor: opt})} />
                          <span>{opt}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>

                {pollMsg && <p className="mt-3 text-sm text-slate-700">{pollMsg}</p>}
              </motion.div>
            </section>
          </div>

          <div className="space-y-8">
            <FAQSection />
          </div>
        </div>
      </div>
    </div>
  );
}
