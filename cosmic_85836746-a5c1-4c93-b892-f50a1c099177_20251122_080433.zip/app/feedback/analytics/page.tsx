"use client";

import React from "react";
import { motion } from "framer-motion";
import TopHeader from "@/app/components/TopHeader";
import AnalyticsPanel from "@/app/components/AnalyticsPanel";
import FeedbackList from "@/app/components/FeedbackList";

export default function FeedbackAnalyticsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <TopHeader />
      <div className="max-w-7xl mx-auto px-6 py-8">
        <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} transition={{duration:0.6}} className="mb-8">
          <h1 className="text-3xl md:text-4xl font-medium text-slate-900">Feedback Analytics</h1>
          <p className="text-slate-600 text-sm mt-2">Staff-only dashboard with real-time notifications, summaries, and exports.</p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <FeedbackList />
          </div>
          <div>
            <AnalyticsPanel />
          </div>
        </div>
      </div>
    </div>
  );
}
