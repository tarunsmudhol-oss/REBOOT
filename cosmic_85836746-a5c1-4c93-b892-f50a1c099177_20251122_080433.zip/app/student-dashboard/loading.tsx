export default function Loading() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="animate-pulse space-y-6">
          <div className="h-8 w-1/3 bg-slate-200 rounded" />
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-3">
              <div className="h-40 bg-slate-200/80 rounded-xl" />
              <div className="h-64 bg-slate-200/70 rounded-xl" />
            </div>
            <div className="space-y-3">
              <div className="h-52 bg-slate-200/70 rounded-xl" />
              <div className="h-24 bg-slate-200/70 rounded-xl" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
