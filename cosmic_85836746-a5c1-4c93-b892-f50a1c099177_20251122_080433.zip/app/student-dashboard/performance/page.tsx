"use client";

import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import TopHeader from "@/app/components/TopHeader";
import LeftNav from "@/app/components/LeftNav";
import PerformanceHero from "@/app/components/PerformanceHero";
import PerformanceCard from "@/app/components/PerformanceCard";
import { Button } from "@/app/components/Button";
import { Icon } from "@iconify/react";
import LearningSphere from "@/app/components/LearningSphere";
import AIPersonalizationOverlay from "@/app/components/AIPersonalizationOverlay";

interface StudentInfo {
  studentName: string;
  dob: string;
  classLevel: string;
  school: string;
  targetExam: string;
  gender: string;
  previousYearMarks: number;
}

interface TimetableItem {
  id: string;
  label: string;
  subject?: string;
  topic?: string;
  exam?: string;
  done: boolean;
}

interface PerformanceDoc {
  userGoal?: { subjects?: string[]; exams?: string[]; notes?: string };
  profile?: { grade?: string; subjects?: string[]; targetExam?: string };
  courseProgress?: { level?: string; selectionType?: "subject" | "topic" | "exam"; selectionValue?: string };
  aiAssist?: {
    input?: { grades?: string; marks?: string; performanceNotes?: string };
    plan?: { dailyGoals?: string[]; timetable?: string[]; testSchedule?: { weekly?: string; monthly?: string } };
  };
  timetable?: { items?: TimetableItem[] };
  reminders?: { daily?: boolean; lastCompletedDate?: string; streakCount?: number };
  preferences?: { overlayEnabled?: boolean; overlayIntensity?: number; nightMode?: boolean };
}

export default function PerformancePage() {
  const [student, setStudent] = useState<StudentInfo | null>(null);
  const [perf, setPerf] = useState<PerformanceDoc>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string>("");

  // Local form states
  const [goalSubjects, setGoalSubjects] = useState<string>("");
  const [goalExams, setGoalExams] = useState<string>("");
  const [goalNotes, setGoalNotes] = useState<string>("");

  const [profileGrade, setProfileGrade] = useState<string>("");
  const [profileSubjects, setProfileSubjects] = useState<string>("");
  const [profileTargetExam, setProfileTargetExam] = useState<string>("");

  const [level, setLevel] = useState<string>("");
  const [selectionType, setSelectionType] = useState<"subject" | "topic" | "exam">("subject");
  const [selectionValue, setSelectionValue] = useState<string>("");

  const [aiGrades, setAiGrades] = useState<string>("");
  const [aiMarks, setAiMarks] = useState<string>("");
  const [aiNotes, setAiNotes] = useState<string>("");
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  const [taskLabel, setTaskLabel] = useState<string>("");
  const [taskSubject, setTaskSubject] = useState<string>("");
  const [taskTopic, setTaskTopic] = useState<string>("");
  const [taskExam, setTaskExam] = useState<string>("");

  // Overlay controls
  const [overlayEnabled, setOverlayEnabled] = useState<boolean>(false);
  const [overlayIntensity, setOverlayIntensity] = useState<number>(0.6);
  const [nightMode, setNightMode] = useState<boolean>(false);
  // Simple real-time metrics
  const [sessionStart] = useState<number>(() => Date.now());

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      setLoading(true);
      try {
        const [sRes, pRes] = await Promise.all([
          fetch("/api/student-info", { cache: "no-store" }),
          fetch("/api/performance", { cache: "no-store" })
        ]);
        const sJson = await sRes.json();
        const pJson = await pRes.json();
        if (!mounted) return;
        if (sRes.ok && sJson.exists) {
          const info: StudentInfo = {
            studentName: sJson.studentName,
            dob: sJson.dob,
            classLevel: sJson.classLevel,
            school: sJson.school,
            targetExam: sJson.targetExam,
            gender: sJson.gender,
            previousYearMarks: Number(sJson.previousYearMarks || 0)
          };
          setStudent(info);
        }
        if (pRes.ok && (pJson.exists || pJson.id)) {
          const data = pJson as PerformanceDoc;
          setPerf({
            userGoal: data.userGoal || {},
            profile: data.profile || {},
            courseProgress: data.courseProgress || {},
            aiAssist: data.aiAssist || {},
            timetable: data.timetable || { items: [] },
            reminders: data.reminders || { daily: true, streakCount: 0 },
            preferences: data.preferences || { overlayEnabled: false, overlayIntensity: 0.6 }
          });
          // prime forms
          setGoalSubjects((data.userGoal?.subjects || []).join(", "));
          setGoalExams((data.userGoal?.exams || []).join(", "));
          setGoalNotes(data.userGoal?.notes || "");
          setProfileGrade(data.profile?.grade || (sJson?.classLevel || ""));
          setProfileSubjects((data.profile?.subjects || []).join(", "));
          setProfileTargetExam(data.profile?.targetExam || (sJson?.targetExam || ""));
          setLevel(data.courseProgress?.level || "");
          setSelectionType(data.courseProgress?.selectionType || "subject");
          setSelectionValue(data.courseProgress?.selectionValue || "");
          setAiGrades(data.aiAssist?.input?.grades || "");
          setAiMarks(data.aiAssist?.input?.marks || (sJson?.previousYearMarks ? String(sJson.previousYearMarks) : ""));
          setAiNotes(data.aiAssist?.input?.performanceNotes || "");
          setOverlayEnabled(Boolean(data.preferences?.overlayEnabled));
          setOverlayIntensity(typeof data.preferences?.overlayIntensity === "number" ? (data.preferences?.overlayIntensity as number) : 0.6);
          setNightMode(Boolean(data.preferences?.nightMode));
        } else {
          setPerf({});
        }
      } catch {
        setPerf({});
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    return () => {
      mounted = false;
    };
  }, []);

  const profileName = useMemo(() => student?.studentName || "John Doe", [student?.studentName]);

  const saveSection = async (section: keyof PerformanceDoc, data: unknown) => {
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/performance", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ section, data })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to save");
      setPerf((prev) => ({ ...prev, [section]: data as never }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSaving(false);
    }
  };

  const addTask = async () => {
    if (!taskLabel.trim()) return;
    const newItem: TimetableItem = {
      id: `${Date.now()}`,
      label: taskLabel.trim(),
      subject: taskSubject.trim() || undefined,
      topic: taskTopic.trim() || undefined,
      exam: taskExam.trim() || undefined,
      done: false
    };
    const next = { items: [ ...(perf.timetable?.items || []), newItem ] };
    await saveSection("timetable", next);
    setTaskLabel("");
    setTaskSubject("");
    setTaskTopic("");
    setTaskExam("");
  };

  const toggleTask = async (id: string) => {
    const items = (perf.timetable?.items || []).map((it) => it.id === id ? { ...it, done: !it.done } : it);
    await saveSection("timetable", { items });
  };

  const completeToday = async () => {
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/performance", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ section: "reminders", operation: "completeDaily" })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to update streak");
      setPerf((prev) => ({ ...prev, reminders: json.reminders }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSaving(false);
    }
  };

  const runAiAssist = async () => {
    setAiLoading(true);
    setError("");
    try {
      const res = await fetch("/api/performance/ai-assist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input: { grades: aiGrades, marks: aiMarks, performanceNotes: aiNotes } })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "AI Assist failed");
      setPerf((prev) => ({ ...prev, aiAssist: { input: { grades: aiGrades, marks: aiMarks, performanceNotes: aiNotes }, plan: json.plan } }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setAiLoading(false);
    }
  };

  // Derive AI visual mood and next task
  const totalTasks = (perf.timetable?.items || []).length;
  const doneTasks = (perf.timetable?.items || []).filter((t) => t.done).length;
  const doneRatio = totalTasks > 0 ? doneTasks / totalTasks : 0;
  const mood: "rising" | "steady" | "falling" = doneRatio > 0.6 || (perf.reminders?.streakCount || 0) >= 3 ? "rising" : doneRatio < 0.3 ? "falling" : "steady";
  const nextTask = (perf.timetable?.items || []).find((t) => !t.done)?.label;

  // Persist overlay prefs when changed
  useEffect(() => {
    const hour = new Date().getHours();
    const shouldNight = nightMode || hour >= 21 || hour <= 6;
    setNightMode(shouldNight);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onToggleOverlay = async (v: boolean) => {
    setOverlayEnabled(v);
    await saveSection("preferences", { overlayEnabled: v, overlayIntensity, nightMode });
  };
  const onIntensity = async (v: number) => {
    setOverlayIntensity(v);
    await saveSection("preferences", { overlayEnabled, overlayIntensity: v, nightMode });
  };

  // Periodically persist basic metrics (time spent and task completion ratio)
  useEffect(() => {
    const interval = setInterval(() => {
      const seconds = Math.floor((Date.now() - sessionStart) / 1000);
      const total = (perf.timetable?.items || []).length;
      const done = (perf.timetable?.items || []).filter((t) => t.done).length;
      const accuracy = total > 0 ? done / total : 0;
      // Fire and forget; no need to wait
      fetch("/api/performance", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ section: "metrics", data: { timeSpentSec: seconds, accuracy, updatedAt: new Date().toISOString() } })
      }).catch(() => undefined);
    }, 30000);
    const onUnload = () => {
      const seconds = Math.floor((Date.now() - sessionStart) / 1000);
      navigator.sendBeacon?.("/api/performance", new Blob([JSON.stringify({ section: "metrics", data: { timeSpentSec: seconds, updatedAt: new Date().toISOString() } })], { type: "application/json" }));
    };
    window.addEventListener("beforeunload", onUnload);
    return () => {
      clearInterval(interval);
      window.removeEventListener("beforeunload", onUnload);
    };
  }, [perf.timetable?.items, sessionStart]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <TopHeader />
      <div className="flex">
        <LeftNav />
        <div className="flex-1">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <PerformanceHero />

            {/* AI Learning Sphere + Overlay controls */}
            <div className="grid lg:grid-cols-3 gap-6 mb-8">
              <div className="lg:col-span-2">
                <LearningSphere mood={mood} nextTargetId={nextTask ? `n${(nextTask.split("").reduce((a, c) => a + c.charCodeAt(0), 0) % 60)}` : undefined} />
              </div>
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-5 border border-white/20">
                <h3 className="text-base font-medium text-slate-900 mb-2">Personalized Overlay</h3>
                <p className="text-xs text-slate-600 mb-3">Adaptive visuals based on your progress. Toggle anytime.</p>
                <AIPersonalizationOverlay
                  enabled={overlayEnabled}
                  intensity={overlayIntensity}
                  state={mood}
                  nextTask={nextTask}
                  onToggle={onToggleOverlay}
                  onIntensity={onIntensity}
                  nightMode={nightMode}
                />
                <p className="mt-4 text-[11px] text-slate-500">Respects reduced motion settings.</p>
              </div>
            </div>

            {/* Profile Summary (top-right style) */}
            <div className="grid lg:grid-cols-3 gap-6 mb-8">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="lg:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20"
              >
                <p className="text-sm text-slate-600">Welcome back</p>
                <h2 className="text-xl font-medium text-slate-900 mt-1">{profileName}</h2>
                <p className="text-sm text-slate-600 mt-1">{student?.classLevel || "Set your profile to personalize goals."}</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20"
              >
                <h3 className="text-base font-medium text-slate-900 mb-3">Profile</h3>
                <div className="text-xs text-slate-700 grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-slate-500">School</p>
                    <p className="text-slate-900">{student?.school || "-"}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Target Exam</p>
                    <p className="text-slate-900">{perf.profile?.targetExam || student?.targetExam || "-"}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Grade</p>
                    <p className="text-slate-900">{perf.profile?.grade || student?.classLevel || "-"}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Subjects</p>
                    <p className="text-slate-900 truncate">{(perf.profile?.subjects || []).join(", ") || "-"}</p>
                  </div>
                </div>
              </motion.div>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">{error}</div>
            )}

            {!loading && (
              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                {/* 1) User & Goal Setup */}
                <PerformanceCard title="User & Goal Setup" emoji="🎯">
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">Subjects (comma-separated)</label>
                      <input value={goalSubjects} onChange={(e)=>setGoalSubjects(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="Math, Physics, English" />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">Competitive Exams (comma-separated)</label>
                      <input value={goalExams} onChange={(e)=>setGoalExams(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="NEET, IIT-JEE, UPSC" />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">Notes</label>
                      <textarea value={goalNotes} onChange={(e)=>setGoalNotes(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="What are your goals?" />
                    </div>
                    <div className="flex justify-end">
                      <Button size="sm" onClick={() => saveSection("userGoal", { subjects: goalSubjects.split(",").map(s=>s.trim()).filter(Boolean), exams: goalExams.split(",").map(s=>s.trim()).filter(Boolean), notes: goalNotes })} loading={saving}>Save Goals</Button>
                    </div>
                  </div>
                </PerformanceCard>

                {/* 2) Profile creation */}
                <PerformanceCard title="Profile Creation" emoji="🧩">
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">Grade</label>
                      <input value={profileGrade} onChange={(e)=>setProfileGrade(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="10, 11, 12, UG, PG" />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">Subjects (comma-separated)</label>
                      <input value={profileSubjects} onChange={(e)=>setProfileSubjects(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="Math, Physics, Biology" />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">Target Exam</label>
                      <input value={profileTargetExam} onChange={(e)=>setProfileTargetExam(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="NEET, JEE, CAT" />
                    </div>
                    <div className="flex justify-end">
                      <Button size="sm" onClick={() => saveSection("profile", { grade: profileGrade, subjects: profileSubjects.split(",").map(s=>s.trim()).filter(Boolean), targetExam: profileTargetExam })} loading={saving}>Save Profile</Button>
                    </div>
                  </div>
                </PerformanceCard>

                {/* 3) Course Progress */}
                <PerformanceCard title="Course Progress" emoji="📚">
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">Level</label>
                      <select value={level} onChange={(e)=>setLevel(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm">
                        <option value="">Select</option>
                        <option value="1-8">1-8</option>
                        <option value="10-12">10-12</option>
                        <option value="UG">UG</option>
                        <option value="PG">PG</option>
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button onClick={()=>setSelectionType("subject")} className={`text-xs px-3 py-1.5 rounded ${selectionType==='subject'? 'bg-slate-900 text-white':'bg-slate-100 text-slate-700'}`}>Subject</button>
                      <button onClick={()=>setSelectionType("topic")} className={`text-xs px-3 py-1.5 rounded ${selectionType==='topic'? 'bg-slate-900 text-white':'bg-slate-100 text-slate-700'}`}>Topic</button>
                      <button onClick={()=>setSelectionType("exam")} className={`text-xs px-3 py-1.5 rounded ${selectionType==='exam'? 'bg-slate-900 text-white':'bg-slate-100 text-slate-700'}`}>Target Exam</button>
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">{selectionType === 'exam' ? 'Exam' : selectionType === 'topic' ? 'Topic' : 'Subject'}</label>
                      <input value={selectionValue} onChange={(e)=>setSelectionValue(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder={selectionType === 'exam' ? 'NEET, JEE, UPSC' : 'e.g., Algebra'} />
                    </div>
                    <div className="flex justify-end">
                      <Button size="sm" onClick={() => saveSection("courseProgress", { level, selectionType, selectionValue })} loading={saving}>Save Progress</Button>
                    </div>
                  </div>
                </PerformanceCard>

                {/* 4) AI Assist */}
                <PerformanceCard title="AI Assist" emoji="🤖">
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Grades</label>
                        <input value={aiGrades} onChange={(e)=>setAiGrades(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="A, B, etc." />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-600 mb-1">Marks</label>
                        <input value={aiMarks} onChange={(e)=>setAiMarks(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="e.g., 82" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs text-slate-600 mb-1">Notes</label>
                      <textarea value={aiNotes} onChange={(e)=>setAiNotes(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="Strong/weak areas, available hours..." />
                    </div>
                    <div className="flex items-center justify-between">
                      <Button size="sm" variant="secondary" onClick={runAiAssist} loading={aiLoading}>Generate Plan</Button>
                      {perf.aiAssist?.plan && (
                        <span className="text-xs text-green-700 bg-green-100 px-2 py-1 rounded">Plan ready</span>
                      )}
                    </div>
                    {perf.aiAssist?.plan && (
                      <div className="mt-3 space-y-2">
                        <p className="text-slate-900 text-sm">Suggested Daily Goals</p>
                        <ul className="list-disc pl-5 space-y-1">
                          {(perf.aiAssist.plan.dailyGoals || []).map((g)=> (<li key={g} className="text-slate-700">{g}</li>))}
                        </ul>
                        <p className="text-slate-900 text-sm mt-3">Weekly / Monthly Tests</p>
                        <p className="text-slate-700 text-sm">Weekly: {perf.aiAssist.plan.testSchedule?.weekly || '-'}</p>
                        <p className="text-slate-700 text-sm">Monthly: {perf.aiAssist.plan.testSchedule?.monthly || '-'}</p>
                      </div>
                    )}
                  </div>
                </PerformanceCard>

                {/* 5) Set timetable */}
                <PerformanceCard title="Set Timetable" emoji="🗓️">
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <input value={taskLabel} onChange={(e)=>setTaskLabel(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="Task (e.g., Algebra ch.2)" />
                      <input value={taskSubject} onChange={(e)=>setTaskSubject(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="Subject (optional)" />
                      <input value={taskTopic} onChange={(e)=>setTaskTopic(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="Topic (optional)" />
                      <input value={taskExam} onChange={(e)=>setTaskExam(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" placeholder="Exam (optional)" />
                    </div>
                    <div className="flex justify-end">
                      <Button size="sm" onClick={addTask} loading={saving}>Add</Button>
                    </div>
                    <div className="space-y-2">
                      {(perf.timetable?.items || []).length === 0 && (
                        <p className="text-xs text-slate-500">No tasks yet. Add your first study task.</p>
                      )}
                      {(perf.timetable?.items || []).map((it) => (
                        <label key={it.id} className="flex items-center gap-3 p-2 rounded hover:bg-slate-50 cursor-pointer">
                          <input type="checkbox" checked={it.done} onChange={() => toggleTask(it.id)} className="h-4 w-4" aria-label={`Toggle ${it.label}`} />
                          <span className={`text-sm ${it.done ? 'line-through text-slate-400' : 'text-slate-800'}`}>{it.label}</span>
                          <span className="ml-auto text-xs text-slate-500">{[it.subject, it.topic, it.exam].filter(Boolean).join(" • ")}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </PerformanceCard>

                {/* 6) Smart Reminders & Streak Tracker */}
                <PerformanceCard title="Smart Reminders & Streak" emoji="🔥">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <motion.span initial={{ scale: 0.9 }} animate={{ scale: 1 }} transition={{ repeat: Infinity, repeatType: 'mirror', duration: 1.2 }} aria-hidden="true">🔥</motion.span>
                        <p className="text-sm text-slate-800">Daily Streak</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-slate-900">{perf.reminders?.streakCount || 0} days</span>
                        <Icon icon="mdi:fire" className="text-orange-500" />
                      </div>
                    </div>
                    <div>
                      <Button size="sm" variant="primary" onClick={completeToday} loading={saving}>Mark Done Today</Button>
                      {perf.reminders?.lastCompletedDate && (
                        <p className="text-xs text-slate-500 mt-2">Last done: {perf.reminders.lastCompletedDate}</p>
                      )}
                    </div>
                  </div>
                </PerformanceCard>
              </div>
            )}

            {loading && (
              <p className="text-sm text-slate-500">Loading...</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
