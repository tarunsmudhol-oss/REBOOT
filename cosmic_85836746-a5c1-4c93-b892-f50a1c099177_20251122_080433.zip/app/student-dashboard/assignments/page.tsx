"use client";

import React, { useEffect, useMemo, useState } from "react";
import TopHeader from "@/app/components/TopHeader";
import LeftNav from "@/app/components/LeftNav";
import { Icon } from "@iconify/react";
import AssignmentCard, { AssignmentItem, AssignmentStatus } from "@/app/components/AssignmentCard";
import AssignmentsDashboardCalendar from "@/app/components/AssignmentsDashboardCalendar";

const STATUSES: AssignmentStatus[] = ["pending", "submitted", "graded", "overdue"];

export default function AssignmentsPage() {
  const [items, setItems] = useState<AssignmentItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>("");
  const [status, setStatus] = useState<string>("");
  const [subject, setSubject] = useState<string>("");
  const [view, setView] = useState<"list" | "calendar">("list");

  const load = async () => {
    setLoading(true);
    try {
      const u = new URL(window.location.origin + "/api/assignments");
      if (status) u.searchParams.set("status", status);
      if (subject) u.searchParams.set("subject", subject);
      const r = await fetch(u.toString(), { cache: "no-store" });
      const j = await r.json();
      if (r.ok && Array.isArray(j.items)) setItems(j.items);
    } catch {
      // noop
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 30000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, subject]);

  const filtered = useMemo(() => {
    const s = search.toLowerCase().trim();
    if (!s) return items;
    return items.filter((i) => i.title.toLowerCase().includes(s) || (i.subject || "").toLowerCase().includes(s));
  }, [items, search]);

  const counts = useMemo(() => {
    const map = new Map<string, number>();
    for (const st of STATUSES) map.set(st, 0);
    for (const it of items) map.set(it.status, (map.get(it.status) || 0) + 1);
    return map;
  }, [items]);

  const upcoming = useMemo(() => {
    const now = Date.now();
    const soon = now + 1000 * 60 * 60 * 48; // 48h
    return items.filter((i) => {
      const t = new Date(i.dueAt).getTime();
      return t > now && t <= soon && (i.status === "pending" || i.status === "overdue");
    });
  }, [items]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <TopHeader />
      <div className="flex">
        <LeftNav />
        <div className="flex-1">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
              <div>
                <h1 className="text-2xl font-medium text-slate-900">Assignments</h1>
                <p className="text-sm text-slate-600">Overview of active, upcoming, and past work.</p>
              </div>
              <div className="flex items-center gap-2">
                {STATUSES.map((st) => (
                  <span key={st} className="text-xs bg-white/80 border border-white/30 rounded px-2 py-1 text-slate-700">{st}: {counts.get(st) || 0}</span>
                ))}
              </div>
            </div>

            {upcoming.length > 0 && (
              <div className="mb-4 p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                <p className="text-xs text-yellow-900">Heads up: {upcoming.length} assignment(s) due within 48 hours.</p>
              </div>
            )}

            <div className="mb-4 grid sm:grid-cols-3 gap-3">
              <div className="sm:col-span-1">
                <div className="flex items-center gap-2 bg-white/80 border border-white/30 rounded-lg px-3 py-2">
                  <Icon icon="mdi:magnify" className="text-slate-500" />
                  <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search title or subject" className="w-full text-sm outline-none bg-transparent" />
                </div>
              </div>
              <select value={status} onChange={(e) => setStatus(e.target.value)} className="text-sm px-3 py-2 border border-slate-300 rounded-lg">
                <option value="">All statuses</option>
                {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
              <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Filter by subject" className="text-sm px-3 py-2 border border-slate-300 rounded-lg" />
            </div>

            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <button onClick={() => setView("list")} className={`px-3 py-1.5 text-xs rounded-lg ${view === "list" ? "bg-slate-900 text-white" : "bg-white text-slate-800 border"}`}>List</button>
                <button onClick={() => setView("calendar")} className={`px-3 py-1.5 text-xs rounded-lg ${view === "calendar" ? "bg-slate-900 text-white" : "bg-white text-slate-800 border"}`}>Calendar</button>
              </div>
            </div>

            {loading && <p className="text-sm text-slate-600">Loading...</p>}

            {!loading && view === "list" && (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filtered.map((it) => (<AssignmentCard key={it.id} item={it} />))}
                {filtered.length === 0 && <p className="text-sm text-slate-600">No assignments found.</p>}
              </div>
            )}

            {!loading && view === "calendar" && (
              <AssignmentsDashboardCalendar items={items} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
