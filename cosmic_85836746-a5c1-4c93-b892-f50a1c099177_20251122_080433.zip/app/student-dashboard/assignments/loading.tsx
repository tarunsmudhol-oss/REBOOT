export default function Loading() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="animate-pulse space-y-6">
          <div className="h-8 w-40 bg-slate-200 rounded" />
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-40 bg-slate-200/80 rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
