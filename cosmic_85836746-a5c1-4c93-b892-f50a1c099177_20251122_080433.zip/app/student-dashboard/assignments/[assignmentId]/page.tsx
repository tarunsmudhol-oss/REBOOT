"use client";

import React from "react";
import { useParams } from "next/navigation";
import TopHeader from "@/app/components/TopHeader";
import LeftNav from "@/app/components/LeftNav";
import AssignmentDetail from "@/app/components/AssignmentDetail";

export default function AssignmentDetailPage() {
  const params = useParams();
  const assignmentId = String(params?.assignmentId || "");

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <TopHeader />
      <div className="flex">
        <LeftNav />
        <div className="flex-1">
          <div className="max-w-5xl mx-auto px-6 py-8">
            <AssignmentDetail assignmentId={assignmentId} />
          </div>
        </div>
      </div>
    </div>
  );
}
