"use client";

import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react";
import { useAuth } from "cosmic-authentication";
import { Button } from "@/app/components/Button";
import { useRouter } from "next/navigation";
import LeftNav from "@/app/components/LeftNav";
import TopHeader from "@/app/components/TopHeader";
import Pie3D from "@/app/components/Pie3D";
import LearningHub from "@/app/components/LearningHub";
import Backlogs from "@/app/components/Backlogs";

interface StudentInfo {
  studentName: string;
  dob: string; // ISO
  classLevel: string;
  school: string;
  targetExam: string;
  gender: string;
  previousYearMarks: number;
}

interface PerfProfile { grade?: string; subjects?: string[]; targetExam?: string }

function calculateAge(dobIso: string): number {
  const today = new Date();
  const birth = new Date(dobIso);
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age -= 1;
  return age;
}

export default function StudentDashboard() {
  const { signOut } = useAuth();
  const router = useRouter();

  const [activeTab, setActiveTab] = useState<"timetable" | "courses">("timetable");

  const [info, setInfo] = useState<StudentInfo | null>(null);
  const [exists, setExists] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string>("");

  const [perfProfile, setPerfProfile] = useState<PerfProfile | null>(null);
  const [backlogCount, setBacklogCount] = useState<number>(0);

  const [form, setForm] = useState<StudentInfo>({
    studentName: "",
    dob: "",
    classLevel: "",
    school: "",
    targetExam: "",
    gender: "",
    previousYearMarks: 0
  });

  useEffect(() => {
    let mounted = true;
    const fetchInfo = async () => {
      try {
        const res = await fetch("/api/student-info", { cache: "no-store" });
        const data = await res.json();
        if (!mounted) return;
        if (res.ok && data.exists) {
          const loaded: StudentInfo = {
            studentName: data.studentName,
            dob: data.dob,
            classLevel: data.classLevel,
            school: data.school,
            targetExam: data.targetExam,
            gender: data.gender,
            previousYearMarks: Number(data.previousYearMarks || 0)
          };
          setExists(true);
          setInfo(loaded);
          setForm(loaded);
          // Enforce age rule at login
          if (calculateAge(loaded.dob) < 15) {
            alert("Access denied: Students must be at least 15 years old.");
            await signOut();
            router.push("/");
            return;
          }
        }
      } catch {
        // ignore; show empty form
      } finally {
        if (mounted) setLoading(false);
      }
    };
    fetchInfo();
    return () => {
      mounted = false;
    };
  }, [router, signOut]);

  // Fetch performance profile to reflect saved Performance data in the top-right card
  useEffect(() => {
    let active = true;
    const loadPerf = async () => {
      try {
        const r = await fetch("/api/performance", { cache: "no-store" });
        const j = await r.json();
        if (!active) return;
        if (r.ok && (j?.profile || j?.exists)) {
          setPerfProfile(j.profile || null);
        }
      } catch {
        // noop
      }
    };
    loadPerf();
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let mounted = true;
    const fetchBacklogs = async () => {
      try {
        const r = await fetch("/api/backlogs", { cache: "no-store" });
        const j = await r.json();
        if (!mounted) return;
        if (r.ok && Array.isArray(j.items)) setBacklogCount(j.items.length);
      } catch {
        // ignore
      }
    };
    if (exists) fetchBacklogs();
    return () => {
      mounted = false;
    };
  }, [exists]);

  const profileName = useMemo(() => {
    if (form.studentName) return form.studentName;
    if (info?.studentName) return info.studentName;
    return "John Doe";
  }, [form.studentName, info?.studentName]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!form.studentName || !form.dob || !form.classLevel || !form.school || !form.targetExam || !form.gender) {
      setError("Please fill in all fields.");
      return;
    }

    const marks = Number(form.previousYearMarks);
    if (Number.isNaN(marks) || marks < 0) {
      setError("Marks must be a valid non-negative number.");
      return;
    }

    if (calculateAge(form.dob) < 15) {
      setError("Students must be at least 15 years old.");
      return;
    }

    setSaving(true);
    try {
      const res = await fetch("/api/student-info", {
        method: exists ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, previousYearMarks: marks })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to save information");
      }
      setExists(true);
      setInfo(form);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSaving(false);
    }
  };

  const today = new Date();
  const dateStr = today.toLocaleDateString(undefined, {
    weekday: "long",
    year: "numeric",
    month: "short",
    day: "numeric"
  });

  const stats = [
    { label: "Active Courses", value: "6", icon: "mdi:book-open-variant", color: "text-blue-600" },
    { label: "Assignments Due", value: "3", icon: "mdi:clipboard-text", color: "text-orange-600" },
    { label: "Average Grade", value: "87%", icon: "mdi:chart-line", color: "text-green-600" },
    { label: "Study Hours", value: "42h", icon: "mdi:clock-outline", color: "text-teal-600" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <TopHeader />
      <div className="flex">
        <LeftNav />
        <div className="flex-1">
          <div className="max-w-7xl mx-auto px-6 py-8">
            {/* Welcome Banner */}
            <div className="mb-6 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">{dateStr}</p>
                  <h1 className="text-2xl font-medium text-slate-900 mt-1">Welcome{profileName ? `, ${profileName}` : ""}</h1>
                  <p className="text-sm text-slate-600 mt-1">{form.classLevel || info?.classLevel ? `Class: ${form.classLevel || info?.classLevel}` : "Complete your student information to unlock your dashboard."}</p>
                </div>
                <div className="hidden md:flex items-center gap-3">
                  <button className="px-3 py-1.5 text-sm rounded-lg bg-slate-900 text-white">Announcements</button>
                  <button className="px-3 py-1.5 text-sm rounded-lg bg-slate-100 text-slate-700">Calendar</button>
                </div>
              </div>
            </div>

            {/* Student Info Section */}
            <div id="student-info" className="grid lg:grid-cols-3 gap-6 mb-8">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="lg:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20"
              >
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-medium text-slate-900">Student Information</h2>
                  {exists && <span className="text-xs px-2 py-1 rounded bg-green-100 text-green-700">Saved</span>}
                </div>

                {error && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                    {error}
                  </div>
                )}

                {!loading && (
                  <form onSubmit={onSubmit} className="grid sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-sm text-slate-700 mb-1">Student Name</label>
                      <input
                        type="text"
                        value={form.studentName}
                        onChange={(e) => setForm({ ...form, studentName: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Enter full name"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-slate-700 mb-1">Date of Birth</label>
                      <input
                        type="date"
                        value={form.dob}
                        max={new Date().toISOString().split("T")[0]}
                        onChange={(e) => setForm({ ...form, dob: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-slate-700 mb-1">Class</label>
                      <input
                        type="text"
                        value={form.classLevel}
                        onChange={(e) => setForm({ ...form, classLevel: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="e.g., 10th Grade / 2nd Year"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-slate-700 mb-1">School or College</label>
                      <input
                        type="text"
                        value={form.school}
                        onChange={(e) => setForm({ ...form, school: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Institution name"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-slate-700 mb-1">Target Exam</label>
                      <input
                        type="text"
                        value={form.targetExam}
                        onChange={(e) => setForm({ ...form, targetExam: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="e.g., SAT, JEE, NEET"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-slate-700 mb-1">Gender</label>
                      <select
                        value={form.gender}
                        onChange={(e) => setForm({ ...form, gender: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      >
                        <option value="">Select</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                        <option value="Prefer not to say">Prefer not to say</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm text-slate-700 mb-1">Marks of Previous Year</label>
                      <input
                        type="number"
                        min={0}
                        step={1}
                        value={form.previousYearMarks}
                        onChange={(e) => setForm({ ...form, previousYearMarks: Number(e.target.value) })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="e.g., 85"
                        required
                      />
                    </div>

                    <div className="sm:col-span-2 flex items-center justify-end gap-3 mt-2">
                      <Button type="submit" size="sm" loading={saving}>
                        Save Information
                      </Button>
                    </div>
                  </form>
                )}

                {loading && (
                  <p className="text-sm text-slate-500">Loading...</p>
                )}
              </motion.div>

              {/* Top-right Student Profile Card */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20"
              >
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-medium text-slate-900">Profile</h2>
                </div>
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm">
                    <span>{profileName.split(" ").map((n) => n[0]).join("")}</span>
                  </div>
                  <div>
                    <p className="text-slate-900 text-sm">{profileName}</p>
                    <p className="text-slate-500 text-xs">{form.classLevel || info?.classLevel || "Class"}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs text-slate-600">
                  <div>
                    <p className="text-slate-500">DOB</p>
                    <p className="text-slate-900">{(form.dob || info?.dob || "").toString() || "-"}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Gender</p>
                    <p className="text-slate-900">{form.gender || info?.gender || "-"}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">School</p>
                    <p className="text-slate-900">{form.school || info?.school || "-"}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Target Exam</p>
                    <p className="text-slate-900">{perfProfile?.targetExam || form.targetExam || info?.targetExam || "-"}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Prev. Marks</p>
                    <p className="text-slate-900">{String(form.previousYearMarks || info?.previousYearMarks || "-")}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Subjects</p>
                    <p className="text-slate-900">{(perfProfile?.subjects || []).join(", ") || "-"}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-slate-500">Backlogs</p>
                    <p className="text-slate-900">{backlogCount}</p>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Information Cards / Widgets */}
            {exists && (
              <div className="grid lg:grid-cols-4 gap-6 mb-8">
                {/* Name */}
                <div className="bg-white/80 backdrop-blur-sm rounded-xl p-5 border border-white/20">
                  <p className="text-xs text-slate-500 mb-1">Name</p>
                  <p className="text-slate-900">{profileName}</p>
                </div>
                {/* Class & Section */}
                <div className="bg-white/80 backdrop-blur-sm rounded-xl p-5 border border-white/20">
                  <p className="text-xs text-slate-500 mb-1">Class & Section</p>
                  <p className="text-slate-900">{form.classLevel || info?.classLevel || "-"}</p>
                </div>
                {/* Support Request */}
                <div className="bg-white/80 backdrop-blur-sm rounded-xl p-5 border border-white/20">
                  <p className="text-xs text-slate-500 mb-3">Support Request</p>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <input placeholder="Support ID" className="px-2 py-1.5 border border-slate-200 rounded" />
                    <input placeholder="Category" className="px-2 py-1.5 border border-slate-200 rounded" />
                    <input placeholder="Request Type" className="px-2 py-1.5 border border-slate-200 rounded" />
                  </div>
                  <button className="mt-3 text-xs px-3 py-1.5 rounded bg-slate-900 text-white">Submit</button>
                </div>
                {/* Time Table Summary */}
                <div className="bg-white/80 backdrop-blur-sm rounded-xl p-5 border border-white/20">
                  <p className="text-xs text-slate-500 mb-2">Time Table Summary</p>
                  <p className="text-sm text-slate-700">IA: 12 Mar</p>
                  <p className="text-sm text-slate-700">Exams: 25 Mar - 05 Apr</p>
                </div>
              </div>
            )}

            {/* Quick Stats */}
            {exists && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {stats.map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-600 mb-1">{stat.label}</p>
                        <p className="text-2xl font-medium text-slate-900">{stat.value}</p>
                      </div>
                      <Icon icon={stat.icon} className={`text-2xl ${stat.color}`} />
                    </div>
                  </motion.div>
                ))}
              </div>
            )}

            {/* Main Content Area with Tabs + 3D Pie */}
            {exists && (
              <div className="grid xl:grid-cols-3 gap-8">
                <div className="xl:col-span-2 space-y-8">
                  <div className="bg-white/80 backdrop-blur-sm rounded-xl border border-white/20">
                    <div className="flex items-center gap-3 p-4 border-b border-slate-200/60">
                      <button onClick={() => setActiveTab("timetable")} className={`text-sm px-3 py-1.5 rounded ${activeTab === "timetable" ? "bg-slate-900 text-white" : "text-slate-700 hover:bg-slate-100"}`}>Time Table</button>
                      <button onClick={() => setActiveTab("courses")} className={`text-sm px-3 py-1.5 rounded ${activeTab === "courses" ? "bg-slate-900 text-white" : "text-slate-700 hover:bg-slate-100"}`}>Course Details</button>
                    </div>
                    <div className="p-6">
                      {activeTab === "timetable" ? (
                        <div className="grid md:grid-cols-2 gap-4 text-sm">
                          {["Mon", "Tue", "Wed", "Thu", "Fri"].map((day) => (
                            <div key={day} className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                              <p className="font-medium text-slate-900 mb-1">{day}</p>
                              <p className="text-slate-600">08:00 - Math • 10:00 - English • 12:00 - Science</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="space-y-4 text-sm">
                          {[{name:"Mathematics", teacher:"Dr. Allen", credits:4}, {name:"English", teacher:"Ms. Rose", credits:3}, {name:"Physics", teacher:"Mr. Clark", credits:4}].map((c) => (
                            <div key={c.name} className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between">
                              <div>
                                <p className="font-medium text-slate-900">{c.name}</p>
                                <p className="text-slate-600">{c.teacher} • {c.credits} credits</p>
                              </div>
                              <button className="text-xs px-3 py-1.5 rounded bg-slate-900 text-white">Details</button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Upcoming Exams + Study Schedule */}
                  <div className="grid md:grid-cols-2 gap-8">
                    <motion.div initial={{opacity:0, x:-20}} animate={{opacity:1,x:0}} transition={{duration:0.6}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-lg font-medium text-slate-900">Upcoming Exams</h2>
                      </div>
                      <div className="space-y-3 text-sm">
                        {[{sub:"Math", date:"Mar 25"},{sub:"English", date:"Mar 28"},{sub:"Physics", date:"Apr 02"}].map((ex) => (
                          <div key={ex.sub} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                            <p className="text-slate-900">{ex.sub}</p>
                            <span className="text-slate-600">{ex.date}</span>
                          </div>
                        ))}
                      </div>
                    </motion.div>

                    <motion.div initial={{opacity:0, x:20}} animate={{opacity:1,x:0}} transition={{duration:0.6}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-lg font-medium text-slate-900">Study Schedule</h2>
                      </div>
                      <div className="space-y-3 text-sm">
                        {[{slot:"Mon 6-8pm", task:"Math Practice"},{slot:"Wed 7-8pm", task:"Essay Draft"},{slot:"Fri 5-7pm", task:"Physics Lab Prep"}].map((s) => (
                          <div key={s.slot} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                            <p className="text-slate-900">{s.task}</p>
                            <span className="text-slate-600">{s.slot}</span>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  </div>
                </div>

                {/* 3D Pie Chart */}
                <div className="space-y-4">
                  <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                    <h2 className="text-lg font-medium text-slate-900 mb-4">Attendance</h2>
                    <Pie3D slices={[
                      { label: "Present", value: 92, color: "#16a34a" },
                      { label: "Absent", value: 8, color: "#ef4444" }
                    ]} />
                    <div className="mt-3 text-sm text-slate-600">
                      <p><span className="inline-block w-3 h-3 rounded-full mr-2" style={{background:'#16a34a'}}></span>Present: 92%</p>
                      <p><span className="inline-block w-3 h-3 rounded-full mr-2" style={{background:'#ef4444'}}></span>Absent: 8%</p>
                    </div>
                  </div>
                  <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                    <h2 className="text-lg font-medium text-slate-900 mb-4">Course Progress</h2>
                    <Pie3D slices={[
                      { label: "Completed", value: 68, color: "#2563eb" },
                      { label: "In Progress", value: 22, color: "#06b6d4" },
                      { label: "Pending", value: 10, color: "#d1d5db" }
                    ]} />
                    <div className="mt-3 text-sm text-slate-600">
                      <p><span className="inline-block w-3 h-3 rounded-full mr-2" style={{background:'#2563eb'}}></span>Completed: 68%</p>
                      <p><span className="inline-block w-3 h-3 rounded-full mr-2" style={{background:'#06b6d4'}}></span>In Progress: 22%</p>
                      <p><span className="inline-block w-3 h-3 rounded-full mr-2" style={{background:'#d1d5db'}}></span>Pending: 10%</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Actions */}
            {exists && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="mt-8 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 max-w-7xl mx-auto"
              >
                <h2 className="text-lg font-medium text-slate-900 mb-6">Quick Actions</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { icon: "mdi:book-plus", label: "View Courses", color: "bg-blue-500" },
                    { icon: "mdi:clipboard-plus", label: "Submit Assignment", color: "bg-green-500" },
                    { icon: "mdi:calendar", label: "View Calendar", color: "bg-teal-500" },
                    { icon: "mdi:message-text", label: "Messages", color: "bg-orange-500" }
                  ].map((action) => (
                    <button
                      key={action.label}
                      className="flex flex-col items-center p-4 rounded-lg hover:bg-slate-50/50 transition-colors"
                    >
                      <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-2`}>
                        <Icon icon={action.icon} className="text-white text-xl" />
                      </div>
                      <span className="text-sm font-medium text-slate-700">{action.label}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {exists && (
              <LearningHub />
            )}

            {exists && (
              <Backlogs />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}