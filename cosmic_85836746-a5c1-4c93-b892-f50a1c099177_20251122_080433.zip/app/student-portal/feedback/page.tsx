"use client";

import React from "react";
import TopHeader from "@/app/components/TopHeader";
import LeftNav from "@/app/components/LeftNav";
import { motion } from "framer-motion";
import FeedbackForm from "@/app/components/FeedbackForm";

export default function StudentFeedbackPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <TopHeader />
      <div className="flex">
        <LeftNav />
        <main className="flex-1">
          <div className="max-w-5xl mx-auto px-6 py-8">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="mb-6">
              <p className="text-xs uppercase tracking-wide text-slate-500">Student Portal</p>
              <h1 className="text-2xl md:text-3xl text-slate-900 mt-1">Feedback</h1>
            </motion.div>

            <FeedbackForm />
          </div>
        </main>
      </div>
    </div>
  );
}
