"use client";

import React, { useMemo, useState } from "react";
import TopHeader from "@/app/components/TopHeader";
import LeftNav from "@/app/components/LeftNav";
import Footer from "@/app/components/Footer";
import { Icon } from "@iconify/react";
import { motion } from "framer-motion";

// Simple helpers
type Message = { from: "me" | "mentor" | "group"; text: string; time: string };
type Resource = { id: string; type: "pdf" | "youtube" | "link"; title: string; url: string };
type Task = { id: string; title: string; done: boolean };
type Note = { id: string; text: string; time: string };
type Mentor = {
  id: string;
  name: string;
  specialization: string;
  experienceYears: number;
  rating: number; // 1-5
  badges: string[];
  subjects: string[];
};

type Slot = { day: string; time: string; available: boolean; booked?: boolean };

const heroImg = "https://storage.googleapis.com/cosmic-generated-assets/backgrounds/4k/cosmic-bg-1ryhy717un.jpg";

export default function MentoringPage() {
  // Mock mentors
  const mentors: Mentor[] = useMemo(
    () => [
      { id: "m1", name: "Aisha Kumar", specialization: "Mathematics", experienceYears: 7, rating: 4.8, badges: ["Top Mentor", "Fast Responder"], subjects: ["Algebra", "Calculus", "Statistics"] },
      { id: "m2", name: "Liam Chen", specialization: "Physics", experienceYears: 5, rating: 4.6, badges: ["Problem Solver"], subjects: ["Mechanics", "Optics", "Thermodynamics"] },
      { id: "m3", name: "Sofia Garcia", specialization: "Computer Science", experienceYears: 6, rating: 4.9, badges: ["Project Guru", "Top Mentor"], subjects: ["DSA", "Web Dev", "Databases"] },
      { id: "m4", name: "Ethan Brown", specialization: "Chemistry", experienceYears: 8, rating: 4.7, badges: ["Research Pro"], subjects: ["Organic", "Inorganic", "Physical Chem"] }
    ],
    []
  );

  const [selectedMentorId, setSelectedMentorId] = useState<string>("m3");
  const selectedMentor = useMemo(() => mentors.find(m => m.id === selectedMentorId) as Mentor, [mentors, selectedMentorId]);

  // Goals
  const [shortGoals, setShortGoals] = useState<string[]>(["Finish Algebra Ch. 3", "Revise sorting algorithms"]);
  const [longGoals, setLongGoals] = useState<string[]>(["Ace midterms (A- or better)", "Build portfolio website"]);
  const [newGoal, setNewGoal] = useState<string>("");
  const [goalType, setGoalType] = useState<"short" | "long">("short");

  // Progress + gamification
  const [progress, setProgress] = useState<number>(68);
  const [xp, setXp] = useState<number>(420);
  const level = Math.floor(xp / 100) + 1;
  const nextLevelProgress = xp % 100;

  // Chat
  const [chatMessages, setChatMessages] = useState<Message[]>([
    { from: "mentor", text: "Hi! What would you like to cover today?", time: "09:00" }
  ]);
  const [chatInput, setChatInput] = useState<string>("");

  // Group rooms
  const [activeRoom, setActiveRoom] = useState<string>("DSA Study Group");
  const [groupMessages, setGroupMessages] = useState<Record<string, Message[]>>({
    "DSA Study Group": [ { from: "group", text: "Share your best sorting tips!", time: "08:30" } ],
    "Physics Mechanics": [],
    "Algebra Boosters": []
  });

  // Booking + availability
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];
  const times = ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00"];
  const [slots, setSlots] = useState<Slot[]>(() => {
    const arr: Slot[] = [];
    days.forEach(d => times.forEach(t => arr.push({ day: d, time: t, available: Math.random() > 0.3 })));
    return arr;
  });

  // Feedback
  const [rating, setRating] = useState<number>(0);
  const [feedbackText, setFeedbackText] = useState<string>("");

  // Notes
  const [notes, setNotes] = useState<Note[]>([]);
  const [noteText, setNoteText] = useState<string>("");

  // Resources
  const [resources, setResources] = useState<Resource[]>([
    { id: "r1", type: "youtube", title: "Sorting Algorithms Visualized", url: "https://www.youtube.com/watch?v=ZZuD6iUe3Pc" },
    { id: "r2", type: "link", title: "Algebra practice sheet", url: "https://www.khanacademy.org/math" }
  ]);
  const [resourceTitle, setResourceTitle] = useState<string>("");
  const [resourceUrl, setResourceUrl] = useState<string>("");
  const [resourceType, setResourceType] = useState<"pdf" | "youtube" | "link">("link");

  // Reports
  const downloadReport = (period: "weekly" | "monthly") => {
    const content = `Smart Student Portal - ${period} report\nMentor: ${selectedMentor.name}\nProgress: ${progress}%\nGoals: ${[...shortGoals, ...longGoals].join(", ")}`;
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `progress-report-${period}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Suggestions (very simple subject-match + rating)
  const subjects = ["Algebra", "Calculus", "DSA", "Web Dev", "Physics", "Chemistry"];
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(["DSA", "Algebra"]);
  const suggestedMentors = useMemo(() => {
    return mentors
      .map(m => ({
        mentor: m,
        score: m.rating + m.subjects.reduce((acc, s) => acc + (selectedSubjects.includes(s) ? 1 : 0), 0)
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 3)
      .map(x => x.mentor);
  }, [mentors, selectedSubjects]);

  // Forum & doubts
  const [topics, setTopics] = useState<{ id: string; title: string; replies: string[] }[]>([
    { id: "t1", title: "Best way to memorize formulas?", replies: ["Use spaced repetition."] }
  ]);
  const [newTopic, setNewTopic] = useState<string>("");
  const [doubts, setDoubts] = useState<{ id: string; text: string; resolved: boolean }[]>([]);
  const [doubtText, setDoubtText] = useState<string>("");

  // Badges
  const [mentorBadges] = useState<string[]>(selectedMentor.badges);

  // Tasks
  const [tasks, setTasks] = useState<Task[]>([
    { id: "t1", title: "Rewatch DSA session", done: false },
    { id: "t2", title: "Solve 10 Algebra problems", done: true }
  ]);
  const [taskText, setTaskText] = useState<string>("");

  // Notifications
  const [notifyEmail, setNotifyEmail] = useState<boolean>(true);
  const [notifyPortal, setNotifyPortal] = useState<boolean>(true);
  const [notifySMS, setNotifySMS] = useState<boolean>(false);

  // Recordings
  const recordings = [
    { id: "v1", title: "DSA Mentoring 10/01", url: "https://www.youtube.com/embed/8hly31xKli0" },
    { id: "v2", title: "Algebra Check-in 10/05", url: "https://www.youtube.com/embed/QVKj3LADCnA" }
  ];
  const [openVideo, setOpenVideo] = useState<string | null>(null);

  // Profile & privacy
  const [bio, setBio] = useState<string>("Second-year CS student who loves clean UI and efficient code.");
  const [interests, setInterests] = useState<string>("DSA, Web development, UI/UX");
  const [privacy, setPrivacy] = useState<{ showProgress: boolean; showGoals: boolean; showProfile: boolean }>({ showProgress: true, showGoals: true, showProfile: true });

  // Mentor recommendation (learning paths)
  const [recommendations, setRecommendations] = useState<string[]>(["Start with arrays & strings", "Daily 30-min math review"]);

  // Quote of the day
  const quotes = [
    "Small steps daily lead to big results.",
    "Progress over perfection.",
    "Learn, grow, and keep going.",
    "Consistency is the secret sauce."
  ];
  const quote = quotes[new Date().getDay() % quotes.length];

  // Handlers
  const addGoal = () => {
    if (!newGoal.trim()) return;
    if (goalType === "short") setShortGoals(prev => [...prev, newGoal.trim()]);
    else setLongGoals(prev => [...prev, newGoal.trim()]);
    setNewGoal("");
  };

  const toggleTask = (id: string) => setTasks(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t));

  const sendChat = () => {
    if (!chatInput.trim()) return;
    const now = new Date();
    const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    setChatMessages(prev => [...prev, { from: "me", text: chatInput.trim(), time }]);
    setChatInput("");
  };

  const sendGroupMessage = (text: string) => {
    if (!text.trim()) return;
    const now = new Date();
    const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    setGroupMessages(prev => ({
      ...prev,
      [activeRoom]: [...(prev[activeRoom] || []), { from: "me", text: text.trim(), time }]
    }));
  };

  const bookSlot = (d: string, t: string) => {
    setSlots(prev => prev.map(s => s.day === d && s.time === t ? { ...s, booked: true, available: false } : s));
  };

  const addResource = () => {
    if (!resourceTitle.trim() || !resourceUrl.trim()) return;
    setResources(prev => [{ id: Math.random().toString(36).slice(2), type: resourceType, title: resourceTitle.trim(), url: resourceUrl.trim() }, ...prev]);
    setResourceTitle("");
    setResourceUrl("");
  };

  const addNote = () => {
    if (!noteText.trim()) return;
    const time = new Date().toLocaleString();
    setNotes(prev => [{ id: Math.random().toString(36).slice(2), text: noteText.trim(), time }, ...prev]);
    setNoteText("");
  };

  const submitFeedback = () => {
    if (rating === 0) return;
    setFeedbackText("");
    // Simulate success toast
    alert("Thanks! Your feedback was submitted.");
  };

  const addTopic = () => {
    if (!newTopic.trim()) return;
    setTopics(prev => [{ id: Math.random().toString(36).slice(2), title: newTopic.trim(), replies: [] }, ...prev]);
    setNewTopic("");
  };

  const addDoubt = () => {
    if (!doubtText.trim()) return;
    setDoubts(prev => [{ id: Math.random().toString(36).slice(2), text: doubtText.trim(), resolved: false }, ...prev]);
    setDoubtText("");
  };

  const requestMentor = () => alert("Mentor request sent! We will notify you soon.");
  const savePrivacy = () => alert("Privacy settings saved.");

  // Simple performance comparison data
  const months = ["Aug", "Sep", "Oct", "Nov"];
  const performance = [62, 66, 71, progress];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <TopHeader />
      <div className="flex">
        <LeftNav />
        <main className="flex-1">
          <div className="max-w-7xl mx-auto px-6 py-8">
            {/* Hero */}
            <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} className="mb-8">
              <p className="text-xs uppercase tracking-wide text-slate-500">Student Portal</p>
              <h1 className="text-2xl md:text-3xl text-slate-900 mt-1">Welcome to Your Mentoring Journey – Let&apos;s Learn, Grow, and Succeed Together.</h1>
              <div className="mt-4 grid md:grid-cols-3 gap-4 items-center">
                <div className="md:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-5 border border-white/20">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                    <span className="px-2 py-1 rounded-full bg-blue-50 text-blue-700">Quick chats</span>
                    <span className="px-2 py-1 rounded-full bg-teal-50 text-teal-700">Book sessions</span>
                    <span className="px-2 py-1 rounded-full bg-amber-50 text-amber-700">Track progress</span>
                    <span className="px-2 py-1 rounded-full bg-slate-100 text-slate-700">Share resources</span>
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <a href="#overview" className="px-3 py-2 text-sm rounded-lg bg-blue-600 text-white hover:bg-blue-700">Go to Overview</a>
                    <a href="#chat" className="px-3 py-2 text-sm rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50">Open Chat</a>
                    <a href="#calendar" className="px-3 py-2 text-sm rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50">Book Session</a>
                  </div>
                </div>
                <div className="md:col-span-1">
                  <img src={heroImg} alt="Mentoring hero" className="w-full rounded-xl border border-white/20 shadow-sm" />
                </div>
              </div>
            </motion.section>

            {/* Quick in-page nav */}
            <div className="sticky top-16 z-30 bg-white/80 backdrop-blur-sm border border-slate-200/60 rounded-xl px-3 py-2 mb-6 overflow-x-auto">
              <div className="flex gap-2 text-xs">
                {[
                  { href: "#overview", label: "Overview" },
                  { href: "#chat", label: "1:1 Chat" },
                  { href: "#groups", label: "Groups" },
                  { href: "#calendar", label: "Calendar" },
                  { href: "#resources", label: "Resources" },
                  { href: "#forum", label: "Forum" },
                  { href: "#recordings", label: "Recordings" },
                  { href: "#reports", label: "Reports" },
                  { href: "#profile", label: "Profile" },
                  { href: "#settings", label: "Settings" },
                ].map(x => (
                  <a key={x.href} href={x.href} className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 whitespace-nowrap">{x.label}</a>
                ))}
              </div>
            </div>

            {/* Overview: Mentor + Student dashboards, progress, goals, notifications */}
            <section id="overview" className="grid xl:grid-cols-3 gap-6">
              {/* Mentor Dashboard */}
              <div className="xl:col-span-1 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="flex items-start justify-between">
                  <p className="text-slate-900 text-sm">Mentor Dashboard</p>
                  <span className="text-[10px] px-2 py-1 bg-teal-50 text-teal-700 rounded-full flex items-center gap-1"><Icon icon="material-symbols:badge" />Verified</span>
                </div>
                <div className="mt-4 flex items-center gap-3">
                  <img src={`https://i.pravatar.cc/80?u=${selectedMentor.id}`} alt="Mentor avatar" className="w-14 h-14 rounded-full border border-slate-200" />
                  <div>
                    <p className="text-slate-900 text-sm">{selectedMentor.name}</p>
                    <p className="text-slate-500 text-xs">{selectedMentor.specialization} • {selectedMentor.experienceYears} yrs exp</p>
                    <div className="flex items-center gap-1 mt-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Icon key={i} icon={i < Math.round(selectedMentor.rating) ? "material-symbols:star" : "material-symbols:star-outline"} className="text-amber-500" />
                      ))}
                      <span className="text-xs text-slate-500">{selectedMentor.rating.toFixed(1)}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {mentorBadges.map(b => (
                    <span key={b} className="px-2 py-1 rounded-full bg-blue-50 text-blue-700 text-[10px]">{b}</span>
                  ))}
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <label className="text-xs text-slate-600">Switch mentor:</label>
                  <select value={selectedMentorId} onChange={(e) => setSelectedMentorId(e.target.value)} className="text-sm border border-slate-300 rounded-lg px-2 py-1">
                    {mentors.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                  </select>
                  <button onClick={requestMentor} className="text-xs px-2 py-1 rounded-lg border border-slate-300 hover:bg-slate-50">Request Mentor</button>
                </div>
                <div className="mt-4 text-xs text-slate-600 flex items-center gap-2">
                  <Icon icon="mdi:clock-outline" />
                  <span>Next available: {slots.find(s => s.available)?.day ?? "—"} {slots.find(s => s.available)?.time ?? ""}</span>
                </div>
              </div>

              {/* Student Dashboard */}
              <div className="xl:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="flex items-start justify-between">
                  <p className="text-slate-900 text-sm">Student Dashboard</p>
                  <span className="text-[10px] text-slate-500">Quote: {quote}</span>
                </div>
                <div className="grid md:grid-cols-3 gap-4 mt-4">
                  {/* Progress tracker */}
                  <div className="col-span-1 bg-slate-50 rounded-lg p-4">
                    <p className="text-xs text-slate-600">Overall Progress</p>
                    <div className="relative w-28 h-28 mx-auto my-2">
                      <svg viewBox="0 0 36 36" className="w-full h-full">
                        <path d="M18 2.0845a 15.9155 15.9155 0 0 1 0 31.831" fill="none" stroke="#e5e7eb" strokeWidth="3" />
                        <path d="M18 2.0845a 15.9155 15.9155 0 0 1 0 31.831" fill="none" stroke="#0ea5e9" strokeWidth="3" strokeDasharray={`${progress}, 100`} />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center"><span className="text-slate-900 text-sm">{progress}%</span></div>
                    </div>
                    <div className="mt-2">
                      <p className="text-xs text-slate-600">Level {level}</p>
                      <div className="w-full h-2 bg-white rounded-full mt-1">
                        <div className="h-2 bg-blue-600 rounded-full" style={{ width: `${nextLevelProgress}%` }} />
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">XP: {xp}/100 to next level</p>
                      <div className="mt-2 flex gap-2">
                        <button onClick={() => setXp(xp + 5)} className="text-[11px] px-2 py-1 rounded bg-blue-600 text-white">Add 5 XP</button>
                        <button onClick={() => setProgress(Math.min(100, progress + 2))} className="text-[11px] px-2 py-1 rounded border border-slate-300">Update Progress</button>
                      </div>
                    </div>
                  </div>
                  {/* Goals */}
                  <div className="col-span-2 bg-slate-50 rounded-lg p-4">
                    <p className="text-xs text-slate-600">Goals</p>
                    <div className="mt-2 flex items-center gap-2">
                      <input value={newGoal} onChange={(e) => setNewGoal(e.target.value)} placeholder="Add a goal" className="text-sm px-3 py-2 rounded-lg border border-slate-300 flex-1" />
                      <select value={goalType} onChange={(e) => setGoalType(e.target.value as ("short"|"long"))} className="text-sm px-2 py-2 rounded-lg border border-slate-300">
                        <option value="short">Short-term</option>
                        <option value="long">Long-term</option>
                      </select>
                      <button onClick={addGoal} className="px-3 py-2 text-sm rounded-lg bg-blue-600 text-white">Add</button>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-3 mt-3">
                      <div>
                        <p className="text-[11px] text-slate-500">Short-term</p>
                        <ul className="mt-1 space-y-1 text-sm text-slate-700">
                          {shortGoals.map((g, idx) => <li key={idx} className="flex items-center gap-2"><Icon icon="mdi:check-circle-outline" className="text-teal-600" /><span>{g}</span></li>)}
                        </ul>
                      </div>
                      <div>
                        <p className="text-[11px] text-slate-500">Long-term</p>
                        <ul className="mt-1 space-y-1 text-sm text-slate-700">
                          {longGoals.map((g, idx) => <li key={idx} className="flex items-center gap-2"><Icon icon="mdi:target-variant" className="text-blue-600" /><span>{g}</span></li>)}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                {/* Performance comparison chart */}
                <div className="mt-4 bg-slate-50 rounded-lg p-4">
                  <p className="text-xs text-slate-600">Performance Comparison</p>
                  <div className="mt-2 flex items-end gap-2 h-24">
                    {performance.map((val, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center">
                        <div className="w-full bg-blue-600/70 rounded-t" style={{ height: `${val}%` }} />
                        <span className="text-[11px] text-slate-500 mt-1">{months[i]}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            {/* 1:1 Chat + Notes + Feedback */}
            <section id="chat" className="mt-8 grid xl:grid-cols-3 gap-6">
              {/* Chat */}
              <div className="xl:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="material-symbols:chat" /> One-on-One Chat</p>
                  <span className="text-[10px] text-slate-500">Mentor: {selectedMentor.name}</span>
                </div>
                <div className="mt-3 h-64 overflow-y-auto rounded-lg border border-slate-200 p-3 bg-slate-50">
                  {chatMessages.map((m, idx) => (
                    <div key={idx} className={`max-w-[80%] my-1 px-3 py-2 rounded-lg text-sm ${m.from === "me" ? "ml-auto bg-blue-600 text-white" : "mr-auto bg-white border border-slate-200"}`}>
                      <p className="text-xs opacity-80 mb-1">{m.from === "me" ? "You" : "Mentor"} • {m.time}</p>
                      <p className="text-sm">{m.text}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <input value={chatInput} onChange={(e) => setChatInput(e.target.value)} placeholder="Type a message" className="text-sm px-3 py-2 rounded-lg border border-slate-300 flex-1" />
                  <button onClick={sendChat} className="px-3 py-2 text-sm rounded-lg bg-blue-600 text-white">Send</button>
                </div>
                {/* AI Assistant */}
                <div className="mt-4 bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-600 flex items-center gap-1"><Icon icon="material-symbols:robot" /> AI Assistant (beta)</p>
                  <p className="text-xs text-slate-500 mt-1">Try: &quot;Suggest a mentor for Algebra&quot;</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {["Suggest a mentor for Algebra", "Tips to improve focus", "Create a 7-day plan"].map(q => (
                      <button key={q} onClick={() => setChatMessages(prev => [...prev, { from: "mentor", text: `AI: ${q} → Check Resources & Calendar.`, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }])} className="text-[11px] px-2 py-1 rounded border border-slate-300 hover:bg-slate-100">{q}</button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Notes + Feedback */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <p className="text-slate-900 text-sm">Notes</p>
                <textarea value={noteText} onChange={(e) => setNoteText(e.target.value)} rows={4} placeholder="Key discussion points..." className="w-full mt-2 px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                <div className="mt-2 flex items-center gap-2">
                  <button onClick={addNote} className="px-3 py-1.5 text-xs rounded-lg bg-slate-900 text-white">Add Note</button>
                  <span className="text-xs text-slate-500">Autosaving…</span>
                </div>
                <ul className="mt-3 space-y-2 text-sm text-slate-700 max-h-40 overflow-y-auto">
                  {notes.map(n => (
                    <li key={n.id} className="p-2 bg-slate-50 rounded border border-slate-200"><span className="text-xs text-slate-500">{n.time} — </span>{n.text}</li>
                  ))}
                </ul>
                <div className="mt-5 border-t border-slate-200 pt-4">
                  <p className="text-slate-900 text-sm">Session Feedback</p>
                  <div className="flex items-center gap-1 mt-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <button key={i} onClick={() => setRating(i + 1)} aria-label={`Rate ${i + 1}`}>
                        <Icon icon={i < rating ? "material-symbols:star" : "material-symbols:star-outline"} className="text-amber-500 text-lg" />
                      </button>
                    ))}
                  </div>
                  <textarea value={feedbackText} onChange={(e) => setFeedbackText(e.target.value)} rows={3} placeholder="Share feedback about your last session" className="w-full mt-2 px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                  <button onClick={submitFeedback} className="mt-2 px-3 py-1.5 text-xs rounded-lg bg-blue-600 text-white">Submit Feedback</button>
                </div>
              </div>
            </section>

            {/* Groups + Forum + Doubts */}
            <section id="groups" className="mt-8 grid xl:grid-cols-3 gap-6">
              {/* Group rooms */}
              <div className="xl:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="material-symbols:group" /> Group Rooms</p>
                  <div className="flex gap-2 text-[11px]">
                    {["DSA Study Group", "Physics Mechanics", "Algebra Boosters"].map(r => (
                      <button key={r} onClick={() => setActiveRoom(r)} className={`px-2 py-1 rounded ${activeRoom === r ? "bg-blue-600 text-white" : "border border-slate-300"}`}>{r}</button>
                    ))}
                  </div>
                </div>
                <div className="mt-3 h-56 overflow-y-auto rounded-lg border border-slate-200 p-3 bg-slate-50">
                  {(groupMessages[activeRoom] || []).map((m, idx) => (
                    <div key={idx} className={`max-w-[85%] my-1 px-3 py-2 rounded-lg text-sm ${m.from === "me" ? "ml-auto bg-teal-600 text-white" : "mr-auto bg-white border border-slate-200"}`}>
                      <p className="text-xs opacity-80 mb-1">{m.from === "me" ? "You" : activeRoom} • {m.time}</p>
                      <p className="text-sm">{m.text}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <input onKeyDown={(e) => { if (e.key === "Enter") sendGroupMessage((e.target as HTMLInputElement).value); }} placeholder="Message the group (Enter to send)" className="text-sm px-3 py-2 rounded-lg border border-slate-300 flex-1" />
                </div>
              </div>

              {/* Forum & doubts */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 space-y-5">
                <div>
                  <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="material-symbols:forum" /> Discussion Forum</p>
                  <div className="mt-2 flex items-center gap-2">
                    <input value={newTopic} onChange={(e) => setNewTopic(e.target.value)} placeholder="Start a topic" className="text-sm px-3 py-2 rounded-lg border border-slate-300 flex-1" />
                    <button onClick={addTopic} className="px-3 py-2 text-sm rounded-lg bg-blue-600 text-white">Post</button>
                  </div>
                  <ul className="mt-3 space-y-2 text-sm text-slate-700 max-h-40 overflow-y-auto">
                    {topics.map(t => (
                      <li key={t.id} className="p-2 bg-slate-50 rounded border border-slate-200">
                        <p className="text-slate-800 text-sm">{t.title}</p>
                        <p className="text-[11px] text-slate-500 mt-1">{t.replies.length} replies</p>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="mdi:help-circle-outline" /> Doubt Box</p>
                  <div className="mt-2 flex items-center gap-2">
                    <input value={doubtText} onChange={(e) => setDoubtText(e.target.value)} placeholder="Ask a question (academic or personal)" className="text-sm px-3 py-2 rounded-lg border border-slate-300 flex-1" />
                    <button onClick={addDoubt} className="px-3 py-2 text-sm rounded-lg border border-slate-300">Drop</button>
                  </div>
                  <ul className="mt-3 space-y-2 text-sm text-slate-700 max-h-36 overflow-y-auto">
                    {doubts.map(d => (
                      <li key={d.id} className="p-2 bg-slate-50 rounded border border-slate-200 flex items-center justify-between">
                        <span>{d.text}</span>
                        <span className={`text-[11px] px-2 py-1 rounded ${d.resolved ? "bg-teal-50 text-teal-700" : "bg-amber-50 text-amber-700"}`}>{d.resolved ? "Resolved" : "Pending"}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </section>

            {/* Calendar + Availability + Tasks */}
            <section id="calendar" className="mt-8 grid xl:grid-cols-3 gap-6">
              {/* Booking calendar */}
              <div className="xl:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="mdi:calendar-outline" /> Session Booking</p>
                <div className="mt-3 overflow-x-auto">
                  <table className="min-w-full text-xs">
                    <thead>
                      <tr>
                        <th className="text-left p-2 text-slate-500">Time</th>
                        {days.map(d => <th key={d} className="text-left p-2 text-slate-500">{d}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {times.map(t => (
                        <tr key={t} className="border-t border-slate-200/60">
                          <td className="p-2 text-slate-600">{t}</td>
                          {days.map(d => {
                            const s = slots.find(x => x.day === d && x.time === t)!;
                            return (
                              <td key={`${d}-${t}`} className="p-2">
                                {s.available ? (
                                  <button onClick={() => bookSlot(d, t)} className="px-2 py-1 rounded bg-teal-600 text-white">Book</button>
                                ) : (
                                  <span className={`px-2 py-1 rounded text-[11px] ${s.booked ? "bg-blue-50 text-blue-700" : "bg-slate-100 text-slate-500"}`}>{s.booked ? "Booked" : "Busy"}</span>
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-[11px] text-slate-500 mt-3">Mentor availability updates every hour.</p>
              </div>

              {/* Tasks + Notifications */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 space-y-5">
                <div>
                  <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="material-symbols:task" /> Task Tracker</p>
                  <div className="mt-2 flex items-center gap-2">
                    <input value={taskText} onChange={(e) => setTaskText(e.target.value)} placeholder="New task" className="text-sm px-3 py-2 rounded-lg border border-slate-300 flex-1" />
                    <button onClick={() => { if (taskText.trim()) { setTasks([{ id: Math.random().toString(36).slice(2), title: taskText.trim(), done: false }, ...tasks]); setTaskText(""); } }} className="px-3 py-2 text-sm rounded-lg bg-blue-600 text-white">Add</button>
                  </div>
                  <ul className="mt-3 space-y-2 text-sm text-slate-700 max-h-40 overflow-y-auto">
                    {tasks.map(t => (
                      <li key={t.id} className="p-2 bg-slate-50 rounded border border-slate-200 flex items-center justify-between">
                        <label className="flex items-center gap-2">
                          <input type="checkbox" checked={t.done} onChange={() => toggleTask(t.id)} />
                          <span className={t.done ? "line-through text-slate-400" : ""}>{t.title}</span>
                        </label>
                        <button onClick={() => setTasks(prev => prev.filter(x => x.id !== t.id))} className="text-[11px] px-2 py-1 rounded border border-slate-300">Remove</button>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="mdi:bell-outline" /> Notifications</p>
                  <div className="mt-2 space-y-2 text-sm text-slate-700">
                    <label className="flex items-center justify-between"><span>Email updates</span><input type="checkbox" checked={notifyEmail} onChange={(e) => setNotifyEmail(e.target.checked)} /></label>
                    <label className="flex items-center justify-between"><span>In-portal alerts</span><input type="checkbox" checked={notifyPortal} onChange={(e) => setNotifyPortal(e.target.checked)} /></label>
                    <label className="flex items-center justify-between"><span>SMS reminders</span><input type="checkbox" checked={notifySMS} onChange={(e) => setNotifySMS(e.target.checked)} /></label>
                    <p className="text-[11px] text-slate-500">Changes saved automatically.</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Resources + Recommendations */}
            <section id="resources" className="mt-8 grid xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="material-symbols:book" /> Resources</p>
                <div className="mt-3 grid sm:grid-cols-4 gap-2">
                  <select value={resourceType} onChange={(e) => setResourceType(e.target.value as ("pdf"|"youtube"|"link"))} className="text-sm px-2 py-2 rounded-lg border border-slate-300">
                    <option value="link">Link</option>
                    <option value="youtube">YouTube</option>
                    <option value="pdf">PDF</option>
                  </select>
                  <input value={resourceTitle} onChange={(e) => setResourceTitle(e.target.value)} placeholder="Title" className="text-sm px-3 py-2 rounded-lg border border-slate-300" />
                  <input value={resourceUrl} onChange={(e) => setResourceUrl(e.target.value)} placeholder="URL" className="text-sm px-3 py-2 rounded-lg border border-slate-300 sm:col-span-2" />
                </div>
                <div className="mt-2">
                  <button onClick={addResource} className="px-3 py-2 text-sm rounded-lg bg-blue-600 text-white">Add Resource</button>
                </div>
                <ul className="mt-3 space-y-2 text-sm text-slate-700 max-h-56 overflow-y-auto">
                  {resources.map(r => (
                    <li key={r.id} className="p-2 bg-slate-50 rounded border border-slate-200 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Icon icon={r.type === "youtube" ? "mdi:video-outline" : r.type === "pdf" ? "mdi:file-pdf-box" : "mdi:link-variant"} className="text-blue-600" />
                        <a href={r.url} target="_blank" rel="noreferrer" className="hover:underline">{r.title}</a>
                      </div>
                      <button onClick={() => setResources(prev => prev.filter(x => x.id !== r.id))} className="text-[11px] px-2 py-1 rounded border border-slate-300">Remove</button>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Mentor suggestion + mentor recommendation */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <p className="text-slate-900 text-sm">Mentor Suggestions</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {subjects.map(s => (
                    <button key={s} onClick={() => setSelectedSubjects(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s])} className={`text-[11px] px-2 py-1 rounded ${selectedSubjects.includes(s) ? "bg-teal-600 text-white" : "border border-slate-300"}`}>{s}</button>
                  ))}
                </div>
                <ul className="mt-3 space-y-2 text-sm text-slate-700">
                  {suggestedMentors.map(m => (
                    <li key={m.id} className="p-2 bg-slate-50 rounded border border-slate-200 flex items-center justify-between">
                      <div>
                        <p className="text-slate-800 text-sm">{m.name}</p>
                        <p className="text-[11px] text-slate-500">{m.specialization} • {m.subjects.join(", ")}</p>
                      </div>
                      <button onClick={() => setSelectedMentorId(m.id)} className="text-[11px] px-2 py-1 rounded bg-blue-600 text-white">Choose</button>
                    </li>
                  ))}
                </ul>
                <div className="mt-5 border-t border-slate-200 pt-4">
                  <p className="text-slate-900 text-sm">Mentor Recommendations</p>
                  <ul className="mt-2 space-y-1 text-sm text-slate-700">
                    {recommendations.map((r, i) => <li key={`${r}-${i}`} className="flex items-center gap-2"><Icon icon="mdi:check" className="text-teal-600" /><span>{r}</span></li>)}
                  </ul>
                  <div className="mt-2 flex items-center gap-2">
                    <input onKeyDown={(e) => { if (e.key === "Enter") { const val = (e.target as HTMLInputElement).value.trim(); if (val) { setRecommendations(prev => [val, ...prev]); (e.target as HTMLInputElement).value = ""; } } }} placeholder="Add a recommended step (Enter)" className="text-sm px-3 py-2 rounded-lg border border-slate-300 flex-1" />
                  </div>
                </div>
              </div>
            </section>

            {/* Recordings + Reports */}
            <section id="recordings" className="mt-8 grid xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="mdi:video-outline" /> Session Recordings</p>
                <ul className="mt-3 grid sm:grid-cols-2 gap-3 text-sm text-slate-700">
                  {recordings.map(v => (
                    <li key={v.id} className="p-2 bg-slate-50 rounded border border-slate-200 flex items-center justify-between">
                      <span>{v.title}</span>
                      <button onClick={() => setOpenVideo(v.url)} className="text-[11px] px-2 py-1 rounded bg-blue-600 text-white">Watch</button>
                    </li>
                  ))}
                </ul>
                {openVideo && (
                  <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setOpenVideo(null)}>
                    <div className="bg-white rounded-xl w-full max-w-3xl p-3" onClick={(e) => e.stopPropagation()}>
                      <div className="aspect-video w-full">
                        <iframe className="w-full h-full rounded" src={openVideo} title="Session recording" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
                      </div>
                      <div className="text-right mt-3"><button onClick={() => setOpenVideo(null)} className="px-3 py-1.5 text-sm rounded-lg border border-slate-300">Close</button></div>
                    </div>
                  </div>
                )}
              </div>

              <div id="reports" className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="material-symbols:download" /> Progress Reports</p>
                <p className="text-xs text-slate-600 mt-1">Auto-generate a quick summary.</p>
                <div className="mt-3 flex items-center gap-2">
                  <button onClick={() => downloadReport("weekly")} className="px-3 py-2 text-sm rounded-lg bg-blue-600 text-white">Download Weekly</button>
                  <button onClick={() => downloadReport("monthly")} className="px-3 py-2 text-sm rounded-lg border border-slate-300">Download Monthly</button>
                </div>
              </div>
            </section>

            {/* Profile + Privacy + Help */}
            <section id="profile" className="mt-8 grid xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2 bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <p className="text-slate-900 text-sm">Student Profile</p>
                <div className="mt-3 grid sm:grid-cols-3 gap-4">
                  <div className="sm:col-span-2">
                    <label className="text-xs text-slate-600">Bio</label>
                    <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={4} className="w-full mt-1 px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                  </div>
                  <div>
                    <label className="text-xs text-slate-600">Interests</label>
                    <textarea value={interests} onChange={(e) => setInterests(e.target.value)} rows={4} className="w-full mt-1 px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                  </div>
                </div>
                <div className="mt-3 grid sm:grid-cols-2 gap-3 text-sm">
                  <div className="p-3 bg-slate-50 rounded border border-slate-200">
                    <p className="text-slate-800 text-sm">Mentor History</p>
                    <ul className="mt-1 text-xs text-slate-600 list-disc list-inside">
                      <li>Sofia Garcia (current)</li>
                      <li>Aisha Kumar (trial)</li>
                    </ul>
                  </div>
                  <div className="p-3 bg-slate-50 rounded border border-slate-200">
                    <p className="text-slate-800 text-sm">Achievements</p>
                    <div className="mt-1 flex flex-wrap gap-2">
                      {mentorBadges.map(b => <span key={b} className="px-2 py-1 rounded-full bg-teal-50 text-teal-700 text-[10px]">{b}</span>)}
                    </div>
                  </div>
                </div>
              </div>

              <div id="settings" className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 space-y-5">
                <div>
                  <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="material-symbols:privacy" /> Privacy Settings</p>
                  <div className="mt-2 space-y-2 text-sm text-slate-700">
                    <label className="flex items-center justify-between"><span>Show progress to mentors</span><input type="checkbox" checked={privacy.showProgress} onChange={(e) => setPrivacy({ ...privacy, showProgress: e.target.checked })} /></label>
                    <label className="flex items-center justify-between"><span>Show goals to mentors</span><input type="checkbox" checked={privacy.showGoals} onChange={(e) => setPrivacy({ ...privacy, showGoals: e.target.checked })} /></label>
                    <label className="flex items-center justify-between"><span>Show profile to peers</span><input type="checkbox" checked={privacy.showProfile} onChange={(e) => setPrivacy({ ...privacy, showProfile: e.target.checked })} /></label>
                    <button onClick={savePrivacy} className="mt-2 px-3 py-2 text-sm rounded-lg border border-slate-300">Save</button>
                  </div>
                </div>
                <div>
                  <p className="text-slate-900 text-sm flex items-center gap-2"><Icon icon="material-symbols:help-outline" /> Help & Support</p>
                  <div className="mt-2 text-sm text-slate-700">
                    {[{q: "How do I book a session?", a: "Go to Calendar and click an available slot."}, {q: "How to change mentor?", a: "Use Switch mentor in Mentor Dashboard."}, {q: "Where are recordings?", a: "See Recordings section."}].map((f, i) => (
                      <details key={i} className="p-2 bg-slate-50 rounded border border-slate-200">
                        <summary className="cursor-pointer text-slate-800">{f.q}</summary>
                        <p className="text-xs text-slate-600 mt-1">{f.a}</p>
                      </details>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-slate-900 text-sm">Mentor Request</p>
                  <textarea rows={3} placeholder="Request a specific mentor or share preferences" className="w-full mt-2 px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                  <button onClick={requestMentor} className="mt-2 px-3 py-2 text-sm rounded-lg bg-blue-600 text-white">Send Request</button>
                </div>
              </div>
            </section>

            {/* Reports and email note placed earlier; Footer below */}
            <Footer />
          </div>
        </main>
      </div>
    </div>
  );
}
