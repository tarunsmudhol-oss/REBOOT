"use client";

import React from "react";
import TopHeader from "@/app/components/TopHeader";
import LeftNav from "@/app/components/LeftNav";
import Backlogs from "@/app/components/Backlogs";
import { motion } from "framer-motion";

export default function BacklogsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <TopHeader />
      <div className="flex">
        <LeftNav />
        <main className="flex-1">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="mb-6">
              <p className="text-xs uppercase tracking-wide text-slate-500">Student Portal</p>
              <h1 className="text-2xl md:text-3xl text-slate-900 mt-1">Backlogs</h1>
            </motion.div>
            <Backlogs />
          </div>
        </main>
      </div>
    </div>
  );
}
