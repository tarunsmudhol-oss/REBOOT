"use client";

import React from "react";

export default function Loading() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <div className="flex">
        <aside className="hidden lg:block w-56 border-r border-slate-200/60 bg-white/70 min-h-screen" />
        <div className="flex-1">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <div className="h-6 w-40 bg-slate-200/70 rounded mb-4" />
            <div className="h-8 w-56 bg-slate-200/70 rounded mb-6" />
            <div className="h-80 bg-white/70 border border-white/20 rounded-xl animate-pulse" />
          </div>
        </div>
      </div>
    </div>
  );
}
