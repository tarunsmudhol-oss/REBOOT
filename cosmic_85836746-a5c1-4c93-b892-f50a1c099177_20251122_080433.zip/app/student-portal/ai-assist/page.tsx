"use client";

import React, { useState } from "react";
import TopHeader from "@/app/components/TopHeader";
import LeftNav from "@/app/components/LeftNav";
import { motion } from "framer-motion";
import AIPersonalizationOverlay from "@/app/components/AIPersonalizationOverlay";

export default function AIAssistPage() {
  const [enabled, setEnabled] = useState<boolean>(true);
  const [intensity, setIntensity] = useState<number>(0.6);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <TopHeader />
      <div className="flex">
        <LeftNav />
        <main className="flex-1">
          <div className="max-w-7xl mx-auto px-6 py-8">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="mb-6">
              <p className="text-xs uppercase tracking-wide text-slate-500">Student Portal</p>
              <h1 className="text-2xl md:text-3xl text-slate-900 mt-1">AI Assist</h1>
            </motion.div>

            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <h2 className="text-lg text-slate-900 mb-2">Personalized Focus</h2>
              <p className="text-sm text-slate-600 mb-4">Enable the AI overlay to receive subtle guidance on what to focus next while you work.</p>
              <AIPersonalizationOverlay
                enabled={enabled}
                intensity={intensity}
                state="rising"
                nextTask="Revise Algebra II: Quadratics"
                onToggle={setEnabled}
                onIntensity={setIntensity}
              />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
