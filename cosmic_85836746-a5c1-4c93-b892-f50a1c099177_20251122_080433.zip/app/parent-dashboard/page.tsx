"use client";

import React, { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function ParentDashboard() {
  const router = useRouter();
  useEffect(() => {
    router.replace('/parents-guardians-zone');
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <p className="text-slate-600 text-sm">Redirecting to Parents / Guardians Zone…</p>
    </div>
  );
}