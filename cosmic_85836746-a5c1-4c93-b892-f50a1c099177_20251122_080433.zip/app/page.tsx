"use client";

import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/app/components/Navbar";
import AuthForm from "@/app/components/AuthForm";
import { Button } from "@/app/components/Button";

export default function Home() {
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "signup">("signup");
  const router = useRouter();

  // Remove only the visible "Built with Cosmic" text on this page while keeping the required badge visible
  useEffect(() => {
    document.body.setAttribute("data-smart-portal", "true");

    const scrubBadgeText = () => {
      const regex = /built\s*with\s*cosmic/i;
      const candidates = Array.from(
        document.querySelectorAll(
          "#cosmic-badge, [id*='cosmic-badge'], a[href*='cosmic.new'], a[href*='cosmic']"
        )
      );

      candidates.forEach((el) => {
        // Remove direct text nodes that match
        el.childNodes.forEach((node) => {
          if (node.nodeType === Node.TEXT_NODE && regex.test(node.textContent ?? "")) {
            node.textContent = "";
          }
        });
        // Remove matching text inside spans
        el.querySelectorAll("span").forEach((span) => {
          if (regex.test(span.textContent ?? "")) {
            span.textContent = "";
            span.setAttribute("aria-hidden", "true");
          }
        });
        // Clean up common attributes
        const title = (el as HTMLElement).getAttribute("title");
        if (title && regex.test(title)) (el as HTMLElement).setAttribute("title", "");
        const ariaLabel = (el as HTMLElement).getAttribute("aria-label");
        if (ariaLabel && regex.test(ariaLabel)) (el as HTMLElement).setAttribute("aria-label", "");
      });
    };

    scrubBadgeText();
    const observer = new MutationObserver(() => scrubBadgeText());
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      document.body.removeAttribute("data-smart-portal");
    };
  }, []);

  const handleGetStarted = () => {
    setAuthMode("signup");
    setShowAuth(true);
  };

  const handleSignIn = () => {
    setAuthMode("login");
    setShowAuth(true);
  };

  const handleRoleSelection = (role: string) => {
    const routes = {
      student: "/student-dashboard",
      teacher: "/teacher-dashboard", 
      parent: "/parent-dashboard"
    };
    
    router.push(routes[role as keyof typeof routes]);
  };

  const features = [
    {
      icon: "mdi:book-open-variant",
      title: "Course Management",
      description: "Organize and track all your academic courses in one place"
    },
    {
      icon: "mdi:chart-line",
      title: "Progress Tracking",
      description: "Monitor academic progress with detailed analytics and insights"
    },
    {
      icon: "mdi:account-group", 
      title: "Collaboration Tools",
      description: "Connect students, teachers, and parents seamlessly"
    },
    {
      icon: "mdi:calendar-check",
      title: "Assignment Calendar",
      description: "Never miss a deadline with our integrated calendar system"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      {/* Route prefetchers for instant section open */}
      <div aria-hidden="true" className="hidden">
        <Link href="/student-dashboard" prefetch>student</Link>
        <Link href="/student-dashboard/assignments" prefetch>assignments</Link>
        <Link href="/student-dashboard/performance" prefetch>performance</Link>
        <Link href="/student-portal/mentoring" prefetch>mentoring</Link>
        <Link href="/student-portal/backlogs" prefetch>backlogs</Link>
        <Link href="/student-portal/ai-assist" prefetch>ai</Link>
        <Link href="/student-portal/feedback" prefetch>feedback</Link>
        <Link href="/teacher-dashboard" prefetch>teacher</Link>
        <Link href="/parents-guardians-zone" prefetch>parents</Link>
      </div>

      {/* Page-scoped CSS to visually hide the text label on the Cosmic badge while keeping the badge visible */}
      <style
        dangerouslySetInnerHTML={{
          __html: `
          body[data-smart-portal="true"] #cosmic-badge span,
          body[data-smart-portal="true"] [id*="cosmic-badge"] span {
            color: transparent !important;
            text-shadow: none !important;
          }
          body[data-smart-portal="true"] #cosmic-badge,
          body[data-smart-portal="true"] [id*="cosmic-badge"] {
            opacity: 1 !important;
          }
        `
        }}
      />

      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-8"
            >
              <div className="inline-flex items-center px-4 py-2 bg-blue-100/80 backdrop-blur-sm rounded-full text-blue-700 text-sm font-medium mb-6">
                <Icon icon="mdi:education" className="mr-2" />
                Welcome to the future of education
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light text-slate-900 mb-6 leading-tight">
                <span className="block">Smart Student Portal</span>
                <span className="block text-3xl sm:text-4xl lg:text-5xl text-slate-600 mt-2">
                  Connecting Students, Resources, and Success
                </span>
              </h1>
              
              <p className="text-lg text-slate-600 mb-8 max-w-2xl mx-auto leading-relaxed">
                A comprehensive education platform that brings together students, teachers, and parents. 
                Manage coursework, track progress, and foster educational success in one intuitive portal.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={handleGetStarted}
                  size="lg"
                  className="px-8 py-3"
                  icon={<Icon icon="mdi:arrow-right" />}
                >
                  Get Started Free
                </Button>
                <Button 
                  onClick={handleSignIn}
                  variant="outline"
                  size="lg"
                  className="px-8 py-3"
                >
                  Sign In
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-light text-slate-900 mb-4">
              Everything you need for educational success
            </h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Powerful tools designed to enhance learning, teaching, and parent engagement
            </p>
          </motion.div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 hover:shadow-lg transition-all duration-300"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Icon icon={feature.icon} className="text-blue-600 text-xl" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">{feature.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Role Preview Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-light text-slate-900 mb-4">
              Designed for every member of the educational community
            </h2>
          </motion.div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: "hugeicons:students",
                title: "Students",
                description: "Access courses, submit assignments, track grades, and collaborate with peers",
                color: "bg-blue-500"
              },
              {
                icon: "mdi:account-tie", 
                title: "Teachers",
                description: "Create assignments, grade work, manage classes, and communicate with students",
                color: "bg-green-500"
              },
              {
                icon: "mdi:account-heart",
                title: "Parents",
                description: "Monitor progress, communicate with teachers, and stay involved in education",
                color: "bg-orange-500"
              }
            ].map((role, index) => (
              <motion.div
                key={role.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className={`w-16 h-16 ${role.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                  <Icon icon={role.icon} className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-medium text-slate-900 mb-2">{role.title}</h3>
                <p className="text-slate-600 leading-relaxed">{role.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Auth Modal */}
      {showAuth && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative">
            <button
              onClick={() => setShowAuth(false)}
              className="absolute -top-4 -right-4 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center text-slate-500 hover:text-slate-700 z-10"
            >
              <Icon icon="mdi:close" />
            </button>
            <AuthForm 
              mode={authMode}
              onModeSwitch={setAuthMode}
              onRoleSelection={handleRoleSelection}
            />
          </div>
        </div>
      )}
    </div>
  );
}