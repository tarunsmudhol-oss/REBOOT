"use client";

import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react";
import { useAuth } from "cosmic-authentication";
import { Button } from "@/app/components/Button";
import AnalyticsPanel from "@/app/components/AnalyticsPanel";
import DiscussionThread from "@/app/components/DiscussionThread";
import TeacherOnboarding from "@/app/components/TeacherOnboarding";
import LeftNav from "@/app/components/LeftNav";

export default function TeacherDashboard() {
  const { user, signOut } = useAuth();

  const stats = [
    { label: "Active Classes", value: "4", icon: "mdi:google-classroom", color: "text-blue-600" },
    { label: "Total Students", value: "127", icon: "hugeicons:students", color: "text-green-600" },
    { label: "Pending Grades", value: "23", icon: "mdi:clipboard-check", color: "text-orange-600" },
    { label: "This Week\'s Lessons", value: "12", icon: "mdi:book-open-variant", color: "text-teal-600" }
  ];

  const myClasses = [
    { name: "Advanced Mathematics", students: 32, period: "1st Period", room: "Room 101" },
    { name: "Algebra II", students: 28, period: "3rd Period", room: "Room 101" },
    { name: "Geometry", students: 35, period: "5th Period", room: "Room 102" },
    { name: "Pre-Calculus", students: 32, period: "7th Period", room: "Room 101" }
  ];

  const recentSubmissions = [
    { student: "Emma Johnson", assignment: "Quadratic Equations", subject: "Algebra II", submitted: "2 hours ago" },
    { student: "Michael Chen", assignment: "Geometry Proofs", subject: "Geometry", submitted: "3 hours ago" },
    { student: "Sarah Williams", assignment: "Calculus Practice", subject: "Pre-Calculus", submitted: "1 day ago" }
  ];

  const upcomingTasks = [
    { task: "Grade Midterm Exams", class: "Advanced Mathematics", deadline: "Tomorrow" },
    { task: "Prepare Lesson Plan", class: "Geometry", deadline: "Friday" },
    { task: "Parent-Teacher Meetings", class: "All Classes", deadline: "Next Week" }
  ];

  // Lesson plans (dummy, client-side only for demo)
  const [lessonPlans, setLessonPlans] = useState<Array<{ id: string; title: string; subject: string; objective: string }>>([
    { id: "lp1", title: "Linear Equations Basics", subject: "Algebra", objective: "Solve single-variable linear equations" },
    { id: "lp2", title: "Triangles & Similarity", subject: "Geometry", objective: "Understand triangle similarity theorems" }
  ]);
  const [newPlan, setNewPlan] = useState<{ title: string; subject: string; objective: string }>({ title: "", subject: "", objective: "" });

  // Content library (dummy)
  const [query, setQuery] = useState<string>("");
  const library = useMemo(() => ([
    { id: "r1", type: "video", title: "Khan Academy: Derivatives Intro", subject: "Calculus" },
    { id: "r2", type: "worksheet", title: "Algebra Worksheets Pack", subject: "Algebra" },
    { id: "r3", type: "reference", title: "Geometry Proofs Guide", subject: "Geometry" },
    { id: "r4", type: "interactive", title: "Functions Sandbox", subject: "Algebra" },
  ]), []);
  const filteredLibrary = useMemo(() => library.filter(i => (
    !query || i.title.toLowerCase().includes(query.toLowerCase()) || i.subject.toLowerCase().includes(query.toLowerCase())
  )), [library, query]);

  // Students (dummy)
  const students = [
    { name: "Emma Johnson", progress: 82, attendance: 96, grade: "A-", behavior: "Positive" },
    { name: "Michael Chen", progress: 71, attendance: 92, grade: "B", behavior: "Neutral" },
    { name: "Sarah Williams", progress: 89, attendance: 98, grade: "A", behavior: "Positive" },
    { name: "Aarav Patel", progress: 64, attendance: 88, grade: "C+", behavior: "Needs Support" }
  ];

  // Gradebook (dummy)
  const [grades, setGrades] = useState<Array<{ id: string; student: string; assignment: string; score: number | null }>>([
    { id: "g1", student: "Emma Johnson", assignment: "Quiz 3", score: 18 },
    { id: "g2", student: "Michael Chen", assignment: "Quiz 3", score: 15 },
    { id: "g3", student: "Sarah Williams", assignment: "Quiz 3", score: 19 },
    { id: "g4", student: "Aarav Patel", assignment: "Quiz 3", score: null }
  ]);

  // Schedule (dummy)
  const events = [
    { when: "Mon 10:00", what: "Algebra II - Chapter 4", where: "Room 101" },
    { when: "Tue 12:00", what: "Geometry - Proof Workshop", where: "Room 102" },
    { when: "Wed 14:00", what: "Parent-Teacher Q&A", where: "Conference Hall" }
  ];

  // Resources & tasks (dummy)
  const resources: Array<{ id: string; name: string; subject: string; due?: string }> = [
    { id: "rs1", name: "Homework Set 5 (PDF)", subject: "Algebra", due: "Fri" },
    { id: "rs2", name: "Slides: Triangle Similarity", subject: "Geometry" }
  ];

  // e‑Library (dummy)
  const [recommendedIds, setRecommendedIds] = useState<Set<string>>(new Set());
  const books = [
    { id: "b1", title: "Calculus Made Easy", author: "Silvanus P. Thompson" },
    { id: "b2", title: "How to Solve It", author: "George Pólya" },
    { id: "b3", title: "The Art of Problem Solving", author: "Sandor Lehoczky" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      <div className="flex">
        <LeftNav />
        <div className="flex-1">
          {/* Onboarding Overlay */}
          <TeacherOnboarding />
          {/* Header */}
          <header className="bg-white/80 backdrop-blur-lg border-b border-slate-200/50 px-6 py-4">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                  <Icon icon="mdi:account-tie" className="text-white text-xl" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-slate-900">Teacher Dashboard</h1>
                  <p className="text-sm text-slate-600">Welcome back, {user?.displayName || "Teacher"}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <a href="/feedback/analytics" className="text-sm px-3 py-1.5 rounded bg-slate-900 text-white flex items-center"><Icon icon="mdi:chart-bar" className="mr-1"/> Feedback Analytics</a>
                <Button variant="ghost" size="sm" onClick={signOut}>
                  Sign Out
                </Button>
              </div>
            </div>
          </header>

          <div className="max-w-7xl mx-auto px-6 py-8">
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-600 mb-1">{stat.label}</p>
                      <p className="text-2xl font-semibold text-slate-900">{stat.value}</p>
                    </div>
                    <Icon icon={stat.icon} className={`text-2xl ${stat.color}`} />
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="grid lg:grid-cols-2 gap-8 mb-8">
              {/* My Classes */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-slate-900">My Classes</h2>
                  <Button variant="ghost" size="sm">
                    <Icon icon="mdi:plus" className="mr-1" />
                    Add Class
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {myClasses.map((classItem, index) => (
                    <div key={index} className="p-4 bg-slate-50/50 rounded-lg hover:bg-slate-100/50 transition-colors cursor-pointer">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-slate-900">{classItem.name}</h3>
                        <span className="text-sm text-slate-500">{classItem.room}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm text-slate-600">
                        <span>{classItem.students} students</span>
                        <span>{classItem.period}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Recent Submissions */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-slate-900">Recent Submissions</h2>
                  <Button variant="ghost" size="sm">View All</Button>
                </div>
                
                <div className="space-y-4">
                  {recentSubmissions.map((submission, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-slate-50/50 rounded-lg">
                      <div className="flex-1">
                        <h3 className="font-medium text-slate-900 mb-1">{submission.student}</h3>
                        <p className="text-sm text-slate-600">{submission.assignment} • {submission.subject}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-slate-500">{submission.submitted}</p>
                        <Button variant="ghost" size="sm" className="mt-1">
                          Review
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Upcoming Tasks */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-slate-900">Upcoming Tasks</h2>
                <Button variant="ghost" size="sm">
                  <Icon icon="mdi:plus" className="mr-1" />
                  Add Task
                </Button>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4">
                {upcomingTasks.map((task, index) => (
                  <div key={index} className="p-4 bg-slate-50/50 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-medium text-slate-900 text-sm">{task.task}</h3>
                      <Icon icon="mdi:clock-outline" className="text-slate-400 text-sm mt-1" />
                    </div>
                    <p className="text-xs text-slate-600 mb-2">{task.class}</p>
                    <p className="text-xs text-orange-600 font-medium">{task.deadline}</p>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Lesson Planning Tools */}
            <motion.section id="lesson-plans" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-slate-900">Lesson Planning Tools</h2>
                <Button size="sm" variant="ghost" onClick={() => {
                  if (!newPlan.title.trim()) return;
                  setLessonPlans((prev) => [{ id: `lp_${Date.now()}`, title: newPlan.title.trim(), subject: newPlan.subject.trim(), objective: newPlan.objective.trim() }, ...prev]);
                  setNewPlan({ title: "", subject: "", objective: "" });
                }}>
                  <Icon icon="mdi:content-save" className="mr-1"/> Save Plan
                </Button>
              </div>
              <div className="grid md:grid-cols-3 gap-3 mb-3">
                <input value={newPlan.title} onChange={(e) => setNewPlan({...newPlan, title: e.target.value})} placeholder="Title" className="text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
                <input value={newPlan.subject} onChange={(e) => setNewPlan({...newPlan, subject: e.target.value})} placeholder="Subject" className="text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
                <input value={newPlan.objective} onChange={(e) => setNewPlan({...newPlan, objective: e.target.value})} placeholder="Learning objective" className="text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                {lessonPlans.map((p) => (
                  <div key={p.id} className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="text-sm font-medium text-slate-900">{p.title}</h3>
                      <span className="text-xs px-2 py-0.5 rounded bg-emerald-100 text-emerald-700">{p.subject}</span>
                    </div>
                    <p className="text-xs text-slate-600">Objective: {p.objective || "—"}</p>
                    <div className="mt-3 flex gap-2">
                      <button className="px-2 py-1 text-xs rounded bg-slate-900 text-white">Share</button>
                      <button className="px-2 py-1 text-xs rounded bg-slate-100">Attach</button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.section>

            {/* Content Libraries */}
            <motion.section id="content-library" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-slate-900">Content Library</h2>
                <div className="flex items-center gap-2">
                  <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search resources" className="text-sm px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" />
                </div>
              </div>
              <div className="grid md:grid-cols-3 gap-4">
                {filteredLibrary.map((r) => (
                  <div key={r.id} className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="text-sm font-medium text-slate-900">{r.title}</h3>
                      <span className="text-xs px-2 py-0.5 rounded bg-sky-100 text-sky-700 capitalize">{r.type}</span>
                    </div>
                    <p className="text-xs text-slate-600">{r.subject}</p>
                    <div className="mt-3 flex gap-2">
                      <button className="px-2 py-1 text-xs rounded bg-slate-900 text-white">Open</button>
                      <button className="px-2 py-1 text-xs rounded bg-slate-100">Share to Students</button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.section>

            {/* Student Data Management */}
            <motion.section id="students" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Student Data Management</h2>
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left text-slate-600">
                      <th className="py-2">Name</th>
                      <th className="py-2">Progress</th>
                      <th className="py-2">Attendance</th>
                      <th className="py-2">Grade</th>
                      <th className="py-2">Behavior</th>
                      <th className="py-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((s) => (
                      <tr key={s.name} className="border-t">
                        <td className="py-2 text-slate-900">{s.name}</td>
                        <td className="py-2">{s.progress}%</td>
                        <td className="py-2">{s.attendance}%</td>
                        <td className="py-2">{s.grade}</td>
                        <td className="py-2">{s.behavior}</td>
                        <td className="py-2">
                          <button className="px-2 py-1 text-xs rounded bg-slate-100">View</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.section>

            {/* Communication & Collaboration */}
            <motion.section id="communication" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-slate-900">Communication & Collaboration</h2>
                <div className="text-xs text-slate-600">Messaging demo only</div>
              </div>
              <DiscussionThread assignmentId="teacher-lounge" />
              <div className="mt-4 grid md:grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                  <h3 className="text-sm font-medium text-slate-900 mb-1">Discussion Boards</h3>
                  <p className="text-xs text-slate-600">Create class forums and Q&A threads.</p>
                </div>
                <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                  <h3 className="text-sm font-medium text-slate-900 mb-1">Video Conferencing</h3>
                  <p className="text-xs text-slate-600">Placeholder for live class links.</p>
                </div>
                <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                  <h3 className="text-sm font-medium text-slate-900 mb-1">Notifications</h3>
                  <p className="text-xs text-slate-600">Announcements to classes and parents.</p>
                </div>
              </div>
            </motion.section>

            {/* Grading & Assessments */}
            <motion.section id="grading" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-slate-900">Grading & Assessments</h2>
                <Button size="sm" variant="ghost"><Icon icon="mdi:clipboard-plus" className="mr-1"/> New Test</Button>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left text-slate-600">
                      <th className="py-2">Student</th>
                      <th className="py-2">Assignment</th>
                      <th className="py-2">Score</th>
                      <th className="py-2">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {grades.map((g) => (
                      <tr key={g.id} className="border-t">
                        <td className="py-2 text-slate-900">{g.student}</td>
                        <td className="py-2">{g.assignment}</td>
                        <td className="py-2">{g.score ?? "—"}</td>
                        <td className="py-2">
                          <button onClick={() => setGrades((prev) => prev.map((x) => x.id === g.id ? { ...x, score: (x.score ?? 0) + 1 } : x))} className="px-2 py-1 text-xs rounded bg-slate-100">+1</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.section>

            {/* Schedule */}
            <motion.section id="schedule" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-slate-900">Personal Calendars & Scheduling</h2>
                <Button size="sm" variant="ghost"><Icon icon="mdi:calendar-plus" className="mr-1"/> Add Event</Button>
              </div>
              <div className="grid md:grid-cols-3 gap-4">
                {events.map((e, i) => (
                  <div key={i} className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                    <p className="text-xs text-slate-500">{e.when} • {e.where}</p>
                    <p className="text-sm text-slate-900 mt-1">{e.what}</p>
                  </div>
                ))}
              </div>
            </motion.section>

            {/* Reports & Analytics */}
            <motion.section id="reports" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Reports & Analytics</h2>
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2"><AnalyticsPanel /></div>
                <div className="bg-white/70 border border-white/30 rounded-xl p-4">
                  <p className="text-sm text-slate-900 mb-2">Summary</p>
                  <ul className="text-xs text-slate-600 space-y-1">
                    <li>Enrollment: 127 students</li>
                    <li>Average Attendance: 94%</li>
                    <li>Lesson Completion: 86%</li>
                  </ul>
                </div>
              </div>
            </motion.section>

            {/* Resources & Task Management */}
            <motion.section id="resources" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-slate-900">Resources</h2>
                <Button size="sm" variant="ghost"><Icon icon="mdi:upload" className="mr-1"/> Upload</Button>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                {resources.map((r) => (
                  <div key={r.id} className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-900">{r.name}</p>
                      <p className="text-xs text-slate-500">{r.subject} {r.due ? `• Due ${r.due}` : ""}</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="px-2 py-1 text-xs rounded bg-slate-100">Assign</button>
                      <button className="px-2 py-1 text-xs rounded bg-slate-100">Download</button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.section>

            {/* Collaborative Spaces */}
            <motion.section id="collaboration" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20 mb-8">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Collaborative Spaces</h2>
              <div className="grid md:grid-cols-3 gap-4">
                {[
                  { title: "Algebra Team", desc: "Share resources and align exams." },
                  { title: "Geometry Project", desc: "Group tasks and review." },
                  { title: "PD: Assessment Design", desc: "Professional development materials." }
                ].map((c) => (
                  <div key={c.title} className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                    <p className="text-sm text-slate-900">{c.title}</p>
                    <p className="text-xs text-slate-600 mt-1">{c.desc}</p>
                    <div className="mt-2 flex gap-2">
                      <button className="px-2 py-1 text-xs rounded bg-slate-100">Open</button>
                      <button className="px-2 py-1 text-xs rounded bg-slate-100">Share</button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.section>

            {/* e‑Library */}
            <motion.section id="elibrary" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{duration:0.4}} className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-slate-900">e‑Library</h2>
                <div className="text-xs text-slate-600">Suggest titles to students</div>
              </div>
              <div className="grid md:grid-cols-3 gap-4">
                {books.map((b) => {
                  const isRec = recommendedIds.has(b.id);
                  return (
                    <div key={b.id} className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-900">{b.title}</p>
                        <p className="text-xs text-slate-600">{b.author}</p>
                      </div>
                      <button onClick={() => setRecommendedIds((prev) => {
                        const next = new Set(prev);
                        if (next.has(b.id)) next.delete(b.id); else next.add(b.id);
                        return next;
                      })} className={`px-2 py-1 text-xs rounded ${isRec ? "bg-teal-600 text-white" : "bg-slate-100"}`}>
                        {isRec ? "Recommended" : "Recommend"}
                      </button>
                    </div>
                  );
                })}
              </div>
            </motion.section>
          </div>
        </div>
      </div>
    </div>
  );
}